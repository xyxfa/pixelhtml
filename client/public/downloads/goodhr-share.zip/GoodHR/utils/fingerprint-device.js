class DeviceFingerprint {
    constructor() {
        this.fingerprint = null;
        this.isLoaded = false;
    }
    async loadFingerprintJS() {
        return new Promise((resolve, reject) => {
            if (window.FingerprintJS) {
                this.isLoaded = true;
                resolve();
                return;
            }
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL('utils/fp.min.js');
            script.onload = () => {
                this.isLoaded = true;
                resolve();
            };
            script.onerror = () => {
                reject(new Error('Failed to load FingerprintJS'));
            };
            document.head.appendChild(script);
        });
    }
    async generateFingerprint() {
        try {
            const storedFingerprint = this.getStoredFingerprint();
            if (storedFingerprint) {
                this.fingerprint = storedFingerprint;
                return this.fingerprint;
            }
            if (!this.isLoaded) {
                await this.loadFingerprintJS();
            }
            const fp = await window.FingerprintJS.load({
                debug: false
            });
            const result = await fp.get();
            this.fingerprint = 'hr_device_' + result.visitorId;
            this.storeFingerprint(this.fingerprint);
            return this.fingerprint;
        }
        catch (error) {
            void 0;
            this.fingerprint = 'hr_device_' + Date.now().toString(16) + '_' + Math.random().toString(36).substring(2);
            this.storeFingerprint(this.fingerprint);
            return this.fingerprint;
        }
    }
    storeFingerprint(fingerprint) {
        try {
            localStorage.setItem('goodhr_device_fingerprint', fingerprint);
            localStorage.setItem('goodhr_fingerprint_time', Date.now().toString());
        }
        catch (error) {
            void 0;
        }
    }
    getStoredFingerprint() {
        try {
            const fingerprint = localStorage.getItem('goodhr_device_fingerprint');
            const timestamp = localStorage.getItem('goodhr_fingerprint_time');
            if (!fingerprint || !timestamp) {
                return null;
            }
            const now = Date.now();
            const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
            if (now - parseInt(timestamp, 10) > sevenDaysInMs) {
                localStorage.removeItem('goodhr_device_fingerprint');
                localStorage.removeItem('goodhr_fingerprint_time');
                return null;
            }
            return fingerprint;
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    getFingerprint() {
        return this.fingerprint;
    }
    async checkDeviceUsage(phone) {
        try {
            if (!this.fingerprint) {
                await this.generateFingerprint();
            }
            const apiBase = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.API_BASE : 'https://goodhr.58it.cn';
            const response = await fetch(`${apiBase}/checkfingerprint.php?fingerprint=${encodeURIComponent(this.fingerprint)}&phone=${encodeURIComponent(phone)}`);
            const data = await response.json();
            return data;
        }
        catch (error) {
            void 0;
            return {
                device_used: false,
                associated_phone: null,
                phone: phone
            };
        }
    }
    async checkAITrialStatus() {
        try {
            if (!this.fingerprint) {
                await this.generateFingerprint();
            }
            const apiBase = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.API_BASE : 'https://goodhr.58it.cn';
            const response = await fetch(`${apiBase}/checkaitrial.php?fingerprint=${encodeURIComponent(this.fingerprint)}`);
            const data = await response.json();
            return data;
        }
        catch (error) {
            void 0;
            return {
                device_used: false,
                associated_phone: null,
                has_trial: false
            };
        }
    }
}
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DeviceFingerprint;
}
else {
    window.DeviceFingerprint = DeviceFingerprint;
}
