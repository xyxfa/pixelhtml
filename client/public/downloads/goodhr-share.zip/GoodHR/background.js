self.addEventListener('install', (event) => {
    void 0;
    event.waitUntil(self.skipWaiting());
});
self.addEventListener('activate', (event) => {
    void 0;
    event.waitUntil(self.clients.claim());
});
self.addEventListener('error', (event) => {
    void 0;
});
self.addEventListener('unhandledrejection', (event) => {
    void 0;
});
let collectedCandidates = [];
let runningSite = null;
const processedRequests = new Set();
const processedUrls = new Set();
let keepAliveInterval = null;
function startKeepAlive() {
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
    }
}
async function fetchRankingData() {
    try {
        const response = await fetch('https://goodhr.58it.cn/dashang.json');
        const data = await response.json();
        return data;
    }
    catch (error) {
        void 0;
        return [];
    }
}
async function proxyAIRequest(payload) {
    const endpoint = payload?.endpoint;
    const apiKey = payload?.apiKey;
    const model = payload?.model;
    const prompt = payload?.prompt;
    const maxTokens = payload?.maxTokens;
    const temperature = payload?.temperature;
    const provider = payload?.provider;
    const reasoningEffort = payload?.reasoningEffort;
    if (!endpoint) {
        throw new Error('缺少AI接口地址');
    }
    if (!apiKey) {
        throw new Error('缺少AI密钥');
    }
    if (!model) {
        throw new Error('缺少AI模型');
    }
    if (!prompt) {
        throw new Error('缺少AI提示词');
    }
    const isAnthropicCompatible = provider === 'anthropic-compatible' || /\/anthropic(\/|$)/i.test(endpoint || '') || /\/messages$/i.test(endpoint || '');
    const headers = {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
    };
    const body = isAnthropicCompatible
        ? {
            model,
            max_tokens: maxTokens,
            temperature,
            messages: [
                {
                    role: 'user',
                    content: prompt
                }
            ],
            ...(reasoningEffort ? { reasoning_effort: reasoningEffort } : {})
        }
        : {
            model,
            messages: [
                {
                    role: 'user',
                    content: prompt
                }
            ],
            max_tokens: maxTokens,
            temperature
        };
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body)
    });
    if (!response.ok) {
        let errorText = '';
        try {
            errorText = await response.text();
        }
        catch (e) {
            errorText = '';
        }
        throw new Error(`API请求失败，HTTP状态码: ${response.status}${errorText ? `，响应: ${errorText}` : ''}`);
    }
    const data = await response.json();
    const aiResponse = isAnthropicCompatible
        ? (Array.isArray(data.content)
            ? data.content
                .filter(item => item?.type === 'text' || item?.type === 'thinking')
                .map(item => item.text || item.thinking || '')
                .join('\n')
                .trim()
            : '')
        : data.choices?.[0]?.message?.content;
    if (!aiResponse) {
        throw new Error('AI响应为空');
    }
    return {
        success: true,
        response: aiResponse.trim(),
        raw: data
    };
}
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    startKeepAlive();
    if (message.type === 'CANDIDATES_COLLECTED' || message.type === 'RESUME_DATA' || message.type === 'GET_RANKING') {
        return true;
    }
    try {
        switch (message.action) {
            case 'OPEN_PLUGIN':
                void 0;
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    chrome.tabs.update(tabs[0].id, { url: 'popup/index.html' });
                });
                sendResponse({ status: 'success' });
                break;
            case 'GET_RANKING':
                fetchRankingData()
                    .then(data => {
                    sendResponse({ status: 'success', data: data });
                })
                    .catch(error => {
                    void 0;
                    sendResponse({ status: 'error', error: error.message });
                });
                return true;
            case 'AI_PROXY_REQUEST':
                proxyAIRequest(message.payload)
                    .then(result => {
                    sendResponse({
                        success: true,
                        response: result.response,
                        raw: result.raw
                    });
                })
                    .catch(error => {
                    void 0;
                    sendResponse({
                        success: false,
                        error: error.message
                    });
                });
                return true;
            case 'MATCH_SUCCESS':
                void 0;
                sendResponse({ status: 'success', received: true });
                break;
            case 'CHECK_RUNNING_SITE':
                const canStart = !runningSite || runningSite === message.site;
                sendResponse({ canStart });
                break;
            case 'SITE_STARTED':
                runningSite = message.site;
                sendResponse({ status: 'success' });
                break;
            case 'SITE_STOPPED':
                if (runningSite === message.site) {
                    runningSite = null;
                }
                sendResponse({ status: 'success' });
                break;
            case 'SITE_INITIALIZED':
                if (!runningSite) {
                    runningSite = message.site;
                }
                sendResponse({ status: 'success' });
                break;
            case 'DOWNLOAD_IMAGE':
                void 0;
                try {
                    chrome.downloads.download({
                        url: message.url,
                        filename: message.filename,
                        conflictAction: 'uniquify'
                    }, (downloadId) => {
                        if (chrome.runtime.lastError) {
                            void 0;
                            sendResponse({
                                success: false,
                                error: chrome.runtime.lastError.message
                            });
                        }
                        else {
                            void 0;
                            sendResponse({
                                success: true,
                                downloadId: downloadId
                            });
                        }
                    });
                }
                catch (error) {
                    void 0;
                    sendResponse({
                        success: false,
                        error: error.message
                    });
                }
                return true;
            case 'CAPTURE_SCREENSHOT':
                void 0;
                try {
                    chrome.tabs.captureVisibleTab(null, {
                        format: 'png',
                        quality: 50
                    }, (dataUrl) => {
                        if (chrome.runtime.lastError) {
                            void 0;
                            sendResponse({
                                success: false,
                                error: chrome.runtime.lastError.message
                            });
                        }
                        else {
                            void 0;
                            sendResponse({
                                success: true,
                                imageData: dataUrl,
                                method: 'chromeAPI'
                            });
                        }
                    });
                }
                catch (error) {
                    void 0;
                    sendResponse({
                        success: false,
                        error: error.message
                    });
                }
                return true;
            default:
                sendResponse({ status: 'unknown_message_type' });
                break;
        }
    }
    catch (error) {
        void 0;
        sendResponse({ status: 'error', error: error.message });
    }
    return true;
});
chrome.runtime.onConnect.addListener((port) => {
    void 0;
    startKeepAlive();
    port.onMessage.addListener((message) => {
        void 0;
        if (port.name === 'ai-proxy' && message?.action === 'AI_PROXY_REQUEST') {
            proxyAIRequest(message.payload)
                .then(result => {
                port.postMessage({
                    success: true,
                    response: result.response,
                    raw: result.raw,
                    requestId: message.requestId
                });
            })
                .catch(error => {
                void 0;
                port.postMessage({
                    success: false,
                    error: error.message,
                    requestId: message.requestId
                });
            });
        }
    });
    port.onDisconnect.addListener(() => {
        void 0;
    });
});
startKeepAlive();
async function filterCandidates(candidates) {
    const settings = await chrome.storage.local.get([
        'ageRange',
        'education',
        'gender',
        'keywords'
    ]);
    return candidates.filter(candidate => {
        if (settings.ageRange) {
            const { min, max } = settings.ageRange;
            if (min && candidate.age < min)
                return false;
            if (max && candidate.age > max)
                return false;
        }
        if (settings.education &&
            !settings.education.includes('不限') &&
            !settings.education.includes(candidate.education)) {
            return false;
        }
        if (settings.keywords && settings.keywords.length > 0) {
            const text = `${candidate.name} ${candidate.university}`;
            if (!settings.keywords.some(keyword => text.toLowerCase().includes(keyword.toLowerCase()))) {
                return false;
            }
        }
        return true;
    });
}
function sanitizeFilename(filename) {
    return filename
        .replace(/[<>:"/\\|?*]/g, '_')
        .replace(/\s+/g, '_')
        .replace(/\./g, '_')
        .trim();
}
