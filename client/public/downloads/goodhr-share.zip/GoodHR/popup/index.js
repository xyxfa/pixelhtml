const DEFAULT_AI_ENDPOINT = 'https://api.deepseek.com/anthropic';
const DEFAULT_AI_MODEL = 'deepseek-v4-pro';
const DEFAULT_AI_KEY = '';
const LEGACY_AI_ENDPOINTS = [
    'https://api.minimax.io/v1',
    'https://dashscope.aliyuncs.com/compatible-mode/v1'
];
const LEGACY_AI_MODELS = [
    'MiniMax-M2.7',
    'MiniMax-M2.7-highspeed',
    'qwen3.5-plus-2026-02-15'
];
const DEFAULT_REASONING_EFFORT = 'max';
const DEFAULT_POSITIONS = [{
        name: '示例岗位（请填写自己的要求）',
        description: '请在这里填写真实的岗位职责、必需技能和招聘要求。',
        keywords: [], excludeKeywords: []
    }];
const DEFAULT_HR_SETTINGS = {
    positions: DEFAULT_POSITIONS,
    currentPosition: DEFAULT_POSITIONS[0],
    isAndMode: false,
    matchLimit: 30,
    enableSound: true,
    scrollDelayMin: 2,
    scrollDelayMax: 4,
    clickFrequency: 7,
    communicationConfig: {
        collectPhone: true,
        collectResume: true,
        collectWechat: true,
        enabled: false,
        phone: false,
        resume: false,
        wechat: false
    },
    companyInfo: { content: '' },
    jobInfo: { extraInfo: '' },
    runModeConfig: {
        communicationEnabled: true,
        greetingEnabled: true
    }
};
function cloneDefaultHRSettings() {
    return JSON.parse(JSON.stringify(DEFAULT_HR_SETTINGS));
}
function shouldMigrateToMiniMax(aiConfig = {}) {
    const endpoint = (aiConfig.endpoint || '').trim();
    const model = (aiConfig.model || '').trim();
    const apiKey = (aiConfig.apiKey || aiConfig.token || '').trim();
    return !endpoint ||
        !model ||
        !apiKey ||
        LEGACY_AI_ENDPOINTS.includes(endpoint) ||
        LEGACY_AI_MODELS.includes(model);
}
function applyMiniMaxDefaults() {
    const previous = serverData.ai_config || {};
    const key = previous.apiKey || previous.token || '';
    const endpoint = previous.endpoint || DEFAULT_AI_ENDPOINT;
    serverData.ai_config = {
        ...previous, apiKey: key, token: key, endpoint,
        model: previous.model || DEFAULT_AI_MODEL,
        platform: previous.platform || (isAnthropicCompatibleEndpoint(endpoint) ? 'anthropic-compatible' : 'openai-compatible'),
        reasoningEffort: previous.reasoningEffort || DEFAULT_REASONING_EFFORT
    };
    return true;
}
const initialHRSettings = cloneDefaultHRSettings();
let serverData = {
    ai_config: {
        apiKey: DEFAULT_AI_KEY,
        token: DEFAULT_AI_KEY,
        endpoint: DEFAULT_AI_ENDPOINT,
        model: DEFAULT_AI_MODEL,
        clickPrompt: `你是一个资深的HR专家。请根据候选人的基本信息判断是否值得查看其详细信息。

重要提示：
1. 这个API仅用于岗位与候选人的筛选。如果内容不是这些，你应该返回"内容与招聘无关 无法解答"。
2. 请根据岗位要求判断是否值得查看这位候选人的详细信息。
3. 必须返回JSON格式，包含decision和reason两个字段。
4. decision字段只能是"是"或"否"。
5. reason字段是决策原因，10个字以内。
6. 如果岗位要求中包含"经验"，则必须考虑候选人的工作经验。
7. 如果岗位要求中包含"学历"，则必须考虑候选人的学历。
8. 如果岗位要求明确写了年龄、学历、经验年限、专业方向、应届/实习、行业方向等硬性条件，候选人明显不满足时必须返回"否"。
9. 如果岗位要求没有写某个条件，不要凭空添加；如果岗位写了硬性条件但候选人信息缺失或无法证明满足，应作为风险，必要时返回"否"。
10. 当前招聘方是游戏公司。请先判断岗位族，再按对应证据筛选：
   - 技术开发/TA：看 Unity/U3D/UE/Cocos、C#/Lua/C++、客户端/服务端、游戏项目/Demo、Shader/引擎/编辑器/战斗系统/性能优化/工具链/自动化测试等。
   - 策划/文案/剧情：看游戏策划案、玩法/系统/关卡/数值、世界观、剧情、角色设定、任务文本、作品集、RPG/MMO理解等。
   - 产品/PM/制作人：看游戏产品、项目管理、版本管理、需求管理、排期、跨部门协作、商业化、留存/付费/用户研究等。
   - 美术/UI/特效：看游戏美术、原画/3D/动作/动画、游戏UI/GUI、特效/VFX、作品集、Unity/UE落地等。
   - 后期/营销素材：看游戏广告素材、短视频、AE/Pr/剪映/达芬奇、动效、AI视频、小红书/投放素材、作品集等。
   - 运营/发行/市场：看游戏运营、发行、买量、投放、渠道、社区、活动、版本运营、DAU/留存/付费/ROI等。
11. 对金融、保险、销售、客服、教育、行政、人事、财务等明显非游戏/非岗位方向候选人，如果没有当前岗位族的明确匹配信号，必须返回"否"。
12. 开发、技术美术、美术/UI/特效、策划、文案/剧情、后期/营销素材等游戏内容生产岗位，候选人必须同时具备对应岗位能力和游戏行业/游戏项目/游戏内容证据。只有通用程序、通用美术、通用剪辑、通用文案、通用PM经历，不算匹配。
13. 不要把泛AI、Python、数据分析、Web、普通后端、管理系统、电商/CRM/ERP经历误判为游戏开发；也不要要求文案、PM、策划、运营、美术、后期岗位必须会游戏开发。
14. 你应该主动分析岗位信息是不是属于高要求岗位。如果是，则需要严格筛选候选人信息；如果是要求低的普通岗位，再做宽松筛选。


岗位要求：
\${岗位信息}

候选人基本信息：
\${候选人信息}

请判断是否值得查看这位候选人的详细信息，返回JSON格式：{"decision":"是","reason":"符合基本要求"}`,
    },
    positions: initialHRSettings.positions,
    currentPosition: initialHRSettings.currentPosition,
    isAndMode: initialHRSettings.isAndMode,
    matchLimit: initialHRSettings.matchLimit,
    enableSound: initialHRSettings.enableSound,
    scrollDelayMin: initialHRSettings.scrollDelayMin,
    scrollDelayMax: initialHRSettings.scrollDelayMax,
    clickFrequency: initialHRSettings.clickFrequency,
    communicationConfig: initialHRSettings.communicationConfig,
    companyInfo: initialHRSettings.companyInfo,
    jobInfo: initialHRSettings.jobInfo,
    runModeConfig: initialHRSettings.runModeConfig
};
let isRunning = false;
let matchCount = 0;
let isDownloading = false;
let downloadCount = 0;
let boundPhone = '';
let currentTab = 'ai';
const API_BASE = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.API_BASE : 'https://goodhr.58it.cn';
let adConfig = null;
async function saveLogs(logs) {
    try {
        await chrome.storage.local.set({ 'hr_assistant_logs': logs });
    }
    catch (error) {
        void 0;
    }
}
async function loadLogs() {
    try {
        const result = await chrome.storage.local.get('hr_assistant_logs');
        return result.hr_assistant_logs || [];
    }
    catch (error) {
        void 0;
        return [];
    }
}
function showError(error) {
    addLog(`错误: ${error.message}`, 'error');
    void 0;
}
async function saveSettings() {
    try {
        if (serverData.currentPosition && currentTab === 'ai') {
            const jobDescription = document.getElementById('job-description')?.value || '';
            serverData.currentPosition.description = jobDescription;
        }
        serverData.isAndMode = document.getElementById('keywords-and-mode')?.checked || false;
        serverData.matchLimit = parseInt(document.getElementById('match-limit')?.value) || 200;
        serverData.enableSound = document.getElementById('enable-sound')?.checked || true;
        serverData.scrollDelayMin = parseInt(document.getElementById('delay-min')?.value) || 3;
        serverData.scrollDelayMax = parseInt(document.getElementById('delay-max')?.value) || 5;
        serverData.clickFrequency = parseInt(document.getElementById('click-frequency')?.value) || 7;
        if (!serverData.companyInfo) {
            serverData.companyInfo = {};
        }
        serverData.companyInfo.content = document.getElementById('company-info')?.value || '';
        if (!serverData.jobInfo) {
            serverData.jobInfo = {};
        }
        serverData.jobInfo.extraInfo = document.getElementById('job-extra-info')?.value || '';
        if (!serverData.communicationConfig) {
            serverData.communicationConfig = {};
        }
        if (!serverData.runModeConfig) {
            serverData.runModeConfig = {};
        }
        serverData.runModeConfig.greetingEnabled = document.getElementById('greeting-checkbox')?.checked !== false;
        serverData.runModeConfig.communicationEnabled = document.getElementById('communication-checkbox')?.checked !== false;
        serverData.communicationConfig.collectPhone = document.querySelector('.collect-phone')?.checked || false;
        serverData.communicationConfig.collectWechat = document.querySelector('.collect-wechat')?.checked || false;
        serverData.communicationConfig.collectResume = document.querySelector('.collect-resume')?.checked || false;
        await chrome.storage.local.set({
            'hr_assistant_settings': {
                positions: serverData.positions,
                currentPosition: serverData.currentPosition,
                isAndMode: serverData.isAndMode,
                matchLimit: serverData.matchLimit,
                enableSound: serverData.enableSound,
                scrollDelayMin: serverData.scrollDelayMin,
                scrollDelayMax: serverData.scrollDelayMax,
                clickFrequency: serverData.clickFrequency,
                companyInfo: serverData.companyInfo,
                jobInfo: serverData.jobInfo,
                communicationConfig: serverData.communicationConfig,
                runModeConfig: serverData.runModeConfig
            },
            'ai_config': serverData.ai_config
        });
        addLog('设置已保存到本地', 'success');
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function (tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'SETTINGS_UPDATED',
                    data: {
                        positions: serverData.positions,
                        currentPosition: serverData.currentPosition,
                        isAndMode: serverData.isAndMode,
                        matchLimit: serverData.matchLimit,
                        enableSound: serverData.enableSound,
                        scrollDelayMin: serverData.scrollDelayMin,
                        scrollDelayMax: serverData.scrollDelayMax,
                        clickFrequency: serverData.clickFrequency,
                        keywords: serverData.currentPosition?.keywords || [],
                        excludeKeywords: serverData.currentPosition?.excludeKeywords || [],
                        companyInfo: serverData.companyInfo,
                        jobInfo: serverData.jobInfo,
                        communicationConfig: serverData.communicationConfig,
                        runModeConfig: serverData.runModeConfig
                    }
                }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                    }
                });
            }
        });
    }
    catch (error) {
        showError(error);
    }
}
function addKeywordBase() {
    const input = document.getElementById('keyword-input');
    if (!input) {
        void 0;
        addLog('⚠️ 系统错误：找不到关键词输入框', 'error');
        return;
    }
    const keyword = input.value.trim();
    if (keyword && !keywords.includes(keyword)) {
        keywords.push(keyword);
        renderKeywords();
        input.value = '';
    }
}
function removeKeyword(keyword) {
    if (!serverData.currentPosition)
        return;
    serverData.currentPosition.keywords = serverData.currentPosition.keywords.filter(k => k !== keyword);
    renderKeywords();
    saveSettings();
    if (isRunning) {
        notifyKeywordsUpdate();
    }
}
function addKeyword() {
    if (!serverData.currentPosition) {
        addLog('⚠️ 请先选择岗位', 'error');
        return;
    }
    const input = document.getElementById('keyword-input');
    if (!input) {
        void 0;
        addLog('⚠️ 系统错误：找不到关键词输入框', 'error');
        return;
    }
    const keyword = input.value.trim();
    if (keyword && !serverData.currentPosition.keywords.includes(keyword)) {
        serverData.currentPosition.keywords.push(keyword);
        renderKeywords();
        input.value = '';
        saveSettings();
        if (isRunning) {
            notifyKeywordsUpdate();
        }
    }
}
function addExcludeKeyword() {
    if (!serverData.currentPosition) {
        addLog('⚠️ 请先选择岗位', 'error');
        return;
    }
    const input = document.getElementById('keyword-input');
    if (!input) {
        void 0;
        addLog('⚠️ 系统错误：找不到关键词输入框', 'error');
        return;
    }
    const keyword = input.value.trim();
    if (keyword && !serverData.currentPosition.excludeKeywords.includes(keyword)) {
        serverData.currentPosition.excludeKeywords.push(keyword);
        renderExcludeKeywords();
        input.value = '';
        saveSettings();
        if (isRunning) {
            notifyKeywordsUpdate();
        }
    }
}
function removeExcludeKeyword(keyword) {
    if (!serverData.currentPosition)
        return;
    serverData.currentPosition.excludeKeywords = serverData.currentPosition.excludeKeywords.filter(k => k !== keyword);
    renderExcludeKeywords();
    saveSettings();
    if (isRunning) {
        notifyKeywordsUpdate();
    }
}
function renderExcludeKeywords() {
    const container = document.getElementById('exclude-keyword-list');
    if (!container) {
        throw new Error('找不到排除关键词列表容器');
    }
    container.innerHTML = '';
    const currentExcludeKeywords = serverData.currentPosition ? serverData.currentPosition.excludeKeywords : [];
    currentExcludeKeywords.forEach(keyword => {
        const keywordDiv = document.createElement('div');
        keywordDiv.className = 'keyword-tag';
        keywordDiv.style.backgroundColor = '#ffe0e0';
        keywordDiv.style.borderColor = '#ff4444';
        keywordDiv.style.color = '#ff4444';
        keywordDiv.innerHTML = `
            ${keyword}
            <button class="remove-keyword" data-keyword="${keyword}" style="color: #ff4444;">&times;</button>
        `;
        const removeButton = keywordDiv.querySelector('.remove-keyword');
        removeButton.addEventListener('click', () => {
            removeExcludeKeyword(keyword);
        });
        container.appendChild(keywordDiv);
    });
}
async function saveState() {
    await chrome.storage.local.set({
        isRunning,
        isDownloading,
        matchCount,
        downloadCount
    });
}
async function loadState() {
    try {
        const state = await new Promise((resolve) => {
            chrome.storage.local.get({
                isRunning: false,
                isDownloading: false,
                matchCount: 0,
                downloadCount: 0
            }, (result) => {
                resolve(result);
            });
        });
        isRunning = state.isRunning;
        isDownloading = state.isDownloading;
        matchCount = state.matchCount;
        downloadCount = state.downloadCount;
        updateUI();
        if (isRunning) {
            addLog(`继续运行中，已匹配 ${matchCount} 个候选人`, 'info');
        }
        if (isDownloading) {
            addLog(`继续下载中，已下载 ${downloadCount} 份简历`, 'info');
        }
    }
    catch (error) {
        void 0;
        isRunning = false;
        isDownloading = false;
        matchCount = 0;
        downloadCount = 0;
    }
}
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const version = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.VERSION : chrome.runtime.getManifest().version;
        document.getElementById('version').textContent = version;
        const savedTab = await chrome.storage.local.get('selected_tab');
        void 0;
        if (savedTab.selected_tab) {
            currentTab = savedTab.selected_tab;
        }
        else {
            currentTab = 'ai';
        }
        await initializeFromServer();
        if (serverData.ai_config && (serverData.ai_config.apiKey || serverData.ai_config.token)) {
            await loadAIConfig();
        }
        else {
            checkAIConnection();
        }
        switchTab(currentTab);
        if (serverData.currentPosition) {
            renderKeywords();
            renderExcludeKeywords();
            updateJobDescription();
        }
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.getAttribute('data-tab');
                switchTab(tabName);
            });
        });
        document.getElementById('ai-config-btn').addEventListener('click', () => {
            showAIConfigModal();
        });
        document.getElementById('ai-config-close').addEventListener('click', () => {
            hideAIConfigModal();
        });
        const aiConfigSave2 = document.getElementById('ai-config-save2');
        if (aiConfigSave2) {
            aiConfigSave2.addEventListener('click', () => {
                saveAIConfig();
            });
        }
        document.getElementById('ai-model').addEventListener('change', (e) => {
            const customModelInput = document.getElementById('ai-custom-model');
            if (e.target.value === 'custom') {
                customModelInput.style.display = 'block';
                customModelInput.focus();
            }
            else {
                customModelInput.style.display = 'none';
            }
        });
        const platformRadios = document.querySelectorAll('input[name="ai-platform"]');
        platformRadios.forEach(radio => {
            radio.addEventListener('change', function () {
                togglePlatformConfig(this.value);
            });
        });
        const aiClickPrompt = document.getElementById('ai-click-prompt');
        if (aiClickPrompt) {
            let aiPromptSaveTimeout;
            aiClickPrompt.addEventListener('input', () => {
                clearTimeout(aiPromptSaveTimeout);
                aiPromptSaveTimeout = setTimeout(async () => {
                    try {
                        serverData.ai_config.clickPrompt = document.getElementById('ai-click-prompt').value.trim();
                        await saveSettings();
                        addLog('AI提示语已自动保存', 'info');
                    }
                    catch (error) {
                        void 0;
                        addLog('自动保存AI提示语失败: ' + error.message, 'error');
                    }
                }, 1000);
            });
        }
        const logs = await loadLogs();
        const logContainer = document.getElementById('log-container');
        logContainer.innerHTML = '';
        logs.forEach(log => {
            const logEntry = document.createElement('div');
            logEntry.className = 'log-entry';
            logEntry.style.display = 'flex';
            logEntry.innerHTML = log.html;
            logContainer.appendChild(logEntry);
        });
        if (logs.length === 0) {
            const logEntry = document.createElement('div');
            logEntry.className = 'log-entry';
            logEntry.style.display = 'flex';
            logEntry.innerHTML = `
				<span style="color: #666; margin-right: 8px;">></span>
				<span>系统就绪，等待开始...</span>
			`;
            logContainer.appendChild(logEntry);
        }
        await loadState();
        const settings = await getSettings();
        const matchLimitInput = document.getElementById('match-limit');
        const enableSoundCheckbox = document.getElementById('enable-sound');
        const delayMinInput = document.getElementById('delay-min');
        const delayMaxInput = document.getElementById('delay-max');
        document.getElementById('ageMin')?.addEventListener('change', saveSettings);
        document.getElementById('ageMax')?.addEventListener('change', saveSettings);
        document.querySelectorAll('input[id^="edu-"]').forEach(checkbox => {
            checkbox.addEventListener('change', saveSettings);
        });
        document.querySelectorAll('input[id^="gender-"]').forEach(checkbox => {
            checkbox.addEventListener('change', saveSettings);
        });
        const keywordInput = document.getElementById('keyword-input');
        const addKeywordBtn = document.getElementById('add-keyword');
        const addExcludeKeywordBtn = document.getElementById('add-exclude-keyword');
        const positionInput = document.getElementById('position-input');
        const addPositionBtn = document.getElementById('add-position');
        const collectPhoneCheckboxes = document.querySelectorAll('.collect-phone');
        const collectWechatCheckboxes = document.querySelectorAll('.collect-wechat');
        const collectResumeCheckboxes = document.querySelectorAll('.collect-resume');
        collectPhoneCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                document.querySelectorAll('.collect-phone').forEach(cb => {
                    cb.checked = e.target.checked;
                });
                saveSettings();
            });
        });
        collectWechatCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                document.querySelectorAll('.collect-wechat').forEach(cb => {
                    cb.checked = e.target.checked;
                });
                saveSettings();
            });
        });
        collectResumeCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                document.querySelectorAll('.collect-resume').forEach(cb => {
                    cb.checked = e.target.checked;
                });
                saveSettings();
            });
        });
        if (!keywordInput || !addKeywordBtn || !addExcludeKeywordBtn || !positionInput || !addPositionBtn) {
            void 0;
            addLog('⚠️ 系统错误：界面初始化失败', 'error');
            return;
        }
        keywordInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                addKeyword();
            }
        });
        positionInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                addPosition();
            }
        });
        addKeywordBtn.addEventListener('click', () => addKeyword());
        addExcludeKeywordBtn.addEventListener('click', () => addExcludeKeyword());
        addPositionBtn.addEventListener('click', () => addPosition());
        const andModeCheckbox = document.getElementById('keywords-and-mode');
        if (settings.isAndMode !== undefined) {
            isAndMode = settings.isAndMode;
            andModeCheckbox.checked = isAndMode;
        }
        andModeCheckbox.addEventListener('change', (e) => {
            isAndMode = e.target.checked;
            saveSettings();
            addLog(`关键词匹配模式: ${isAndMode ? '全部匹配' : '任一匹配'}`, 'info');
        });
        if (settings.keywords && settings.keywords.length > 0) {
            keywords = settings.keywords;
            renderKeywords();
            addLog(`已加载 ${keywords.length} 个关键词`, 'info');
        }
        if (settings.excludeKeywords && settings.excludeKeywords.length > 0) {
            excludeKeywords = settings.excludeKeywords;
            renderExcludeKeywords();
            addLog(`已加载 ${excludeKeywords.length} 个排除关键词`, 'info');
        }
        if (settings.matchLimit !== undefined) {
            matchLimit = settings.matchLimit;
            matchLimitInput.value = matchLimit;
        }
        if (settings.scrollDelayMin !== undefined) {
            scrollDelayMin = settings.scrollDelayMin;
            delayMinInput.value = scrollDelayMin;
        }
        if (settings.scrollDelayMax !== undefined) {
            scrollDelayMax = settings.scrollDelayMax;
            delayMaxInput.value = scrollDelayMax;
        }
        if (settings.enableSound !== undefined) {
            enableSound = settings.enableSound;
            enableSoundCheckbox.checked = enableSound;
        }
        matchLimitInput.addEventListener('change', () => {
            matchLimit = parseInt(matchLimitInput.value) || 10;
            saveSettings();
            addLog(`设置匹配暂停数量: ${matchLimit}`, 'info');
        });
        const aiOptimizeBtn = document.getElementById('ai-optimize-job-description');
        if (aiOptimizeBtn) {
            aiOptimizeBtn.addEventListener('click', async () => {
                await optimizeJobDescriptionWithAI();
            });
        }
        enableSoundCheckbox.addEventListener('change', (e) => {
            enableSound = e.target.checked;
            saveSettings();
            addLog(`${enableSound ? '启用' : '禁用'}提示音`, 'info');
        });
        if (settings.positions) {
            positions = settings.positions;
            renderPositions();
            if (settings.currentPosition) {
                selectPosition(settings.currentPosition);
            }
        }
        setTimeout(() => {
            updateJobDescription();
        }, 100);
        document.getElementById('position-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addPosition();
            }
        });
        document.getElementById('add-position')?.addEventListener('click', addPosition);
        document.getElementById('ai-position-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addPosition();
            }
        });
        document.getElementById('ai-add-position')?.addEventListener('click', addPosition);
        document.getElementById('job-description')?.addEventListener('input', () => {
            if (serverData.currentPosition) {
                serverData.currentPosition.description = document.getElementById('job-description').value;
                saveSettings();
            }
        });
        document.getElementById('scrollButton')?.addEventListener('click', () => {
            startAutoScroll();
        });
        document.getElementById('downloadButton')?.addEventListener('click', () => {
            alert("出于安全考虑,该功能已禁止使用");
            return;
            startDownload();
        });
        document.getElementById('stopButton')?.addEventListener('click', () => {
            if (isRunning) {
                stopAutoScroll();
            }
            if (isDownloading) {
                stopDownload();
            }
        });
        updateJobDescription();
        addLog('设置加载完成', 'success');
        delayMinInput.addEventListener('change', saveSettings);
        delayMaxInput.addEventListener('change', saveSettings);
        const clickFrequencyInput = document.getElementById('click-frequency');
        if (settings.clickFrequency !== undefined) {
            clickFrequencyInput.value = settings.clickFrequency;
        }
        clickFrequencyInput?.addEventListener('change', saveSettings);
    }
    catch (error) {
        showError(error);
    }
});
async function getSettings() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get([
            'positions',
            'currentPosition',
            'isAndMode',
            'matchLimit',
            'enableSound',
            'scrollDelayMin',
            'scrollDelayMax',
            'clickFrequency'
        ], (result) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
                return;
            }
            resolve(result);
        });
    });
}
async function startAutoScroll() {
    if (!serverData.currentPosition) {
        addLog('⚠️ 请先选择岗位', 'error');
        isRunning = false;
        updateUI();
        return;
    }
    if (isRunning)
        return;
    try {
        isRunning = true;
        matchCount = 0;
        updateUI();
        const storageData = {
            isRunning: true
        };
        await chrome.storage.local.set(storageData);
        const matchLimitInput = document.getElementById('match-limit');
        matchLimit = parseInt(matchLimitInput.value) || 200;
        const delayMinInput = document.getElementById('delay-min');
        const delayMaxInput = document.getElementById('delay-max');
        const clickFrequencyInput = document.getElementById('click-frequency');
        const enableSoundCheckbox = document.getElementById('enable-sound');
        if (currentTab === 'ai') {
            applyMiniMaxDefaults(true);
            addLog('开始智能筛选...', 'info');
            addLog(`设置暂停数量: ${matchLimit}`, 'info');
            addLog(`随机延迟时间: ${delayMinInput.value}-${delayMaxInput.value}秒`, 'info');
            chrome.tabs.query({
                active: true,
                currentWindow: true
            }, tabs => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'START_AI_SCROLL',
                        data: {
                            positionName: serverData.currentPosition.name,
                            jobDescription: serverData.currentPosition.description,
                            keywords: serverData.currentPosition.keywords || [],
                            excludeKeywords: serverData.currentPosition.excludeKeywords || [],
                            aiConfig: serverData.ai_config,
                            matchLimit: serverData.matchLimit,
                            scrollDelayMin: parseInt(delayMinInput.value) || 3,
                            scrollDelayMax: parseInt(delayMaxInput.value) || 5,
                            clickFrequency: parseInt(clickFrequencyInput.value) || 7,
                            enableSound: enableSoundCheckbox.checked,
                            communicationConfig: serverData.communicationConfig
                        }
                    }, response => {
                        if (chrome.runtime.lastError) {
                            void 0;
                            addLog('⚠️ 无法连接到页面，请刷新页面', 'error');
                            isRunning = false;
                            updateUI();
                            return;
                        }
                        void 0;
                    });
                }
            });
        }
        else {
            if (!serverData.currentPosition.keywords.length && !serverData.currentPosition.excludeKeywords.length) {
                if (!confirm('当前岗位没有设置任何关键词，将按当前页面候选人继续处理，是否继续？')) {
                    return;
                }
                addLog('⚠️ 当前未设置关键词，将按页面候选人继续处理', 'warning');
            }
            addLog('开始基础筛选...', 'info');
            addLog(`设置暂停数量: ${serverData.matchLimit}`, 'info');
            addLog(`随机延迟时间: ${delayMinInput.value}-${delayMaxInput.value}秒`, 'info');
            chrome.tabs.query({
                active: true,
                currentWindow: true
            }, tabs => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'START_SCROLL',
                        data: {
                            keywords: serverData.currentPosition.keywords,
                            excludeKeywords: serverData.currentPosition.excludeKeywords,
                            isAndMode: serverData.isAndMode,
                            matchLimit: serverData.matchLimit,
                            scrollDelayMin: parseInt(delayMinInput.value) || 3,
                            scrollDelayMax: parseInt(delayMaxInput.value) || 5,
                            clickFrequency: parseInt(clickFrequencyInput.value) || 7,
                            enableSound: enableSoundCheckbox.checked,
                            communicationConfig: serverData.communicationConfig
                        }
                    }, response => {
                        if (chrome.runtime.lastError) {
                            void 0;
                            addLog('⚠️ 无法连接到页面，请刷新页面', 'error');
                            updateUI();
                            return;
                        }
                        void 0;
                    });
                }
            });
        }
        await saveState();
    }
    catch (error) {
        void 0;
        isRunning = false;
        updateUI();
        addLog('启动失败: ' + error.message, 'error');
    }
}
async function stopAutoScroll() {
    if (!isRunning)
        return;
    try {
        isRunning = false;
        updateUI();
        addLog(`停止自动滚动，当前已匹配 ${matchCount} 个候选人`, 'warning');
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, tabs => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'STOP_SCROLL'
                }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                        return;
                    }
                    void 0;
                });
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'REMOVE_ADS'
                }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                    }
                });
            }
        });
        await chrome.storage.local.set({
            isRunning: false
        });
    }
    catch (error) {
        void 0;
        addLog('停止失败: ' + error.message, 'error');
    }
    finally {
        matchCount = 0;
        isRunning = false;
        updateUI();
    }
}
function updateUI() {
    const initialButtons = document.getElementById('initialButtons');
    const stopButtons = document.getElementById('stopButtons');
    if (isRunning || isDownloading) {
        initialButtons.classList.add('hidden');
        stopButtons.classList.remove('hidden');
    }
    else {
        initialButtons.classList.remove('hidden');
        stopButtons.classList.add('hidden');
    }
}
function renderKeywords() {
    const container = document.getElementById('keyword-list');
    if (!container) {
        throw new Error('找不到关键词列表容器');
    }
    container.innerHTML = '';
    const currentKeywords = serverData.currentPosition ? serverData.currentPosition.keywords : [];
    currentKeywords.forEach(keyword => {
        const keywordDiv = document.createElement('div');
        keywordDiv.className = 'keyword-tag';
        keywordDiv.innerHTML = `
            ${keyword}
            <button class="remove-keyword" data-keyword="${keyword}">&times;</button>
        `;
        const removeButton = keywordDiv.querySelector('.remove-keyword');
        removeButton.addEventListener('click', () => {
            removeKeyword(keyword);
        });
        container.appendChild(keywordDiv);
    });
}
async function addLog(message, type = 'info') {
    const logContainer = document.getElementById('log-container');
    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';
    logEntry.style.display = 'flex';
    const timestamp = new Date().toLocaleTimeString('zh-CN', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    let color = '#00ff00';
    let prefix = '>';
    switch (type) {
        case 'error':
            color = '#ff4444';
            prefix = '!';
            break;
        case 'warning':
            color = '#ffaa00';
            prefix = '?';
            break;
        case 'success':
            color = '#00ff00';
            prefix = '√';
            break;
        case 'info':
            color = '#00ff00';
            prefix = '>';
            break;
    }
    const logHtml = `
        <span style="color: #666;font-size: 10px; margin-right: 8px;">${prefix}</span>
        <span style="color: ${color};font-size: 10px;">[${timestamp}] ${message}</span>
    `;
    logEntry.innerHTML = logHtml;
    logContainer.appendChild(logEntry);
    const parentContainer = logContainer.parentElement;
    parentContainer.scrollTop = parentContainer.scrollHeight;
    try {
        const logs = await loadLogs();
        logs.push({
            message,
            type,
            timestamp,
            html: logHtml
        });
        if (logs.length > 100) {
            logs.splice(0, logs.length - 100);
        }
        await saveLogs(logs);
    }
    catch (error) {
        void 0;
    }
}
chrome.runtime.sendMessage({ message: "hello" }, function (response) {
    void 0;
});
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === 'CHECK_AI_EXPIRATION') {
        sendResponse({ expired: false });
        return true;
    }
    if (message.type === 'MATCH_SUCCESS') {
        const { name, age, education, university, extraInfo, clicked } = message.data;
        matchCount++;
        let logText = ` [${matchCount}] ${name} `;
        if (extraInfo && extraInfo.length > 0) {
            const extraInfoText = extraInfo
                .map(info => `${info.type}: ${info.value}`)
                .join(' | ');
            logText += ` | ${extraInfoText}`;
        }
        if (clicked) {
            logText += ' [已点击]';
        }
        addLog(logText, 'success');
        if (serverData.enableSound) {
            const audio = new Audio(chrome.runtime.getURL('sounds/notification2.mp3'));
            audio.volume = 0.5;
            audio.play().catch(error => void 0);
        }
        if (matchCount >= matchLimit) {
            stopAutoScroll();
            addLog(`已达到设定的暂停数量 ${matchLimit}，自动停止`, 'warning');
            if (serverData.enableSound) {
                const audio = new Audio(chrome.runtime.getURL('sounds/error.mp3'));
                audio.volume = 0.5;
                audio.play().catch(error => void 0);
            }
        }
        await saveState();
    }
    else if (message.type === 'SCROLL_COMPLETE') {
        isRunning = false;
        await saveState();
        updateUI();
        addLog(`滚动完成，共匹配 ${matchCount} 个候选人`, 'success');
        matchCount = 0;
    }
    else if (message.type === 'LOG_MESSAGE') {
        addLog(message.data.message, message.data.type);
    }
    else if (message.type === 'ERROR') {
        addLog(message.error, 'error');
    }
});
function playNotificationSound() {
    const audio = new Audio(chrome.runtime.getURL('sounds/notification2.mp3'));
    audio.volume = 0.5;
    audio.play().catch(error => void 0);
}
const VERSION_API = `${API_BASE}/v.json?t=${Date.now()}`;
const CURRENT_VERSION = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.VERSION : chrome.runtime.getManifest().version;
let NEW_VERSION = "0";
let GONGGAO = null;
async function checkVersion() {
    try {
        const response = await fetch(`${VERSION_API}&_=${Date.now()}`);
        const data = await response.json();
        NEW_VERSION = data.version;
        GONGGAO = data.gonggao;
        return {
            needUpdate: data.version !== CURRENT_VERSION,
            releaseNotes: data.releaseNotes
        };
    }
    catch (error) {
        void 0;
        return {
            needUpdate: false
        };
    }
}
async function checkForUpdates() {
    return;
}
function addPosition() {
    const freeInput = document.getElementById('position-input');
    const aiInput = document.getElementById('ai-position-input');
    void 0;
    let input = null;
    if (currentTab == 'ai') {
        void 0;
        input = aiInput;
    }
    else {
        void 0;
        input = freeInput;
    }
    void 0;
    if (!input) {
        addLog('找不到岗位输入框', 'error');
        return;
    }
    const positionName = input.value;
    void 0;
    if (positionName && !serverData.positions.find(p => p.name === positionName)) {
        const newPosition = {
            name: positionName,
            keywords: [],
            excludeKeywords: [],
            description: ''
        };
        serverData.positions.push(newPosition);
        renderPositions();
        input.value = '';
        saveSettings();
        selectPosition(positionName);
        addLog(`已添加岗位：${positionName}`, 'success');
    }
    else if (positionName && serverData.positions.find(p => p.name === positionName)) {
        addLog('该岗位已存在', 'error');
    }
    else if (!positionName) {
        addLog('请输入岗位名称', 'error');
    }
}
function removePosition(positionName) {
    if (confirm(`确定要删除职位"${positionName}"吗？\n删除后该职位的所有关键词都将被删除。`)) {
        serverData.positions = serverData.positions.filter(p => p.name !== positionName);
        if (serverData.currentPosition?.name === positionName) {
            serverData.currentPosition = null;
        }
        renderPositions();
        renderKeywords();
        renderExcludeKeywords();
        saveSettings();
    }
}
function selectPosition(positionName) {
    serverData.currentPosition = serverData.positions.find(p => p.name === positionName);
    renderKeywords();
    renderExcludeKeywords();
    renderPositions();
    updateJobDescription();
    saveSettings();
}
function updateJobDescription() {
    const jobDescriptionTextarea = document.getElementById('job-description');
    const jobDescriptionGroup = document.getElementById('ai-job-description-group');
    if (currentTab === 'ai' && serverData.currentPosition && jobDescriptionGroup) {
        jobDescriptionGroup.style.display = 'block';
        if (jobDescriptionTextarea) {
            jobDescriptionTextarea.value = serverData.currentPosition.description || '';
        }
    }
    else {
        if (jobDescriptionGroup) {
            jobDescriptionGroup.style.display = 'none';
        }
        if (jobDescriptionTextarea) {
            jobDescriptionTextarea.value = '';
        }
    }
}
function renderPositions() {
    const container = document.getElementById('position-list');
    if (container) {
        container.innerHTML = '';
        serverData.positions.forEach(position => {
            const positionDiv = document.createElement('div');
            positionDiv.className = `position-tag ${serverData.currentPosition?.name === position.name ? 'active' : ''}`;
            positionDiv.innerHTML = `
				${position.name}
				<button class="remove-btn" data-position="${position.name}">&times;</button>
			`;
            positionDiv.querySelector('button').addEventListener('click', (e) => {
                e.stopPropagation();
                removePosition(position.name);
            });
            positionDiv.addEventListener('click', () => {
                selectPosition(position.name);
            });
            container.appendChild(positionDiv);
        });
        if (serverData.positions.length === 0) {
            const emptyTip = document.createElement('div');
            emptyTip.style.cssText = 'color: #999; font-size: 12px; padding: 4px;';
            emptyTip.textContent = '请添加职位...';
            container.appendChild(emptyTip);
        }
    }
    const aiContainer = document.getElementById('ai-position-list');
    if (aiContainer) {
        aiContainer.innerHTML = '';
        serverData.positions.forEach(position => {
            const positionDiv = document.createElement('div');
            positionDiv.className = `position-tag ${serverData.currentPosition?.name === position.name ? 'active' : ''}`;
            positionDiv.innerHTML = `
				${position.name}
				<button class="remove-btn" data-position="${position.name}">&times;</button>
			`;
            positionDiv.querySelector('button').addEventListener('click', (e) => {
                e.stopPropagation();
                removePosition(position.name);
            });
            positionDiv.addEventListener('click', () => {
                selectPosition(position.name);
            });
            aiContainer.appendChild(positionDiv);
        });
        if (serverData.positions.length === 0) {
            const emptyTip = document.createElement('div');
            emptyTip.style.cssText = 'color: #999; font-size: 12px; padding: 4px;';
            emptyTip.textContent = '请添加职位...';
            aiContainer.appendChild(emptyTip);
        }
    }
}
function notifyKeywordsUpdate() {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, tabs => {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'UPDATE_KEYWORDS',
                data: {
                    keywords: serverData.currentPosition.keywords,
                    excludeKeywords: serverData.currentPosition.excludeKeywords,
                    isAndMode: serverData.isAndMode
                }
            }, response => {
                if (chrome.runtime.lastError) {
                    void 0;
                }
            });
        }
    });
}
async function startDownload() {
    if (isDownloading)
        return;
    try {
        isDownloading = true;
        downloadCount = 0;
        updateUI();
        addLog('开始下载简历...', 'info');
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, tabs => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { action: 'START_DOWNLOAD' }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                        addLog('⚠️ 无法连接到页面，请刷新页面', 'error');
                        isDownloading = false;
                        updateUI();
                        return;
                    }
                });
            }
        });
        await saveState();
    }
    catch (error) {
        void 0;
        isDownloading = false;
        updateUI();
        addLog('启动下载失败: ' + error.message, 'error');
    }
}
async function stopDownload() {
    if (!isDownloading)
        return;
    try {
        isDownloading = false;
        updateUI();
        addLog(`停止下载，共下载 ${downloadCount} 份简历`, 'warning');
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, tabs => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'STOP_DOWNLOAD'
                });
            }
        });
        await saveState();
    }
    catch (error) {
        void 0;
        addLog('停止下载失败: ' + error.message, 'error');
    }
}
async function loadRankingData() {
    try {
        void 0;
        fetchRankingData()
            .then(data => {
            renderRankingList(data);
        })
            .catch(error => {
            void 0;
            sendResponse({ status: 'error', error: error.message });
        });
    }
    catch (error) {
        void 0;
    }
}
async function fetchRankingData() {
    try {
        const response = await fetch(`${API_BASE}/dashang.json?t=${Date.now()}`);
        const data = await response.json();
        return data;
    }
    catch (error) {
        void 0;
        return [];
    }
}
function renderRankingList(data) {
    void 0;
    const container = document.getElementById('ranking-list');
    if (!container)
        return;
    if (!Array.isArray(data) || data.length === 0) {
        container.innerHTML = '<div class="ranking-item" style="text-align: center; color: #666;">暂无打赏数据</div>';
        return;
    }
    container.innerHTML = data.map((item, index) => `
		<div class="ranking-item">
			<div class="ranking-number">${index + 1}</div>
			<div class="ranking-info">
				<div class="ranking-name">${item.name || '匿名用户'}</div>
				<div class="ranking-desc">${item.describe || '无留言'}</div>
			</div>
			<div class="ranking-price">￥${item.price || 0}</div>
		</div>
	`).join('');
}
async function checkDeviceAITrialStatus() {
    return {
        used: false,
        hasAccess: true,
        associatedPhone: null
    };
}
function isUsingExternalAI() {
    const aiConfig = serverData.ai_config || {};
    return !!((aiConfig.platform === 'openai-compatible' || aiConfig.endpoint) &&
        (aiConfig.apiKey || aiConfig.token));
}
function checkAIExpiration() {
    return false;
}
async function checkAIAvailability() {
    return true;
}
async function initializeAIExpireTime() {
    return;
}
function updateAIExpireDisplay() {
    const expireText = document.getElementById('ai-expire-text');
    if (!expireText) {
        return;
    }
    expireText.textContent = '';
}
async function setAIExpireTime() {
    return;
}
async function loadAIExpireTime() {
    updateAIExpireDisplay();
}
async function bindPhone(phone) {
    throw new Error('账号同步已移除');
}
async function syncSettingsFromServer() {
    return false;
}
async function switchTab(tabName) {
    currentTab = tabName;
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`).classList.add('active');
    const scrollButton = document.getElementById('scrollButton');
    if (tabName === 'ai') {
        scrollButton.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
            </svg>
            智能筛选
        `;
        updateJobDescription();
        updateAIExpireDisplay();
        if (serverData.ai_config.apiKey || serverData.ai_config.token) {
            handleBalanceCheck();
        }
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, tabs => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'SET_AI_MODE',
                    data: {
                        aiMode: true
                    }
                }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                    }
                });
            }
        });
    }
    else {
        scrollButton.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
            </svg>
            开始筛选
        `;
        const jobDescriptionGroup = document.getElementById('ai-job-description-group');
        if (jobDescriptionGroup) {
            jobDescriptionGroup.style.display = 'none';
        }
        hideBalanceDisplay();
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, tabs => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'SET_AI_MODE',
                    data: {
                        aiMode: false
                    }
                }, response => {
                    if (chrome.runtime.lastError) {
                        void 0;
                    }
                });
            }
        });
    }
    await chrome.storage.local.set({ 'selected_tab': tabName });
    addLog(`切换到${tabName === 'ai' ? '智能筛选' : '基础筛选'}`, 'info');
}
document.addEventListener('DOMContentLoaded', async () => {
    const savedTab = await chrome.storage.local.get('selected_tab');
    if (savedTab.selected_tab) {
        switchTab(savedTab.selected_tab);
    }
    const settings = await getSettings();
    if (settings.currentPosition) {
        await new Promise(resolve => setTimeout(resolve, 100));
        const targetPosition = serverData.positions.find(p => p.name === settings.currentPosition);
        if (targetPosition) {
            selectPosition(settings.currentPosition);
        }
    }
});
async function selectPosition(positionName) {
    if (!serverData.positions || serverData.positions.length === 0) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    serverData.currentPosition = serverData.positions.find(p => p.name === positionName);
    if (!serverData.currentPosition) {
        void 0;
        return;
    }
    renderKeywords();
    renderExcludeKeywords();
    renderPositions();
    updateJobDescription();
    await saveSettings();
}
async function loadAIConfig() {
    try {
        applyMiniMaxDefaults(true);
        if (serverData.ai_config && (serverData.ai_config.apiKey || serverData.ai_config.token)) {
            void 0;
            updateAIConfigUI();
            checkAIConnection();
            return;
        }
        const result = await chrome.storage.local.get('ai_config');
        if (result.ai_config) {
            serverData.ai_config = { ...serverData.ai_config, ...result.ai_config };
            void 0;
            updateAIConfigUI();
        }
        checkAIConnection();
    }
    catch (error) {
        void 0;
    }
}
function updateAIConfigUI() {
    document.getElementById('ai-api-key').value = serverData.ai_config.apiKey || serverData.ai_config.token || '';
    document.getElementById('ai-endpoint').value = serverData.ai_config.endpoint || DEFAULT_AI_ENDPOINT;
    serverData.ai_config.reasoningEffort = serverData.ai_config.reasoningEffort || DEFAULT_REASONING_EFFORT;
    const modelSelect = document.getElementById('ai-model');
    const customModelInput = document.getElementById('ai-custom-model');
    const presetModels = [
        'deepseek-v4-pro',
        'deepseek-v4-flash',
        'MiniMax-M2.5',
        'MiniMax-M2.7',
        'MiniMax-M2.7-highspeed',
        'glm-5',
        'qwen3.5-plus-2026-02-15',
        'Qwen/Qwen2.5-7B-Instruct',
        'THUDM/GLM-4.1V-9B-Thinking',
        'Qwen/Qwen3-8B',
        'deepseek-ai/DeepSeek-R1',
        'deepseek-ai/DeepSeek-V3',
        'deepseek-ai/DeepSeek-V3.1-Terminus',
        'moonshotai/Kimi-K2-Instruct-0905',
    ];
    if (presetModels.includes(serverData.ai_config.model)) {
        modelSelect.value = serverData.ai_config.model;
        customModelInput.style.display = 'none';
    }
    else {
        modelSelect.value = 'custom';
        customModelInput.value = serverData.ai_config.model || '';
        customModelInput.style.display = 'block';
    }
    document.getElementById('ai-click-prompt').value = serverData.ai_config.clickPrompt || '';
    updateAIExpireDisplay();
}
function showAIConfigModal() {
    document.getElementById('ai-config-modal').style.display = 'block';
    updateAIConfigUI();
}
function hideAIConfigModal() {
    document.getElementById('ai-config-modal').style.display = 'none';
}
function togglePlatformConfig() {
    const siliconflowConfig = document.getElementById('siliconflow-config');
    const volcengineConfig = document.getElementById('volcengine-config');
    siliconflowConfig.style.display = 'block';
    volcengineConfig.style.display = 'none';
}
async function saveAIConfig() {
    try {
        serverData.ai_config.platform = isAnthropicCompatibleEndpoint(document.getElementById('ai-endpoint').value.trim() || DEFAULT_AI_ENDPOINT)
            ? 'anthropic-compatible'
            : 'openai-compatible';
        serverData.ai_config.apiKey = document.getElementById('ai-api-key').value.trim();
        serverData.ai_config.token = serverData.ai_config.apiKey;
        serverData.ai_config.endpoint = document.getElementById('ai-endpoint').value.trim() || DEFAULT_AI_ENDPOINT;
        serverData.ai_config.reasoningEffort = DEFAULT_REASONING_EFFORT;
        const modelSelect = document.getElementById('ai-model');
        const customModelInput = document.getElementById('ai-custom-model');
        if (modelSelect.value === 'custom') {
            serverData.ai_config.model = customModelInput.value.trim();
        }
        else {
            serverData.ai_config.model = modelSelect.value;
        }
        if (!serverData.ai_config.clickPrompt.includes('${候选人信息}') || !serverData.ai_config.clickPrompt.includes('${岗位信息}')) {
            throw new Error('查看候选人详情提示语必须包含${候选人信息}和${岗位信息}标记符');
        }
        if (!serverData.ai_config.clickPrompt.includes('JSON') && !serverData.ai_config.clickPrompt.includes('json')) {
            void 0;
        }
        if (!serverData.ai_config.apiKey) {
            throw new Error('请输入外部 AI API Key');
        }
        if (!serverData.ai_config.model) {
            throw new Error('请输入模型名称');
        }
        serverData.ai_config.clickPrompt = document.getElementById('ai-click-prompt').value.trim();
        serverData.ai_config.contactPrompt = null;
        await saveSettings();
        hideAIConfigModal();
        checkAIConnection();
        if (currentTab === 'ai' && (serverData.ai_config.apiKey || serverData.ai_config.token)) {
            handleBalanceCheck();
        }
    }
    catch (error) {
        addLog('保存AI配置失败: ' + error.message, 'error');
    }
}
async function checkAIConnection() {
    const statusIndicator = document.getElementById('ai-status-indicator');
    const statusText = document.getElementById('ai-status-text');
    if (!(serverData.ai_config.apiKey || serverData.ai_config.token) || !serverData.ai_config.model) {
        statusIndicator.className = 'ai-status-indicator disconnected';
        statusText.textContent = '未配置';
        hideBalanceDisplay();
        return;
    }
    if (serverData.ai_config.apiKey || serverData.ai_config.token) {
        try {
            statusIndicator.className = 'ai-status-indicator';
            statusText.textContent = '连接中...';
            const testPrompt = '你好，这是一个连接测试。请回复"连接成功"。';
            const result = await sendDirectAIRequest(testPrompt);
            if (result.success) {
                statusIndicator.className = 'ai-status-indicator connected';
                statusText.textContent = '已连接';
                handleBalanceCheck();
            }
            else {
                statusIndicator.className = 'ai-status-indicator disconnected';
                statusText.textContent = '连接失败: ' + result.error;
                hideBalanceDisplay();
            }
        }
        catch (error) {
            statusIndicator.className = 'ai-status-indicator disconnected';
            statusText.textContent = '连接失败';
            void 0;
            hideBalanceDisplay();
        }
    }
    else {
        statusIndicator.className = 'ai-status-indicator disconnected';
        statusText.textContent = '请填写外部 API Key';
        hideBalanceDisplay();
        void 0;
    }
}
const GUJJI_API_CONFIG = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.GUJJI_API : {
    baseUrl: 'https://api.siliconflow.cn/v1/chat/completions',
    maxTokens: 100,
    temperature: 0.1
};
function buildChatCompletionsUrl(endpoint) {
    const trimmed = (endpoint || '').trim().replace(/\/+$/, '');
    if (!trimmed) {
        return GUJJI_API_CONFIG.baseUrl;
    }
    if (trimmed.endsWith('/chat/completions')) {
        return trimmed;
    }
    return `${trimmed}/chat/completions`;
}
function isSiliconFlowEndpoint(endpoint) {
    return /siliconflow\.cn/i.test(endpoint || '');
}
async function checkSiliconFlowBalance() {
    try {
        const apiKey = serverData.ai_config.apiKey || serverData.ai_config.token;
        const endpoint = serverData.ai_config.endpoint || '';
        if (!apiKey || !isSiliconFlowEndpoint(endpoint)) {
            return { success: false, error: '未配置API Token' };
        }
        const response = await fetch('https://api.siliconflow.cn/v1/user/info', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) {
            throw new Error(`API请求失败，HTTP状态码: ${response.status}`);
        }
        const data = await response.json();
        if (data.code === 20000 && data.status) {
            const balance = parseFloat(data.data.totalBalance) || 0;
            return {
                success: true,
                balance: balance,
                userInfo: data.data
            };
        }
        else {
            throw new Error(data.message || 'API响应异常');
        }
    }
    catch (error) {
        void 0;
        return {
            success: false,
            error: error.message
        };
    }
}
async function handleBalanceCheck() {
    try {
        if (!isSiliconFlowEndpoint(serverData.ai_config.endpoint || '')) {
            hideBalanceDisplay();
            return;
        }
        addLog('检查轨迹流动账号余额...', 'info');
        const result = await checkSiliconFlowBalance();
        if (result && result.success) {
            const balance = result.balance;
            addLog(`账号余额: ¥${balance.toFixed(2)}`, 'info');
            updateBalanceDisplay(balance);
            if (balance < 1) {
                const message = `当前服务商账户余额不足1元（当前余额: ¥${balance.toFixed(2)}），部分模型可能无法正常调用。\n\n是否现在打开服务商充值页面？`;
                if (confirm(message)) {
                    chrome.tabs.create({ url: 'https://cloud.siliconflow.cn/account/billing' });
                }
                addLog('服务商余额较低，建议及时补充额度', 'warning');
            }
            else {
                addLog('余额充足，可正常使用', 'success');
            }
        }
        else {
            addLog(`余额检查失败: ${result ? result.error : '未知错误'}`, 'error');
            hideBalanceDisplay();
        }
    }
    catch (error) {
        void 0;
        addLog(`余额检查异常: ${error.message}`, 'error');
        hideBalanceDisplay();
    }
}
function updateBalanceDisplay(balance) {
    const balanceInfo = document.getElementById('ai-balance-info');
    const balanceText = document.getElementById('ai-balance-text');
    if (balanceInfo && balanceText) {
        balanceText.textContent = `服务商余额: ¥${balance.toFixed(2)}`;
        if (balance < 1) {
            balanceText.style.color = '#ff4444';
        }
        else if (balance < 5) {
            balanceText.style.color = '#ff9800';
        }
        else {
            balanceText.style.color = '#4caf50';
        }
        balanceInfo.style.display = 'block';
    }
}
function hideBalanceDisplay() {
    const balanceInfo = document.getElementById('ai-balance-info');
    if (balanceInfo) {
        balanceInfo.style.display = 'none';
    }
}
function isAnthropicCompatibleEndpoint(endpoint) {
    return /\/anthropic(\/|$)/i.test(endpoint || '') || /\/messages$/i.test(endpoint || '');
}
function buildAIRequestUrl(endpoint, platform) {
    const trimmed = (endpoint || '').trim().replace(/\/+$/, '');
    if (!trimmed) {
        return isAnthropicCompatibleEndpoint(DEFAULT_AI_ENDPOINT)
            ? `${DEFAULT_AI_ENDPOINT.replace(/\/+$/, '')}/messages`
            : buildChatCompletionsUrl(DEFAULT_AI_ENDPOINT);
    }
    if (platform === 'anthropic-compatible' || isAnthropicCompatibleEndpoint(trimmed)) {
        return trimmed.endsWith('/messages') ? trimmed : `${trimmed}/messages`;
    }
    return buildChatCompletionsUrl(trimmed);
}
async function sendDirectAIRequest(prompt) {
    try {
        const platform = serverData.ai_config.platform || (isAnthropicCompatibleEndpoint(serverData.ai_config.endpoint) ? 'anthropic-compatible' : 'openai-compatible');
        const endpoint = buildAIRequestUrl(serverData.ai_config.endpoint, platform);
        const apiKey = serverData.ai_config.apiKey || serverData.ai_config.token;
        const model = serverData.ai_config.model;
        if (!apiKey) {
            throw new Error('未配置外部 AI API Key');
        }
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(platform === 'anthropic-compatible'
                ? {
                    model: model,
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    max_tokens: GUJJI_API_CONFIG.maxTokens,
                    temperature: GUJJI_API_CONFIG.temperature,
                    reasoning_effort: serverData.ai_config.reasoningEffort || DEFAULT_REASONING_EFFORT
                }
                : {
                    model: model,
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    max_tokens: GUJJI_API_CONFIG.maxTokens,
                    temperature: GUJJI_API_CONFIG.temperature
                })
        });
        if (!response.ok) {
            throw new Error(`API请求失败，HTTP状态码: ${response.status}`);
        }
        const data = await response.json();
        const aiResponse = platform === 'anthropic-compatible'
            ? (Array.isArray(data.content)
                ? data.content
                    .filter(item => item?.type === 'text' || item?.type === 'thinking')
                    .map(item => item.text || item.thinking || '')
                    .join('\n')
                    .trim()
                : '')
            : data.choices?.[0]?.message?.content;
        if (!aiResponse) {
            throw new Error('AI响应为空');
        }
        return {
            success: true,
            response: aiResponse.trim()
        };
    }
    catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}
async function loadAdConfig() {
    adConfig = null;
}
function updatePriceDisplay() {
    return;
}
function createAdElement(adData, position) {
    const adElement = document.createElement('div');
    adElement.className = `ad-container ad-${position}`;
    adElement.setAttribute('data-ad-id', adData.id);
    if (adData.style) {
        Object.assign(adElement.style, {
            background: adData.style.background || '#f8f9fa',
            color: adData.style.color || '#333333',
            border: adData.style.border || '1px solid #e9ecef',
            padding: '8px',
            margin: '8px 0',
            borderRadius: '6px',
            fontSize: '12px',
            cursor: adData.link ? 'pointer' : 'default',
            position: 'relative'
        });
    }
    let content = `<div class="ad-title" style="font-weight: 600; margin-bottom: 4px;">${adData.title}</div>`;
    content += `<div class="ad-content">${adData.content}</div>`;
    if (adData.image) {
        content = `<img src="${adData.image}" style="max-width: 100%; height: auto; margin-bottom: 4px;">` + content;
    }
    if (adConfig.config && adConfig.config.show_close_button) {
        content += `<button class="ad-close-btn" style="position: absolute; top: 4px; right: 4px; background: rgba(0,0,0,0.2); border: none; color: white; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; cursor: pointer; line-height: 1;">&times;</button>`;
    }
    adElement.innerHTML = content;
    if (adData.link) {
        adElement.addEventListener('click', (e) => {
            if (e.target.classList.contains('ad-close-btn')) {
                return;
            }
            if (adConfig.config && adConfig.config.click_tracking) {
                void 0;
            }
            window.open(adData.link, '_blank');
        });
    }
    const closeBtn = adElement.querySelector('.ad-close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            adElement.remove();
        });
    }
    return adElement;
}
function shouldShowAd(probability) {
    return Math.random() * 100 < probability;
}
function displayAds() {
    document.querySelectorAll('.ad-container').forEach(element => element.remove());
}
async function initializeFromServer() {
    try {
        await loadSettingsFromLocal();
        updateAllUI();
    }
    catch (error) {
        void 0;
        addLog('初始化失败: ' + error.message, 'error');
    }
}
async function loadSettingsFromLocal() {
    try {
        const result = await chrome.storage.local.get(['hr_assistant_settings', 'ai_config']);
        if (result.hr_assistant_settings) {
            const localSettings = result.hr_assistant_settings;
            if (localSettings.positions)
                serverData.positions = localSettings.positions;
            if (localSettings.currentPosition)
                serverData.currentPosition = localSettings.currentPosition;
            if (localSettings.isAndMode !== undefined)
                serverData.isAndMode = localSettings.isAndMode;
            if (localSettings.matchLimit)
                serverData.matchLimit = localSettings.matchLimit;
            if (localSettings.enableSound !== undefined)
                serverData.enableSound = localSettings.enableSound;
            if (localSettings.scrollDelayMin)
                serverData.scrollDelayMin = localSettings.scrollDelayMin;
            if (localSettings.scrollDelayMax)
                serverData.scrollDelayMax = localSettings.scrollDelayMax;
            if (localSettings.companyInfo)
                serverData.companyInfo = localSettings.companyInfo;
            if (localSettings.jobInfo)
                serverData.jobInfo = localSettings.jobInfo;
            if (localSettings.communicationConfig)
                serverData.communicationConfig = localSettings.communicationConfig;
            if (localSettings.runModeConfig)
                serverData.runModeConfig = localSettings.runModeConfig;
        }
        if (result.ai_config) {
            serverData.ai_config = { ...serverData.ai_config, ...result.ai_config };
            void 0;
        }
        applyMiniMaxDefaults();
    }
    catch (error) {
        void 0;
    }
}
async function checkAndSetAIExpireTime() {
    return;
}
async function updateServerData() {
    return;
}
function updateAllUI() {
    updateAIConfigUI();
    updatePositionsUI();
    updateAIExpireDisplay();
    updateOtherSettingsUI();
}
function updatePositionsUI() {
    renderPositions();
    if (serverData.currentPosition) {
        renderKeywords();
        renderExcludeKeywords();
        updateJobDescription();
    }
}
function updateOtherSettingsUI() {
    const matchLimitInput = document.getElementById('match-limit');
    if (matchLimitInput && serverData.matchLimit !== undefined) {
        matchLimitInput.value = serverData.matchLimit;
    }
    const enableSoundCheckbox = document.getElementById('enable-sound');
    if (enableSoundCheckbox && serverData.enableSound !== undefined) {
        enableSoundCheckbox.checked = serverData.enableSound;
    }
    const collectPhoneCheckboxes = document.querySelectorAll('.collect-phone');
    if (!serverData.communicationConfig.collectPhone) {
        serverData.communicationConfig.collectPhone = false;
    }
    collectPhoneCheckboxes.forEach(checkbox => {
        if (checkbox && serverData.communicationConfig && serverData.communicationConfig.collectPhone !== undefined) {
            checkbox.checked = serverData.communicationConfig.collectPhone;
        }
    });
    if (!serverData.communicationConfig.collectWechat) {
        serverData.communicationConfig.collectWechat = false;
    }
    const collectWechatCheckboxes = document.querySelectorAll('.collect-wechat');
    collectWechatCheckboxes.forEach(checkbox => {
        if (checkbox && serverData.communicationConfig && serverData.communicationConfig.collectWechat !== undefined) {
            checkbox.checked = serverData.communicationConfig.collectWechat;
        }
    });
    if (!serverData.communicationConfig.collectResume) {
        serverData.communicationConfig.collectResume = false;
    }
    const collectResumeCheckboxes = document.querySelectorAll('.collect-resume');
    collectResumeCheckboxes.forEach(checkbox => {
        if (checkbox && serverData.communicationConfig && serverData.communicationConfig.collectResume !== undefined) {
            checkbox.checked = serverData.communicationConfig.collectResume;
        }
        else {
            checkbox.checked = false;
        }
    });
    const delayMinInput = document.getElementById('delay-min');
    if (delayMinInput && serverData.scrollDelayMin !== undefined) {
        delayMinInput.value = serverData.scrollDelayMin;
    }
    const delayMaxInput = document.getElementById('delay-max');
    if (delayMaxInput && serverData.scrollDelayMax !== undefined) {
        delayMaxInput.value = serverData.scrollDelayMax;
    }
    const companyInfoElement = document.getElementById('company-info');
    if (companyInfoElement && serverData.companyInfo && serverData.companyInfo.content !== undefined) {
        companyInfoElement.value = serverData.companyInfo.content;
    }
    const jobExtraInfoElement = document.getElementById('job-extra-info');
    if (jobExtraInfoElement && serverData.jobInfo && serverData.jobInfo.extraInfo !== undefined) {
        jobExtraInfoElement.value = serverData.jobInfo.extraInfo;
    }
    const communicationFields = [
        'collect-contact-methods',
        'auto-send-greeting', 'auto-process-resume'
    ];
    communicationFields.forEach(field => {
        const element = document.getElementById(field);
        if (element && serverData.communicationConfig && serverData.communicationConfig[field.replace(/-/g, '')] !== undefined) {
            if (element.type === 'checkbox') {
                element.checked = serverData.communicationConfig[field.replace(/-/g, '')];
            }
            else {
                element.value = serverData.communicationConfig[field.replace(/-/g, '')];
            }
        }
    });
    const runModeFields = ['greeting-checkbox', 'communication-checkbox'];
    runModeFields.forEach(field => {
        const element = document.getElementById(field);
        if (element && serverData.runModeConfig && serverData.runModeConfig[field.replace('-checkbox', '')] !== undefined) {
            element.checked = serverData.runModeConfig[field.replace('-checkbox', '')];
        }
    });
}
async function optimizeJobDescriptionWithAI() {
    const jobDescriptionTextarea = document.getElementById('job-description');
    const jobDescription = jobDescriptionTextarea.value.trim();
    if (!jobDescription) {
        addLog('请先输入岗位要求内容', 'warning');
        return;
    }
    if (!serverData.ai_config || !(serverData.ai_config.apiKey || serverData.ai_config.token)) {
        addLog('请先配置AI设置（需要可用的 API Key）', 'error');
        return;
    }
    const optimizeBtn = document.getElementById('ai-optimize-job-description');
    const originalBtnText = optimizeBtn.innerHTML;
    optimizeBtn.innerHTML = '<span class="spinner"></span>AI优化中...';
    optimizeBtn.disabled = true;
    try {
        addLog('正在使用AI优化岗位要求...', 'info');
        const prompt = `你是一个资深的HR专家和招聘文案优化师。请优化以下岗位要求，使其：
1. 简单明了，避免复杂的语言
2. 结构更清晰，便于ai模型理解
3. 包含关键信息：岗位要求
4. 符合ai模型的输入要求，不能包含任何特殊字符或格式
5. 理解岗位要求中的所有条件，不能忽略任何重要信息
6. 必须 1234点 这样一行一个。

目的:这是一份岗位要求，你需要根据原始岗位要求优化，使其符合ai模型的输入要求。
请直接返回优化后的岗位要求内容，不要添加其他说明。

原始岗位要求：
${jobDescription}`;
        const result = await sendDirectAIRequest(prompt);
        if (result.success) {
            jobDescriptionTextarea.value = result.response;
            if (serverData.currentPosition) {
                serverData.currentPosition.description = result.response;
                await saveSettings();
            }
            addLog('岗位要求优化完成', 'success');
        }
        else {
            addLog(`AI优化失败: ${result.error}`, 'error');
        }
    }
    catch (error) {
        void 0;
        addLog(`AI优化失败: ${error.message}`, 'error');
    }
    finally {
        optimizeBtn.innerHTML = originalBtnText;
        optimizeBtn.disabled = false;
    }
}
