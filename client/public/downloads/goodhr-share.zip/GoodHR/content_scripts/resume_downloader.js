class ResumeDownloader {
    constructor() {
        this.downloader = null;
    }
    initDownloader(hostname) {
        void 0;
        if (hostname.includes('zhipin.com')) {
            this.downloader = new window.BossResumeDownloader();
            void 0;
        }
    }
    async start() {
        void 0;
        if (!this.downloader) {
            throw new Error('未初始化下载器');
        }
        await this.downloader.start();
    }
    stop() {
        if (this.downloader) {
            this.downloader.stop();
        }
    }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!window.resumeDownloader) {
        window.resumeDownloader = new ResumeDownloader();
        window.resumeDownloader.initDownloader(window.location.hostname);
    }
    if (message.action === 'START_DOWNLOAD') {
        void 0;
        window.resumeDownloader.start()
            .then(() => {
            void 0;
            sendResponse({ status: 'started' });
        })
            .catch(error => {
            void 0;
            sendResponse({ status: 'error', message: error.message });
        });
    }
    else if (message.action === 'STOP_DOWNLOAD') {
        window.resumeDownloader.stop();
        sendResponse({ status: 'stopped' });
    }
    return true;
});
