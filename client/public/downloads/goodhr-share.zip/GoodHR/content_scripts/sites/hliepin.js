import { BaseParser } from './common.js';
class HLiepinParser extends BaseParser {
    constructor() {
        super();
        this.selectors = {
            container: 'recommandResumes--',
            items: 'no-hover-tr',
            name: 'new-resume-personal-name',
            age: 'personal-detail-age',
            education: 'J1lRR',
            university: 'J1lRR',
            description: 'new-resume-personal-expect',
            clickTarget: 'ant-btn ant-btn-default ant-btn-lg lp-ant-btn-light',
            confirmClickTarget: 'ant-btn ant-btn-link ant-btn-lg btn-cancel directly-open-chat-btn',
            extraSelectors: 'J1lRR',
            onlineStatus: 'new-resume-offline',
            nextPageButton: 'ant-pagination-next',
            paginationContainer: 'ant-pagination',
            disabledClass: 'ant-pagination-disabled',
            continueButton: ['ant-btn ant-btn-default ant-btn-lg lp-ant-btn-light'],
            phoneButton: ['ant-btn ant-btn-primary __im_basic__basic-input-action', 'im-ui-action-button action-item'],
        };
        this.urlInfo = {
            url: 'https://www.liepin.com/zhaopin/?key=python',
            site: '推荐人才'
        };
        this.detailSelectors = {
            detailLink: 'tlog-common-resume-card',
            closeButton: 'closeBtn--',
            viewButton: '.ant-lpt-btn.ant-lpt-btn-primary'
        };
    }
    async collectPhoneWechatResume(phone, wechat, resume, candidate, element) {
        try {
            await new Promise(resolve => setTimeout(resolve, 2000));
            let buttonList = [];
            for (let i = 0; i < this.selectors.phoneButton.length; i++) {
                const continueButton = await this.CommonGetElementsByClassName(element, this.selectors.phoneButton[i]);
                void 0;
                if (continueButton != null && continueButton.length > 0) {
                    buttonList = (continueButton);
                }
            }
            void 0;
            if (phone) {
                void 0;
                const phoneButton = buttonList[0];
                if (phoneButton) {
                    phoneButton.click();
                    await new Promise(resolve => setTimeout(resolve, 800));
                    const confirmButton = await this.CommonQuerySelector(document, `[class^="ant-im-modal-confirm-btns"]`);
                    if (confirmButton) {
                        const confirmButton1 = this.CommonQuerySelectorAll(confirmButton, `[class^="ant-im-btn ant-im-btn-primary"]`);
                        for (let j = 0; j < confirmButton1.length; j++) {
                            confirmButton1[j].click();
                        }
                    }
                }
            }
            if (wechat) {
                void 0;
                const wechatButton = buttonList[1];
                if (wechatButton) {
                    wechatButton.click();
                    await new Promise(resolve => setTimeout(resolve, 800));
                    const confirmButton = await this.CommonQuerySelector(document, `[class^="ant-im-modal-confirm-btns"]`);
                    if (confirmButton) {
                        const confirmButton1 = this.CommonQuerySelectorAll(confirmButton, `[class^="ant-im-btn ant-im-btn-primary"]`);
                        for (let j = 0; j < confirmButton1.length; j++) {
                            confirmButton1[j].click();
                        }
                    }
                }
            }
            if (resume) {
                void 0;
                const resumeButton = buttonList[2];
                if (resumeButton) {
                    resumeButton.click();
                    await new Promise(resolve => setTimeout(resolve, 800));
                    const confirmButton = await this.CommonQuerySelector(document, `[class^="ant-im-modal-confirm-btns"]`);
                    if (confirmButton) {
                        const confirmButton1 = this.CommonQuerySelectorAll(confirmButton, `[class^="ant-im-btn ant-im-btn-primary"]`);
                        for (let j = 0; j < confirmButton1.length; j++) {
                            confirmButton1[j].click();
                        }
                    }
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            void 0;
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    async checkMessageTip(element) {
        return false;
    }
    sendMessage(message) {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage(message);
        }
    }
    isAtBottomOfPage() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        const isNearBottom = scrollTop + windowHeight >= documentHeight - 200;
        const hasNoMoreData = document.querySelector('[class*="no-more"], [class*="no-data"], [class*="end"]');
        const hasLoadingIndicator = document.querySelector('[class*="loading"], [class*="spinner"]');
        void 0;
        void 0;
        return isNearBottom && !hasLoadingIndicator;
    }
    hasNextPageButton() {
        const nextPageButton = document.querySelector(`[class*="${this.selectors.nextPageButton}"]`);
        if (!nextPageButton) {
            return false;
        }
        return !nextPageButton.classList.contains(this.selectors.disabledClass);
    }
    async clickNextPageButton() {
        try {
            const nextPageButton = document.querySelector(`[class*="${this.selectors.nextPageButton}"]`);
            if (nextPageButton && !nextPageButton.classList.contains(this.selectors.disabledClass)) {
                void 0;
                nextPageButton.click();
                await new Promise(resolve => setTimeout(resolve, 1000));
                let pageLoaded = false;
                let attempts = 0;
                const maxAttempts = 10;
                while (!pageLoaded && attempts < maxAttempts) {
                    const items = document.querySelectorAll(`[class*="${this.selectors.items}"]`);
                    if (items.length > 0) {
                        void 0;
                        pageLoaded = true;
                    }
                    else {
                        void 0;
                        await new Promise(resolve => setTimeout(resolve, 1000));
                        attempts++;
                    }
                }
                if (!pageLoaded) {
                    void 0;
                }
                window.scrollTo(0, 0);
                this.sendMessage({
                    action: 'RESET_POSITION',
                    data: {}
                });
                void 0;
                return true;
            }
            else {
                void 0;
            }
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    shouldNavigateToNextPage(elements) {
        void 0;
        return true;
    }
    queryColleagueContactedInfo(data) {
        return "";
    }
    getElementByClassPrefix(parent, prefix) {
        let element = parent.querySelector(`[class^="${prefix}"]`);
        if (!element) {
            element = parent.querySelector(`[class*="${prefix}"]`);
        }
        return element;
    }
    getSimpleCandidateInfo(data) {
        new Promise(resolve => setTimeout(resolve, 1000));
        let data2 = "";
        data2 += "姓名：" + data.name + "\n";
        data2 += "年龄：" + data.age + "\n";
        data2 += "学历：" + data.education + "\n";
        data2 += "学校：" + data.university + "\n";
        data2 += "描述：" + data.description + "\n";
        data.extraInfo.forEach(item => {
            data2 += "额外信息：" + item.type + " " + item.value + "\n";
        });
        return data2;
    }
    async extractCandidates2(data) {
        return new Promise(async (resolve, reject) => {
            const responses = [];
            let pollCount = 0;
            const maxPolls = 20;
            void 0;
            const pollLocalStorage = () => {
                try {
                    const storedData = localStorage.getItem('goodhr-candidate-detail');
                    if (storedData) {
                        const data = JSON.parse(storedData);
                        if (data.source === 'goodhr-plugin' &&
                            data.type === 'candidate-detail-response') {
                            responses.push(data);
                            localStorage.removeItem('goodhr-candidate-detail');
                            const matchedResponse = this.findMatchingResponse(responses, data);
                            resolve(matchedResponse);
                            return;
                        }
                    }
                    pollCount++;
                    if (pollCount >= maxPolls) {
                        reject(new Error('获取候选人详细信息超时，未收到任何响应'));
                        return;
                    }
                    setTimeout(pollLocalStorage, 500);
                }
                catch (e) {
                    void 0;
                    pollCount++;
                    if (pollCount >= maxPolls) {
                        reject(new Error('获取候选人详细信息时出错'));
                        return;
                    }
                    setTimeout(pollLocalStorage, 500);
                }
            };
            pollLocalStorage();
        });
    }
    findMatchingResponse(responses, originalData) {
        return responses[0].data.textContent;
    }
    findElementsByMultipleMethods(selector, options = {}) {
        const { timeout = 0, maxRetries = 0, retryInterval = 500, includeHidden = false, methods = ['all'] } = options;
        if (timeout > 0) {
            return this.waitForElements(selector, { timeout, interval: retryInterval });
        }
        if (methods.includes('all') || methods.includes('querySelectorAll')) {
            try {
                const elements = document.querySelectorAll(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    return { elements: filteredElements, method: 'querySelectorAll' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByClassName')) && selector.startsWith('.')) {
            try {
                const className = selector.substring(1);
                const elements = document.getElementsByClassName(className);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByClassName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByTagName')) && /^[a-zA-Z]/.test(selector)) {
            try {
                const elements = document.getElementsByTagName(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByTagName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('xpath')) {
            try {
                let xpath = '';
                if (selector.startsWith('.')) {
                    const className = selector.substring(1);
                    xpath = `//*[contains(@class, '${className}')]`;
                }
                else if (selector.startsWith('#')) {
                    const id = selector.substring(1);
                    xpath = `//*[@id='${id}']`;
                }
                else if (/^[a-zA-Z]/.test(selector)) {
                    xpath = `//${selector}`;
                }
                if (xpath) {
                    const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    const elements = [];
                    for (let i = 0; i < result.snapshotLength; i++) {
                        elements.push(result.snapshotItem(i));
                    }
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'xpath' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('textSearch')) {
            try {
                const keywords = selector.match(/[^\s.#\[\]]+/g) || [];
                if (keywords.length > 0) {
                    const allElements = Array.from(document.body.getElementsByTagName('*'));
                    const elements = allElements.filter(el => {
                        const text = el.textContent || el.innerText || '';
                        return keywords.some(keyword => text.includes(keyword));
                    });
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'textSearch' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('domTraversal')) {
            try {
                const elements = [];
                const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
                    acceptNode: function (node) {
                        try {
                            if (node.matches && node.matches(selector)) {
                                return NodeFilter.FILTER_ACCEPT;
                            }
                        }
                        catch (e) {
                        }
                        return NodeFilter.FILTER_SKIP;
                    }
                });
                let node;
                while (node = walk.nextNode()) {
                    elements.push(node);
                }
                let filteredElements = elements;
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'domTraversal' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        void 0;
        return { elements: [], method: 'none', message: '未找到元素' };
    }
    isElementVisible(element) {
        if (!element)
            return false;
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
            return false;
        }
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            return false;
        }
        return true;
    }
    waitForElements(selector, options = {}) {
        const { timeout = 3000, interval = 100 } = options;
        return new Promise((resolve) => {
            const startTime = Date.now();
            const check = () => {
                const elements = document.querySelectorAll(selector);
                const visibleElements = Array.from(elements).filter(el => this.isElementVisible(el));
                if (visibleElements.length > 0) {
                    resolve({ elements: visibleElements, method: 'waitForElements' });
                }
                else if (Date.now() - startTime > timeout) {
                    resolve({ elements: [], method: 'waitForElements', message: '超时未找到元素' });
                }
                else {
                    setTimeout(check, interval);
                }
            };
            check();
        });
    }
    extractCandidates(elements = null) {
        const candidates = [];
        let items;
        try {
            if (elements) {
                items = elements;
            }
            else {
                items = document.querySelectorAll(`[class^="${this.selectors.items}"], [class*=" ${this.selectors.items}"]`);
                if (items.length === 0) {
                    void 0;
                    void 0;
                    throw new Error('未找到任何候选人元素，请检查选择器是否正确');
                }
            }
            Array.from(items).forEach((item, index) => {
                try {
                    const nameElement = this.getElementByClassPrefix(item, this.selectors.name);
                    const ageElement = this.getElementByClassPrefix(item, this.selectors.age);
                    const educationElement = this.getElementByClassPrefix(item, this.selectors.education);
                    const universityElement = this.getElementByClassPrefix(item, this.selectors.university);
                    const descriptionElement = this.getElementByClassPrefix(item, this.selectors.description);
                    const extraInfo = this.getElementByClassPrefix(item, this.selectors.extraSelectors);
                    const onlineStatusElement = this.getElementByClassPrefix(item, this.selectors.onlineStatus);
                    const candidate = {
                        name: nameElement?.textContent?.trim() + '年龄:' + ageElement?.textContent,
                        age: parseInt(ageElement?.textContent) || 0,
                        education: educationElement?.textContent?.trim() || '',
                        university: universityElement?.textContent?.trim() || '',
                        description: descriptionElement?.textContent?.trim() || item.textContent?.trim() || '',
                        extraInfo: [
                            { type: '在线状态', value: onlineStatusElement?.textContent?.trim() || '' },
                            { type: '求职期望', value: descriptionElement?.textContent?.trim() || '' },
                        ] || [],
                    };
                    if (candidate.name) {
                        candidates.push(candidate);
                    }
                    else {
                        void 0;
                    }
                }
                catch (error) {
                    void 0;
                    this.clearHighlight(item);
                }
            });
        }
        catch (error) {
            void 0;
            throw error;
        }
        return candidates;
    }
    async clickMatchedItem(element) {
        try {
            const clickElement = this.getElementByClassPrefix(element, this.selectors.clickTarget);
            if (clickElement) {
                clickElement.click();
            }
            else {
                void 0;
                return false;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            const confirmClickElement = this.getElementByClassPrefix(document, this.selectors.confirmClickTarget);
            void 0;
            if (confirmClickElement) {
                confirmClickElement.click();
                return true;
            }
            else {
                void 0;
                return false;
            }
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async clickCandidateDetail(element) {
        try {
            const clickTimestamp = Date.now();
            localStorage.setItem('goodhr-candidate-click-timestamp', clickTimestamp.toString());
            void 0;
            const detailLink = this.getElementByClassPrefix(element, this.detailSelectors.detailLink);
            if (detailLink) {
                detailLink.click();
                return true;
            }
            else {
                void 0;
                return false;
            }
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async closeDetail() {
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            const closeButton = document.querySelector(`[class*="${this.detailSelectors.closeButton}"]`);
            if (closeButton) {
                void 0;
                closeButton.click();
                return true;
            }
            void 0;
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async processCommunication(candidate) {
        try {
            if (!this.communicationConfig || !this.communicationConfig.communicationEnabled) {
                void 0;
                return false;
            }
            const candidateInfo = this.getSimpleCandidateInfo(candidate);
            let communicationContent = "";
            if (this.companyInfo) {
                communicationContent += `公司名称：${this.companyInfo.name || ''}\n`;
                communicationContent += `公司地址：${this.companyInfo.address || ''}\n`;
                communicationContent += `公司规模：${this.companyInfo.size || ''}\n`;
                communicationContent += `公司类型：${this.companyInfo.type || ''}\n`;
                communicationContent += `所属行业：${this.companyInfo.industry || ''}\n`;
                communicationContent += `公司介绍：${this.companyInfo.description || ''}\n`;
                communicationContent += `公司官网：${this.companyInfo.website || ''}\n`;
                communicationContent += `联系电话：${this.companyInfo.phone || ''}\n`;
                communicationContent += `联系邮箱：${this.companyInfo.email || ''}\n\n`;
            }
            if (this.jobInfo) {
                communicationContent += `岗位名称：${this.jobInfo.title || ''}\n`;
                communicationContent += `岗位职责：${this.jobInfo.duty || ''}\n`;
                communicationContent += `岗位要求：${this.jobInfo.requirement || ''}\n`;
                communicationContent += `经验要求：${this.jobInfo.experience || ''}\n`;
                communicationContent += `学历要求：${this.jobInfo.education || ''}\n`;
                communicationContent += `薪资范围：${this.jobInfo.salary || ''}\n`;
                communicationContent += `工作地点：${this.jobInfo.location || ''}\n`;
                communicationContent += `工作性质：${this.jobInfo.type || ''}\n`;
                communicationContent += `岗位类别：${this.jobInfo.category || ''}\n`;
                communicationContent += `岗位描述：${this.jobInfo.description || ''}\n\n`;
            }
            communicationContent += `候选人信息：\n${candidateInfo}\n\n`;
            if (this.communicationConfig.autoSendGreeting) {
                void 0;
            }
            if (this.communicationConfig.autoProcessResume) {
                void 0;
            }
            if (this.communicationConfig.collectContactMethods) {
                void 0;
            }
            void 0;
            return true;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
}
export { HLiepinParser };
