class BaseParser {
    constructor() {
        this.settings = null;
        this.filterSettings = null;
        this.highlightStyles = {
            processing: `
                background-color: #fff3e0 !important;
                transition: background-color 0.3s ease;
                outline: 2px solid #ffa726 !important;
            `,
            matched: `
                background-color: #e8f5e9 !important;
                transition: background-color 0.3s ease;
                outline: 2px solid #4caf50 !important;
                box-shadow: 0 0 10px rgba(76, 175, 80, 0.3) !important;
            `
        };
        this.clickCandidateConfig = {
            enabled: true,
            frequency: 3,
            viewDuration: [3, 5]
        };
    }
    async loadSettings() {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(['keywords', 'isAndMode'], (result) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                    return;
                }
                this.settings = result;
                resolve(result);
            });
        });
    }
    setFilterSettings(settings) {
        this.filterSettings = settings;
    }
    async CommonQuerySelector(candidate, selector) {
        for (let attempt = 0; attempt < 5; attempt++) {
            const element = candidate.querySelector(selector);
            if (element) {
                return element;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        return null;
    }
    async CommonQuerySelectorAll(candidate, selector) {
        for (let attempt = 0; attempt < 5; attempt++) {
            const elements = candidate.querySelectorAll(selector);
            if (elements.length > 0) {
                return elements;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        return [];
    }
    async CommonGetElementsByClassName(element, selector) {
        for (let attempt = 0; attempt < 5; attempt++) {
            const elements = element.getElementsByClassName(selector);
            if (elements.length > 0) {
                return elements;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        return [];
    }
    filterCandidate(candidate) {
        if (!this.filterSettings) {
            return true;
        }
        const allText = candidate;
        if (allText == null) {
            return false;
        }
        if (this.filterSettings.excludeKeywords &&
            this.filterSettings.excludeKeywords.some(keyword => allText.includes(keyword.toLowerCase()))) {
            void 0;
            return false;
        }
        if (!this.filterSettings.keywords || !this.filterSettings.keywords.length) {
            return true;
        }
        if (this.filterSettings.isAndMode) {
            return this.filterSettings.keywords.every(keyword => {
                if (!keyword)
                    return true;
                return allText.includes(keyword.toLowerCase());
            });
        }
        else {
            return this.filterSettings.keywords.some(keyword => {
                if (!keyword)
                    return false;
                return allText.includes(keyword.toLowerCase());
            });
        }
    }
    extractExtraInfo(element, extraSelectors) {
        const extraInfo = [];
        if (Array.isArray(extraSelectors)) {
            extraSelectors.forEach(selector => {
                const elements = this.getElementsByClassPrefix(element, selector.prefix);
                if (elements.length > 0) {
                    elements.forEach(el => {
                        const info = el.textContent?.trim();
                        if (info) {
                            extraInfo.push({
                                type: selector.type || 'unknown',
                                value: info
                            });
                        }
                    });
                }
            });
        }
        return extraInfo;
    }
    getElementsByClassPrefix(parent, prefix) {
        const elements = [];
        const startsWith = Array.from(parent.querySelectorAll(`[class^="${prefix}"]`));
        const contains = Array.from(parent.querySelectorAll(`[class*=" ${prefix}"]`));
        return [...new Set([...startsWith, ...contains])];
    }
    clickMatchedItem(element) {
        void 0;
        return false;
    }
    setClickCandidateConfig(config) {
        this.clickCandidateConfig = {
            ...this.clickCandidateConfig,
            ...config
        };
    }
    shouldClickCandidate() {
        if (!this.clickCandidateConfig.enabled)
            return false;
        let random = Math.random() * 10;
        return random <= (this.clickCandidateConfig.frequency);
    }
    getRandomViewDuration() {
        const min = this.filterSettings?.scrollDelayMin || 3;
        const max = this.filterSettings?.scrollDelayMax || 5;
        return Math.floor(Math.random() * (max - min + 1) + min) * 1000;
    }
    async clickCandidateDetail(element) {
        throw new Error('clickCandidateDetail method must be implemented by child class');
    }
    async closeDetail() {
        throw new Error('closeDetail method must be implemented by child class');
    }
}
export { BaseParser };
