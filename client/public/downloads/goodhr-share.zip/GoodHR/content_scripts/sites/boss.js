import { BaseParser } from "./common.js";
class BossParser extends BaseParser {
    constructor() {
        super();
        this.fullClasses = {
            container: "card-list",
            items: [
                "candidate-card-wrap",
                "geek-info-card",
                "card-container",
                "card-inner clear-fix",
            ],
            name: "name",
            age: "job-card-left_labels__wVUfs",
            education: "base-info join-text-wrap",
            university: "content join-text-wrap",
            description: "content",
            clickTarget: [
                "btn btn-greet",
                "btn btn-getcontact search-btn-tip btn-prop-common prop-card-chat",
            ],
        };
        this.urlInfo = {
            url: "/web/chat/recommend",
            site: "推荐牛人",
        };
        this.selectors = {
            container: "card-list",
            items: [
                "candidate-card-wrap",
                "card-inner clear-fix",
                "card-container",
                "geek-info-card",
            ],
            name: "name",
            age: ["job-card-left"],
            education: ["base-info join-text-wrap", "geek-info-detail"],
            university: "content join-text-wrap",
            description: "content",
            clickTarget: [
                "btn btn-greet",
                "btn btn-getcontact search-btn-tip btn-prop-common prop-card-chat",
            ],
            activeText: "active-text",
            continueButton: ["btn btn-continue btn-outline"],
            phoneButton: "operate-item",
            extraSelectors: [
                { prefix: "salary-text", type: "薪资" },
                { prefix: "job-info-primary", type: "基本信息" },
                { prefix: "tags-wrap", type: "标签" },
                { prefix: "content join-text-wrap", type: "公司信息" },
            ],
            isContacted: ["colleague-collaboration"],
        };
        this.detailSelectors = {
            detailLink: [
                "card-inner common-wrap",
                "card-inner clear-fix",
                "candidate-card-wrap",
                "card-inner blue-collar-wrap",
                "card-container",
                "geek-info-card",
                "card-inner new-geek-wrap",
            ],
            closeButton: [
                "boss-popup__close",
                "resume-custom-close",
                "boss-popup__close",
                "dialog-wrap active",
            ],
            closeButtonXpath: ['//*[@id="boss-dynamic-dialog-1j38fleo5"]/div/div[2]'],
            messageTip: "chat-global-entry",
            messageListItem: "friend-list-item",
        };
        this.initDataInterceptor();
        this.startAutoAcceptResumeWatcher();
    }
    async checkMessageTip(element, phone, wechat, resume) {
        return true;
        let messageTip = window.parent.document.getElementsByClassName(this.detailSelectors.messageTip);
        if (messageTip.length > 0) {
            messageTip = messageTip[0];
        }
        void 0;
        let messageCount = 0;
        try {
            messageCount = parseInt(messageTip.textContent.trim()) || 0;
        }
        catch (error) {
            void 0;
        }
        if (messageCount <= 0) {
            return false;
        }
        messageTip.click();
        await new Promise((resolve) => setTimeout(resolve, 2500));
        let messageListItems = window.parent.document.getElementsByClassName("friend-list-item");
        void 0;
        for (let i = 0; i < messageListItems.length; i++) {
            void 0;
            let messageCount = 0;
            try {
                messageCount =
                    parseInt(messageListItems[i]
                        .getElementsByClassName("badge-count badge-count-common-less")[0]
                        .textContent.trim()) || 0;
            }
            catch (error) { }
            if (messageCount <= 0) {
                continue;
            }
            messageListItems[i].click();
            await new Promise((resolve) => setTimeout(resolve, 1000));
            await this.clickPhoneButton(phone, wechat, resume);
        }
        messageTip.click();
        return false;
    }
    async clickPhoneButton(phone, wechat, resume) {
        const suoyaolist = window.parent.document.querySelectorAll(`[class^="${this.selectors.phoneButton}"]`);
        if (!suoyaolist) {
            void 0;
            return null;
        }
        if (suoyaolist.length <= 3) {
            void 0;
            return null;
        }
        void 0;
        if (phone) {
            suoyaolist[3].click();
            await new Promise((resolve) => setTimeout(resolve, 200));
            const confirmphoneButton = document.querySelector(`[class^="boss-btn-primary boss-btn"]`);
            if (confirmphoneButton) {
                confirmphoneButton.click();
            }
        }
        if (wechat) {
            suoyaolist[4].click();
            await new Promise((resolve) => setTimeout(resolve, 200));
            const confirmphoneButton = document.querySelector(`[class^="boss-btn-primary boss-btn"]`);
            if (confirmphoneButton) {
                confirmphoneButton.click();
            }
        }
        if (resume) {
            suoyaolist[2].click();
            await new Promise((resolve) => setTimeout(resolve, 200));
            const confirmphoneButton = document.querySelector(`[class^="boss-btn-primary boss-btn"]`);
            if (confirmphoneButton) {
                confirmphoneButton.click();
            }
        }
    }
    async collectPhoneWechatResume(phone, wechat, resume, candidate, element) {
        try {
            await new Promise((resolve) => setTimeout(resolve, 1000));
            for (let i = 0; i < this.selectors.continueButton.length; i++) {
                const continueButton = element.querySelectorAll(`[class^="${this.selectors.continueButton[i]}"]`);
                for (let j = 0; j < continueButton.length; j++) {
                    continueButton[j].click();
                    await new Promise((resolve) => setTimeout(resolve, 500));
                    continueButton[j].click();
                }
            }
            await new Promise((resolve) => setTimeout(resolve, 1000));
            await this.clickPhoneButton(phone, wechat, resume);
            await new Promise((resolve) => setTimeout(resolve, 1000));
            const closeButton = document.querySelector(`[class^="iboss iboss-close"]`);
            if (closeButton) {
                closeButton.click();
            }
            const closeButton2 = document.querySelector(`[class^="km-icon sati ignore-im-widget-click sati-times"]`);
            if (closeButton2) {
                closeButton2.click();
            }
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    triggerElementClick(element) {
        if (!element) {
            return false;
        }
        try {
            element.scrollIntoView?.({
                block: "center",
                inline: "nearest",
                behavior: "auto",
            });
        }
        catch (error) { }
        try {
            ["pointerdown", "mousedown", "mouseup", "click"].forEach((type) => {
                element.dispatchEvent(new MouseEvent(type, {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                }));
            });
            element.click?.();
            return true;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    isResumeConsentContainer(element) {
        if (!element) {
            return false;
        }
        const text = (element.textContent || "").replace(/\s+/g, "");
        if (!text.includes("简历") || !text.includes("同意")) {
            return false;
        }
        return ((text.includes("发送附件简历") ||
            text.includes("附件简历") ||
            text.includes("发给您") ||
            text.includes("是否同意") ||
            text.includes("简历发您看") ||
            text.includes("简历发送")) &&
            text.includes("拒绝") &&
            text.includes("同意"));
    }
    findResumeConsentCards(root = document) {
        const candidates = Array.from(root.querySelectorAll("div, section, article"));
        return candidates.filter((element) => {
            if (element.dataset.goodhrResumeAutoAccepted === "1") {
                return false;
            }
            return this.isResumeConsentContainer(element);
        });
    }
    findConsentButtonInCard(card) {
        if (!card) {
            return null;
        }
        const buttonCandidates = Array.from(card.querySelectorAll('button, [role="button"], a, [class*="btn"], [class*="button"]')).filter((element) => {
            const text = element.textContent?.replace(/\s+/g, "").trim() || "";
            if (text !== "同意") {
                return false;
            }
            const ariaDisabled = element.getAttribute?.("aria-disabled");
            if (element.disabled || ariaDisabled === "true") {
                return false;
            }
            return true;
        });
        return buttonCandidates[buttonCandidates.length - 1] || null;
    }
    clickResumeConsentButton(button) {
        if (!button) {
            return false;
        }
        try {
            button.scrollIntoView?.({
                block: "center",
                inline: "nearest",
                behavior: "auto",
            });
        }
        catch (error) { }
        try {
            button.focus?.();
            button.click?.();
            return true;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    acceptPendingResumeRequests(root = document) {
        const roots = [
            root,
            document.querySelector('[class*="dialog"]'),
            document.querySelector('[class*="modal"]'),
            document.querySelector('[class*="popup"]'),
            document.querySelector('[class*="message"]'),
        ].filter(Boolean);
        const seen = new Set();
        const consentCards = roots.flatMap((currentRoot) => this.findResumeConsentCards(currentRoot)).filter((card) => {
            if (seen.has(card)) {
                return false;
            }
            seen.add(card);
            return true;
        });
        consentCards.forEach((card) => {
            const consentButton = this.findConsentButtonInCard(card);
            const clicked = this.clickResumeConsentButton(consentButton);
            if (clicked) {
                card.dataset.goodhrResumeAutoAccepted = "1";
                consentButton.dataset.goodhrResumeAutoAccepted = "1";
                void 0;
                setTimeout(() => {
                    if (this.isResumeConsentContainer(card)) {
                        this.clickResumeConsentButton(consentButton);
                    }
                }, 600);
            }
        });
    }
    startAutoAcceptResumeWatcher() {
        if (window !== window.top) {
            return;
        }
        if (window.__goodhrBossResumeWatcherStarted) {
            return;
        }
        window.__goodhrBossResumeWatcherStarted = true;
        const scan = () => {
            try {
                this.acceptPendingResumeRequests(document);
            }
            catch (error) {
                void 0;
            }
        };
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", scan, { once: true });
        }
        else {
            setTimeout(scan, 800);
        }
        const observer = new MutationObserver(() => {
            scan();
        });
        const startObserve = () => {
            if (!document.body) {
                setTimeout(startObserve, 500);
                return;
            }
            observer.observe(document.body, {
                childList: true,
                subtree: true,
            });
            scan();
        };
        startObserve();
        setInterval(scan, 2000);
    }
    initDataInterceptor() {
        window.addEventListener("message", (event) => {
            if (event.source !== window)
                return;
            if (event.data &&
                event.data.source === "boss-plugin" &&
                event.data.type === "geek-list") {
                if (event.data.data) {
                    this.processInterceptedData(event.data.data.zpData.geekList || event.data.data.zpData.geeks);
                }
            }
        });
    }
    async processInterceptedData(apiData) {
        try {
            if (apiData) {
                const candidates = apiData;
                await new Promise((resolve, reject) => {
                    chrome.storage.local.set({
                        bossZhipinCandidates: candidates,
                    }, () => {
                        if (chrome.runtime.lastError) {
                            void 0;
                            reject(chrome.runtime.lastError);
                        }
                        else {
                            void 0;
                            resolve();
                        }
                    });
                });
            }
        }
        catch (error) {
            void 0;
        }
    }
    findElements() {
        let items = [];
        for (const item of this.fullClasses.items) {
            items = document.getElementsByClassName(item);
            if (items.length > 0) {
                break;
            }
        }
        if (items.length === 0) {
            for (const item of this.selectors.items) {
                items = document.getElementsByClassName(item);
                if (items.length > 0) {
                    break;
                }
            }
        }
        if (items.length === 0) {
            for (const item of this.fullClasses.items) {
                items = document.querySelectorAll(`[class*="${item}"]`);
                if (items.length > 0) {
                    break;
                }
            }
        }
        if (items.length === 0) {
            for (const item of this.fullClasses.items) {
                items = document.querySelectorAll(`[class^="${item}"], [class*=" ${this.selectors.items}"]`);
                if (items.length > 0) {
                    break;
                }
            }
        }
        return items;
    }
    async getCachedCandidateData() {
        return new Promise((resolve) => {
            chrome.storage.local.get(["bossZhipinCandidates"], (result) => {
                if (chrome.runtime.lastError) {
                    void 0;
                    resolve([]);
                    return;
                }
                resolve(result.bossZhipinCandidates || []);
            });
        });
    }
    findCandidateFromCache(cachedData, candidateName) {
        if (!cachedData || !candidateName)
            return null;
        for (const candidate of cachedData) {
            void 0;
            if (candidate.geekCard &&
                candidate.geekCard.geekName
                    .toLowerCase()
                    .includes(candidateName.toLowerCase())) {
                return candidate;
            }
        }
        return null;
    }
    async extractCandidates2(data) {
        return null;
    }
    async extractCandidates(elements = null) {
        try {
            const candidates = [];
            let items = elements || (await this.findElements());
            if (!items || items.length === 0) {
                void 0;
                return [];
            }
            const cachedData = await this.getCachedCandidateData();
            for (const item of Array.from(items)) {
                try {
                    const nameElement = await this.findNameElement(item);
                    const candidateName = nameElement?.textContent?.trim() || "";
                    if (!candidateName) {
                        this.clearHighlight(item);
                        continue;
                    }
                    void 0;
                    const candidate = await this.processCandidate(item, candidateName, cachedData);
                    if (candidate) {
                        candidates.push(candidate);
                    }
                }
                catch (error) {
                    void 0;
                    this.clearHighlight(item);
                }
            }
            return candidates;
        }
        catch (error) {
            void 0;
            return [];
        }
    }
    findElement(fullClass, partialClass) {
        return (item) => {
            if (Array.isArray(partialClass)) {
                for (const className of partialClass) {
                    const element = item.getElementsByClassName(className)[0] ||
                        item.querySelector(`[class*="${className}"]`);
                    if (element)
                        return element;
                }
            }
            else {
                return (item.getElementsByClassName(fullClass)[0] ||
                    item.getElementsByClassName(partialClass)[0] ||
                    item.querySelector(`[class*="${partialClass}"]`));
            }
            return null;
        };
    }
    async findNameElement(item) {
        return this.findElement(this.fullClasses.name, this.selectors.name)(item);
    }
    async updateCandidateFromPage(candidate, item) {
        try {
            const pageActiveText = (await this.findElement(this.fullClasses.activeText, this.selectors.activeText)(item)?.textContent?.trim()) || "离线";
            if (pageActiveText && pageActiveText !== "离线") {
                candidate.activeText = pageActiveText;
            }
            return candidate;
        }
        catch (error) {
            void 0;
            return candidate;
        }
    }
    async createNewCandidate(item, candidateName) {
        try {
            return {
                name: candidateName,
                age: this.extractAge(await this.findElement(this.fullClasses.age, this.selectors.age)(item)
                    ?.textContent),
                education: (await this.findElement(this.fullClasses.education, this.selectors.education)(item)?.textContent?.trim()) || "",
                university: (await this.findElement(this.fullClasses.university, this.selectors.university)(item)?.textContent?.trim()) || "",
                description: (await this.findElement(this.fullClasses.description, this.selectors.description)(item)?.textContent?.trim()) || "",
                activeText: await this.getActiveText(item),
                extraInfo: await this.extractExtraInfo(item, this.selectors.extraSelectors),
                timestamp: Date.now(),
            };
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    async processCandidate(item, candidateName, cachedData) {
        const cachedCandidate = this.findCandidateFromCache(cachedData, candidateName);
        if (cachedCandidate) {
            return cachedCandidate;
        }
        return this.createNewCandidate(item, candidateName);
    }
    getActiveText(item) {
        let activeTextElement = findElement(this.fullClasses.activeText, this.selectors.activeText);
        if (!activeTextElement) {
            let onlineMarker = findElement("online-marker", "online-marker");
            return onlineMarker ? "在线" : "离线";
        }
        return activeTextElement.textContent?.trim() || "离线";
    }
    extractAge(text) {
        if (!text)
            return 0;
        const matches = text.match(/(\d+)岁/);
        return matches ? parseInt(matches[1]) : 0;
    }
    async clickMatchedItem(element) {
        try {
            let clickElement = null;
            element.dispatchEvent(new MouseEvent("mouseover", {
                view: window,
                bubbles: true,
                cancelable: true,
            }));
            for (const className of this.selectors.clickTarget) {
                let aaa = element.getElementsByClassName(className) ||
                    element.getElementsByClassName(className) ||
                    element.querySelector(`[class*="${className}"]`);
                if (aaa.length > 0) {
                    for (let i = 0; i <= aaa.length; i++) {
                        if (aaa[i]) {
                            aaa[i].click();
                        }
                    }
                }
            }
            if (clickElement) {
                clickElement.click();
                return true;
            }
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async clickCandidateDetail(element) {
        try {
            let detailLink = null;
            for (const className of this.detailSelectors.detailLink) {
                let element2 = element.getElementsByClassName(className)[0];
                if (element2) {
                    detailLink = element2;
                }
            }
            if (detailLink) {
                detailLink.click();
                return true;
            }
            else {
                void 0;
            }
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async closeDetail(maxRetries = 3) {
        try {
            if (maxRetries <= 0) {
                void 0;
                return false;
            }
            for (const className of this.detailSelectors.closeButton) {
                const closeElements = document.getElementsByClassName(className);
                if (closeElements.length > 0) {
                    closeElements[0].click();
                    await new Promise((resolve) => setTimeout(resolve, 500));
                }
                const closeElements2 = window.parent.document.getElementsByClassName(className);
                if (closeElements2.length > 0) {
                    closeElements2[0].click();
                    await new Promise((resolve) => setTimeout(resolve, 500));
                }
            }
            await new Promise((resolve) => setTimeout(resolve, 500));
            const stillHasModals = this.checkForRemainingModals();
            if (stillHasModals) {
                void 0;
                return await this.closeDetail(maxRetries - 1);
            }
            return true;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    checkForRemainingModals() {
        for (const className of this.detailSelectors.closeButton) {
            if (document.getElementsByClassName(className).length > 0) {
                void 0;
                return true;
            }
        }
        for (const xpath of this.detailSelectors.closeButtonXpath) {
            const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            if (element) {
                void 0;
                return true;
            }
        }
        return false;
    }
    async queryColleagueContactedInfo(candidate) {
        try {
            for (let i = 0; i <= this.selectors.isContacted.length; i++) {
                let aaa = document.getElementsByClassName(this.selectors.isContacted[i]);
                if (aaa.length > 0) {
                    return aaa[0].textContent.trim();
                }
                else {
                }
            }
        }
        catch (error) {
            void 0;
        }
    }
    getSimpleCandidateInfo(candidate) {
        if (!candidate)
            return "候选人信息为空";
        const info = [];
        if (candidate.geekCard) {
            const gc = candidate.geekCard;
            info.push(`姓名: ${gc.geekName || "未知"}`);
            info.push(`年龄: ${gc.ageDesc || "未知"}`);
            info.push(`学历: ${gc.geekDegree || "未知"}`);
            info.push(`毕业院校: ${gc.geekEdu?.school || "未知"}`);
            info.push(`专业: ${gc.geekEdu?.major || "未知"}`);
            info.push(`工作年限: ${gc.geekWorkYear || "未知"}`);
            info.push(`当前状态: ${gc.applyStatusDesc || "未知"}`);
            info.push(`期望薪资: ${gc.salary || "未知"}`);
            info.push(`期望职位: ${gc.expectPositionName || "未知"}`);
            info.push(`期望地点: ${gc.expectLocationName || "未知"}`);
            if (gc.geekDesc?.content) {
                info.push(`自我介绍: ${gc.geekDesc.content}`);
            }
        }
        if (candidate.geekCard.geekWorks?.length > 0) {
            info.push("\n工作经历:");
            candidate.geekCard.geekWorks.forEach((work) => {
                info.push(`- ${work.company || "未知公司"} · ${work.positionName || "未知职位"}`);
                info.push(`  时间: ${work.startDate} 至 ${work.endDate || "至今"}`);
                info.push(`  职责: ${work.responsibility || "无描述"}`);
                info.push(`  工作时长: ${work.workTime || "无描述"}`);
                info.push(`  关键词: ${work.workEmphasisList || "无描述"}`);
            });
        }
        if (candidate.geekCard.geekEdus?.length > 0) {
            info.push("\n教育经历:");
            candidate.geekCard.geekEdus.forEach((edu) => {
                info.push(`- ${edu.school || "未知学校"} · ${edu.major || "未知专业"}`);
                info.push(`  学历: ${edu.degreeName || "未知"} (${edu.startDate} 至 ${edu.endDate})`);
            });
        }
        info.push(`\n最后活跃: ${candidate.activeTimeDesc || "未知"}`);
        info.push(`当前日期: ${new Date().toLocaleDateString()}`);
        return info.join("\n");
    }
}
export { BossParser };
