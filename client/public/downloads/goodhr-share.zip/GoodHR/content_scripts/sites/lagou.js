import { BaseParser } from './common.js';
class LagouParser extends BaseParser {
    constructor() {
        super();
        this.selectors = {
            container: 'position-list',
            items: 'position-item',
            name: 'position-name',
            age: 'age-info',
            education: 'edu-background',
            university: 'school-name',
            description: 'position-detail',
            clickTarget: 'position-title',
            extraSelectors: [
                { prefix: 'salary', type: '薪资' },
                { prefix: 'company-name', type: '公司' },
                { prefix: 'industry-field', type: '行业' },
                { prefix: 'position-address', type: '地点' }
            ]
        };
        this.urlInfo = {
            url: 'https://www.liepin.com/zhaopin/?key=python',
            site: '推荐人才'
        };
    }
    async checkMessageTip(element) {
        return false;
    }
    async clickMatchedItem(element) {
        try {
            const clickElement = this.getElementByClassPrefix(element, this.selectors.clickTarget);
            if (clickElement) {
                void 0;
                clickElement.click();
                return true;
            }
            else {
                void 0;
                return false;
            }
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    getSimpleCandidateInfo(data) {
        void 0;
        let data2 = "";
        data2 += "姓名：" + data.name + "\n";
        data2 += "年龄：" + data.age + "\n";
        data2 += "学历：" + data.education + "\n";
        data2 += "学校：" + data.university + "\n";
        data2 += "描述：" + data.description + "\n";
        data.extraInfo.forEach(item => {
            data2 += "额外信息：" + item.type + " " + item.value + "\n";
        });
        return data2;
    }
    async extractCandidates2(data) {
        return null;
    }
    extractCandidates(elements = null) {
    }
}
export { LagouParser };
