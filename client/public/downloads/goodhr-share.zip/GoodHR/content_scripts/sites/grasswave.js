import { BaseParser } from './common.js';
class GrassWaveParser extends BaseParser {
    constructor() {
        super();
        this.textSelectors = [
            '.job-title',
            '.job-desc',
            '.company-info',
            '.requirements'
        ];
    }
    extractCandidates(elements = null) {
        const candidates = [];
        const items = elements || document.querySelectorAll('tr');
        items.forEach(item => {
            if (item.parentElement.tagName === 'THEAD')
                return;
            let fullText = '';
            this.textSelectors.forEach(selector => {
                const elements = item.querySelectorAll(selector);
                elements.forEach(el => {
                    fullText += el.textContent.trim() + ' ';
                });
            });
            if (!fullText.trim()) {
                fullText = item.textContent.trim();
            }
            const cells = item.cells;
            if (cells.length >= 4) {
                const candidate = {
                    name: cells[0]?.textContent?.trim() || '',
                    age: parseInt(cells[1]?.textContent) || 0,
                    education: cells[2]?.textContent?.trim().replace(/学历$/, ''),
                    university: cells[3]?.textContent?.trim() || '',
                    description: fullText
                };
                if (candidate.name && candidate.age && candidate.education) {
                    candidates.push(candidate);
                }
            }
        });
        return candidates;
    }
    highlightCandidate(candidate) {
        const rows = document.querySelectorAll('tr');
        rows.forEach(row => {
            if (row.cells[0]?.textContent?.trim() === candidate.name) {
                row.style.backgroundColor = '#e8f0fe';
            }
        });
    }
}
export { GrassWaveParser };
