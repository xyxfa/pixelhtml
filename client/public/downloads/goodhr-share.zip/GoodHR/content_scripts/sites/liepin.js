import { BaseParser } from './common.js';
class LiepinParser extends BaseParser {
    constructor() {
        super();
        this.selectors = {
            container: 'recommandResumes--',
            items: 'newResumeItemWrap--',
            name: 'nest-resume-personal-name',
            age: 'personal-detail-age',
            education: 'personal-detail-edulevel',
            university: 'resume-university',
            description: 'resume-description',
            clickTarget: 'ant-lpt-btn ant-lpt-btn-primary ant-lpt-teno-btn ant-lpt-teno-btn-secondary',
            extraSelectors: [
                { prefix: 'nest-resume-personal-skills', type: '技能' },
                { prefix: 'personal-expect-content', type: '薪资' },
                { prefix: 'personal-detail-location', type: 'location' },
            ],
            continueButton: ['ant-lpt-btn ant-lpt-btn-primary ant-lpt-teno-btn ant-lpt-teno-btn-secondary', 'ant-lpt-btn ant-lpt-btn-primary ant-lpt-teno-btn ant-lpt-teno-btn-secondary'],
            phoneButton: 'im-ui-action-button action-item action-phone',
            wechatButton: 'im-ui-action-button action-item action-wechat',
            resumeButton: 'im-ui-action-button action-item action-resume',
            confirmSuoIndoButton: 'ant-im-btn ant-im-btn-primary',
        };
        this.urlInfo = {
            url: 'https://www.liepin.com/zhaopin/?key=python',
            site: '推荐人才'
        };
        this.detailSelectors = {
            detailLink: 'newResumeItem',
            closeButton: 'closeBtn--',
            viewButton: '.ant-lpt-btn.ant-lpt-btn-primary'
        };
    }
    async checkMessageTip(element) {
        return false;
    }
    queryColleagueContactedInfo(data) {
        return "";
    }
    getElementByClassPrefix(parent, prefix) {
        let element = parent.querySelector(`[class^="${prefix}"]`);
        if (!element) {
            element = parent.querySelector(`[class*="${prefix}"]`);
        }
        return element;
    }
    getSimpleCandidateInfo(data) {
        let data2 = "";
        data2 += "姓名：" + data.name + "\n";
        data2 += "年龄：" + data.age + "\n";
        data2 += "学历：" + data.education + "\n";
        data2 += "学校：" + data.university + "\n";
        data2 += "描述：" + data.description + "\n";
        data.extraInfo.forEach(item => {
            data2 += "额外信息：" + item.type + " " + item.value + "\n";
        });
        return data2;
    }
    async extractCandidates2(data) {
        const result = this.findElementsByMultipleMethods(".content--dw5Ml", {
            includeHidden: false,
            methods: ['all']
        });
        if (result.elements && result.elements.length > 0) {
            return result.elements[0].textContent;
        }
        else {
            return null;
        }
    }
    findElementsByMultipleMethods(selector, options = {}) {
        const { timeout = 0, maxRetries = 0, retryInterval = 500, includeHidden = false, methods = ['all'] } = options;
        if (timeout > 0) {
            return this.waitForElements(selector, { timeout, interval: retryInterval });
        }
        if (methods.includes('all') || methods.includes('querySelectorAll')) {
            try {
                const elements = document.querySelectorAll(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    return { elements: filteredElements, method: 'querySelectorAll' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByClassName')) && selector.startsWith('.')) {
            try {
                const className = selector.substring(1);
                const elements = document.getElementsByClassName(className);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByClassName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByTagName')) && /^[a-zA-Z]/.test(selector)) {
            try {
                const elements = document.getElementsByTagName(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByTagName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('xpath')) {
            try {
                let xpath = '';
                if (selector.startsWith('.')) {
                    const className = selector.substring(1);
                    xpath = `//*[contains(@class, '${className}')]`;
                }
                else if (selector.startsWith('#')) {
                    const id = selector.substring(1);
                    xpath = `//*[@id='${id}']`;
                }
                else if (/^[a-zA-Z]/.test(selector)) {
                    xpath = `//${selector}`;
                }
                if (xpath) {
                    const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    const elements = [];
                    for (let i = 0; i < result.snapshotLength; i++) {
                        elements.push(result.snapshotItem(i));
                    }
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'xpath' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('textSearch')) {
            try {
                const keywords = selector.match(/[^\s.#\[\]]+/g) || [];
                if (keywords.length > 0) {
                    const allElements = Array.from(document.body.getElementsByTagName('*'));
                    const elements = allElements.filter(el => {
                        const text = el.textContent || el.innerText || '';
                        return keywords.some(keyword => text.includes(keyword));
                    });
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'textSearch' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('domTraversal')) {
            try {
                const elements = [];
                const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
                    acceptNode: function (node) {
                        try {
                            if (node.matches && node.matches(selector)) {
                                return NodeFilter.FILTER_ACCEPT;
                            }
                        }
                        catch (e) {
                        }
                        return NodeFilter.FILTER_SKIP;
                    }
                });
                let node;
                while (node = walk.nextNode()) {
                    elements.push(node);
                }
                let filteredElements = elements;
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'domTraversal' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        void 0;
        return { elements: [], method: 'none', message: '未找到元素' };
    }
    isElementVisible(element) {
        if (!element)
            return false;
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
            return false;
        }
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            return false;
        }
        return true;
    }
    waitForElements(selector, options = {}) {
        const { timeout = 3000, interval = 100 } = options;
        return new Promise((resolve) => {
            const startTime = Date.now();
            const check = () => {
                const elements = document.querySelectorAll(selector);
                const visibleElements = Array.from(elements).filter(el => this.isElementVisible(el));
                if (visibleElements.length > 0) {
                    resolve({ elements: visibleElements, method: 'waitForElements' });
                }
                else if (Date.now() - startTime > timeout) {
                    resolve({ elements: [], method: 'waitForElements', message: '超时未找到元素' });
                }
                else {
                    setTimeout(check, interval);
                }
            };
            check();
        });
    }
    extractCandidates(elements = null) {
        const candidates = [];
        let items;
        try {
            if (elements) {
                items = elements;
            }
            else {
                items = document.querySelectorAll(`[class^="${this.selectors.items}"], [class*=" ${this.selectors.items}"]`);
                if (items.length === 0) {
                    void 0;
                    void 0;
                    throw new Error('未找到任何候选人元素，请检查选择器是否正确');
                }
            }
            Array.from(items).forEach((item, index) => {
                try {
                    const nameElement = this.getElementByClassPrefix(item, this.selectors.name);
                    const ageElement = this.getElementByClassPrefix(item, this.selectors.age);
                    const educationElement = this.getElementByClassPrefix(item, this.selectors.education);
                    const universityElement = this.getElementByClassPrefix(item, this.selectors.university);
                    const descriptionElement = this.getElementByClassPrefix(item, this.selectors.description);
                    const extraInfo = this.extractExtraInfo(item, this.selectors.extraSelectors);
                    const candidate = {
                        name: nameElement?.textContent?.trim() || '',
                        age: parseInt(ageElement?.textContent) || 0,
                        education: educationElement?.textContent?.trim() || '',
                        university: universityElement?.textContent?.trim() || '',
                        description: descriptionElement?.textContent?.trim() || item.textContent?.trim() || '',
                        extraInfo: extraInfo
                    };
                    if (candidate.name) {
                        candidates.push(candidate);
                    }
                    else {
                        this.clearHighlight(item);
                        void 0;
                    }
                }
                catch (error) {
                    void 0;
                    this.clearHighlight(item);
                }
            });
        }
        catch (error) {
            void 0;
            throw error;
        }
        return candidates;
    }
    async clickMatchedItem(element) {
        try {
            const clickElement = this.getElementByClassPrefix(element, this.selectors.clickTarget);
            if (clickElement) {
                clickElement.click();
                return true;
            }
            else {
                void 0;
                return false;
            }
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async clickCandidateDetail(element) {
        try {
            const detailLink = this.getElementByClassPrefix(element, this.detailSelectors.detailLink);
            if (detailLink) {
                detailLink.click();
                return true;
            }
            void 0;
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async collectPhoneWechatResume(phone, wechat, resume, candidate, element) {
        try {
            for (let i = 0; i < this.selectors.continueButton.length; i++) {
                const continueButton = this.getElementByClassPrefix(element, this.selectors.continueButton[i]);
                if (continueButton) {
                    continueButton.click();
                }
                else {
                    void 0;
                    return null;
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            if (phone) {
                void 0;
                const phoneButton = this.getElementByClassPrefix(document, this.selectors.phoneButton);
                await new Promise(resolve => setTimeout(resolve, 500));
                if (phoneButton) {
                    phoneButton.click();
                }
            }
            if (wechat) {
                void 0;
                const wechatButton = this.getElementByClassPrefix(document, this.selectors.wechatButton);
                if (wechatButton) {
                    wechatButton.click();
                }
            }
            if (resume) {
                void 0;
                const resumeButton = this.getElementByClassPrefix(document, this.selectors.resumeButton);
                if (resumeButton) {
                    resumeButton.click();
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            void 0;
            const confirmButtons = document.querySelectorAll(`[class^="${this.selectors.confirmSuoIndoButton}"]`);
            if (!confirmButtons) {
                confirmButtons = document.querySelectorAll(`[class*="${this.selectors.confirmSuoIndoButton}"]`);
            }
            void 0;
            if (confirmButtons.length > 0) {
                confirmButtons.forEach(button => button.click());
            }
            const confirmButton = document.querySelector(`[class^="ant-im-btn ant-im-btn-text ant-im-btn-sm ant-im-btn-icon-only ant-im-teno-btn"]`);
            if (confirmButton) {
                confirmButton.click();
            }
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    async closeDetail() {
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            const closeButton = document.querySelector(`[class*="${this.detailSelectors.closeButton}"]`);
            if (closeButton) {
                void 0;
                closeButton.click();
                return true;
            }
            void 0;
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async processCommunication(candidate) {
        try {
            const candidateInfo = this.getSimpleCandidateInfo(candidate);
            let communicationContent = "";
            if (this.companyInfo) {
                communicationContent += `公司名称：${this.companyInfo.name || ''}\n`;
                communicationContent += `公司地址：${this.companyInfo.address || ''}\n`;
                communicationContent += `公司规模：${this.companyInfo.size || ''}\n`;
                communicationContent += `公司类型：${this.companyInfo.type || ''}\n`;
                communicationContent += `所属行业：${this.companyInfo.industry || ''}\n`;
                communicationContent += `公司介绍：${this.companyInfo.description || ''}\n`;
                communicationContent += `公司官网：${this.companyInfo.website || ''}\n`;
                communicationContent += `联系电话：${this.companyInfo.phone || ''}\n`;
                communicationContent += `联系邮箱：${this.companyInfo.email || ''}\n\n`;
            }
            if (this.jobInfo) {
                communicationContent += `岗位名称：${this.jobInfo.title || ''}\n`;
                communicationContent += `岗位职责：${this.jobInfo.duty || ''}\n`;
                communicationContent += `岗位要求：${this.jobInfo.requirement || ''}\n`;
                communicationContent += `经验要求：${this.jobInfo.experience || ''}\n`;
                communicationContent += `学历要求：${this.jobInfo.education || ''}\n`;
                communicationContent += `薪资范围：${this.jobInfo.salary || ''}\n`;
                communicationContent += `工作地点：${this.jobInfo.location || ''}\n`;
                communicationContent += `工作性质：${this.jobInfo.type || ''}\n`;
                communicationContent += `岗位类别：${this.jobInfo.category || ''}\n`;
                communicationContent += `岗位描述：${this.jobInfo.description || ''}\n\n`;
            }
            communicationContent += `候选人信息：\n${candidateInfo}\n\n`;
            void 0;
            return true;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
}
export { LiepinParser };
