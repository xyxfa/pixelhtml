import { BaseParser } from './common.js';
class ZhilianParser extends BaseParser {
    constructor() {
        super();
        this.selectors = {
            container: '[role="group"]',
            items: 'recommend-item__inner recommend-resume-item__inner',
            name: '.talent-basic-info__name--inner',
            age: '.talent-basic-info__basic',
            education: '.resume-item__content.resume-card-exp',
            university: 'fasdfasdfasdf',
            description: '.resume-item__content',
            clickTarget: 'small-screen-btn is-mr-16',
            extraSelectors: [
                { selector: '.talent-basic-info__extra--content', type: '薪资' },
                { selector: 'fasdfasdf', type: '地点' },
                { selector: 'fasdfasdf', type: '经验' },
                { selector: 'sdfasdf', type: '标签' }
            ],
            xiangqing: ['new-resume-detail--inner', 'km-scrollbar__view', 'km-scrollbar__wrap'],
            continueButton: [
                'small-screen-btn is-mr-16 km-button km-control km-ripple-off km-button--light km-button--plain resume-btn-small',
            ],
            phoneButton: 'km-button km-control km-ripple-off km-button--light km-button--outlined',
            wechatButton: 'im-ui-action-button action-item action-wechat',
            resumeButton: 'im-ui-action-button action-item action-resume',
            confirmSuoIndoButton: 'ant-im-btn ant-im-btn-primary',
        };
        this.urlInfo = {
            url: 'https://www.liepin.com/zhaopin/?key=python',
            site: '推荐人才'
        };
        this.detailSelectors = {
            detailLink: [
                '.talent-basic-info__name--inner',
                '.resume-item__content.resume-card-exp',
                '.resume-item__content',
                '[class*="recommend-resume-item"]',
                '[class*="recommend-item"]'
            ],
            closeButton: [
                '.km-icon.sati.sati-times-circle-s',
                '[class*="times-circle"]',
                '[class*="resume-detail"] [class*="close"]',
                '[class*="drawer"] [class*="close"]',
                '[aria-label="关闭"]'
            ],
            viewButton: '.km-button--primary'
        };
    }
    getElementByClassPrefix(parent, prefix) {
        let element = parent.querySelector(`[class^="${prefix}"]`);
        if (!element) {
            element = parent.querySelector(`[class*="${prefix}"]`);
        }
        return element;
    }
    async checkMessageTip(element) {
        return false;
    }
    async collectPhoneWechatResume(phone, wechat, resume, candidate, element) {
        try {
            await new Promise(resolve => setTimeout(resolve, 1000));
            for (let i = 0; i < this.selectors.continueButton.length; i++) {
                const continueButton = element.querySelectorAll(`[class^="${this.selectors.continueButton[i]}"]`);
                for (let j = 0; j < continueButton.length; j++) {
                    continueButton[j].click();
                    await new Promise(resolve => setTimeout(resolve, 500));
                    continueButton[j].click();
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            const suoyaolist = document.querySelectorAll(`[class^="${this.selectors.phoneButton}"]`);
            if (!suoyaolist) {
                void 0;
                return null;
            }
            if (phone) {
                suoyaolist[0].click();
                await new Promise(resolve => setTimeout(resolve, 200));
                const confirmphoneButton = document.querySelector(`[class^="is-ml-0 km-button km-control km-ripple-off km-button--primary km-button--outlined"]`);
                if (confirmphoneButton) {
                    confirmphoneButton.click();
                }
            }
            if (wechat) {
                suoyaolist[1].click();
                const confirmphoneButton = document.querySelector(`[class^="is-ml-0 km-button km-control km-ripple-off km-button--primary km-button--outlined"]`);
                if (confirmphoneButton) {
                    confirmphoneButton.click();
                }
            }
            if (resume) {
                suoyaolist[2].click();
                const confirmphoneButton = document.querySelector(`[class^="is-ml-0 km-button km-control km-ripple-off km-button--primary km-button--outlined"]`);
                if (confirmphoneButton) {
                    confirmphoneButton.click();
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            const closeButton = document.querySelector(`[class^="im-widget-session__close"]`);
            if (closeButton) {
                closeButton.click();
            }
            const closeButton2 = document.querySelector(`[class^="km-icon sati ignore-im-widget-click sati-times"]`);
            if (closeButton2) {
                closeButton2.click();
            }
        }
        catch (error) {
            void 0;
            return null;
        }
    }
    findElements() {
        return document.querySelectorAll(this.selectors.items);
    }
    isElementVisible(element) {
        if (!element)
            return false;
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
            return false;
        }
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            return false;
        }
        return true;
    }
    waitForElements(selector, options = {}) {
        const { timeout = 3000, interval = 100 } = options;
        return new Promise((resolve) => {
            const startTime = Date.now();
            const check = () => {
                const elements = document.querySelectorAll(selector);
                const visibleElements = Array.from(elements).filter(el => this.isElementVisible(el));
                if (visibleElements.length > 0) {
                    resolve({ elements: visibleElements, method: 'waitForElements' });
                }
                else if (Date.now() - startTime > timeout) {
                    resolve({ elements: [], method: 'waitForElements', message: '超时未找到元素' });
                }
                else {
                    setTimeout(check, interval);
                }
            };
            check();
        });
    }
    findElementsByMultipleMethods(selector, options = {}) {
        const { timeout = 0, maxRetries = 0, retryInterval = 500, includeHidden = false, methods = ['all'] } = options;
        if (timeout > 0) {
            return this.waitForElements(selector, { timeout, interval: retryInterval });
        }
        if (methods.includes('all') || methods.includes('querySelectorAll')) {
            try {
                const elements = document.querySelectorAll(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    return { elements: filteredElements, method: 'querySelectorAll' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByClassName')) && selector.startsWith('.')) {
            try {
                const className = selector.substring(1);
                const elements = document.getElementsByClassName(className);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByClassName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if ((methods.includes('all') || methods.includes('getElementsByTagName')) && /^[a-zA-Z]/.test(selector)) {
            try {
                const elements = document.getElementsByTagName(selector);
                let filteredElements = Array.from(elements);
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'getElementsByTagName' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('xpath')) {
            try {
                let xpath = '';
                if (selector.startsWith('.')) {
                    const className = selector.substring(1);
                    xpath = `//*[contains(@class, '${className}')]`;
                }
                else if (selector.startsWith('#')) {
                    const id = selector.substring(1);
                    xpath = `//*[@id='${id}']`;
                }
                else if (/^[a-zA-Z]/.test(selector)) {
                    xpath = `//${selector}`;
                }
                if (xpath) {
                    const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    const elements = [];
                    for (let i = 0; i < result.snapshotLength; i++) {
                        elements.push(result.snapshotItem(i));
                    }
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'xpath' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('textSearch')) {
            try {
                const keywords = selector.match(/[^\s.#\[\]]+/g) || [];
                if (keywords.length > 0) {
                    const allElements = Array.from(document.body.getElementsByTagName('*'));
                    const elements = allElements.filter(el => {
                        const text = el.textContent || el.innerText || '';
                        return keywords.some(keyword => text.includes(keyword));
                    });
                    let filteredElements = elements;
                    if (!includeHidden) {
                        filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                    }
                    if (filteredElements.length > 0) {
                        void 0;
                        return { elements: filteredElements, method: 'textSearch' };
                    }
                }
            }
            catch (e) {
                void 0;
            }
        }
        if (methods.includes('all') || methods.includes('domTraversal')) {
            try {
                const elements = [];
                const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
                    acceptNode: function (node) {
                        try {
                            if (node.matches && node.matches(selector)) {
                                return NodeFilter.FILTER_ACCEPT;
                            }
                        }
                        catch (e) {
                        }
                        return NodeFilter.FILTER_SKIP;
                    }
                });
                let node;
                while (node = walk.nextNode()) {
                    elements.push(node);
                }
                let filteredElements = elements;
                if (!includeHidden) {
                    filteredElements = filteredElements.filter(el => this.isElementVisible(el));
                }
                if (filteredElements.length > 0) {
                    void 0;
                    return { elements: filteredElements, method: 'domTraversal' };
                }
            }
            catch (e) {
                void 0;
            }
        }
        void 0;
        return { elements: [], method: 'none', message: '未找到元素' };
    }
    getSimpleCandidateInfo(data) {
        void 0;
        let data2 = "";
        data2 += "姓名：" + data.name + "\n";
        data2 += "年龄：" + data.age + "\n";
        data2 += "学历：" + data.education + "\n";
        data2 += "学校：" + data.university + "\n";
        data2 += "描述：" + data.description + "\n";
        data.extraInfo.forEach(item => {
            data2 += "额外信息：" + item.type + " " + item.value + "\n";
        });
        return data2;
    }
    queryColleagueContactedInfo(data) {
        return "";
    }
    async extractCandidates2(data) {
        const result = this.findElementsByMultipleMethods(".new-shortcut-resume--wrapper", {
            includeHidden: false,
            methods: ['all']
        });
        if (result.elements && result.elements.length > 0) {
            return result.elements[0].textContent;
        }
        else {
            return null;
        }
    }
    extractCandidates(elements = null) {
        const candidates = [];
        try {
            const items = elements || this.findElements();
            Array.from(items).forEach((item, index) => {
                try {
                    const nameElement = item.querySelector(this.selectors.name);
                    const ageElement = item.querySelector(this.selectors.age);
                    const educationElement = item.querySelector(this.selectors.education);
                    const universityElement = item.querySelector(this.selectors.university);
                    const descriptionElement = item.querySelector(this.selectors.description);
                    const extraInfo = this.selectors.extraSelectors.map(selector => {
                        const element = item.querySelector(selector.selector);
                        return element ? {
                            type: selector.type,
                            value: element.textContent?.trim() || ''
                        } : null;
                    }).filter(info => info !== null);
                    const candidate = {
                        name: nameElement?.textContent?.trim() || '',
                        age: this.extractAge(ageElement?.textContent),
                        education: educationElement?.textContent?.trim() || '',
                        university: universityElement?.textContent?.trim() || '',
                        description: descriptionElement?.textContent?.trim() || '',
                        extraInfo: extraInfo
                    };
                    if (candidate.name) {
                        candidates.push(candidate);
                    }
                }
                catch (error) {
                    void 0;
                }
            });
        }
        catch (error) {
            void 0;
            throw error;
        }
        return candidates;
    }
    async clickMatchedItem(element) {
        try {
            const greetButton = element.querySelector(`[class^="${this.selectors.clickTarget}"]`);
            if (greetButton) {
                greetButton.click();
                try {
                    if (this.filterSettings.communicationConfig.collectPhone || this.filterSettings.communicationConfig.collectWechat || this.filterSettings.communicationConfig.collectResume) {
                        greetButton.click();
                    }
                }
                catch (error) {
                    void 0;
                }
                return true;
            }
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async clickCandidateDetail(element) {
        try {
            for (const selector of this.detailSelectors.detailLink) {
                const detailLink = element.querySelector(selector);
                if (detailLink) {
                    detailLink.scrollIntoView?.({ block: 'center', inline: 'nearest', behavior: 'auto' });
                    detailLink.click();
                    return true;
                }
            }
            element.scrollIntoView?.({ block: 'center', inline: 'nearest', behavior: 'auto' });
            element.click();
            return true;
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    async closeDetail() {
        try {
            for (const selector of this.detailSelectors.closeButton) {
                const closeButton = document.querySelector(selector);
                if (closeButton) {
                    closeButton.click();
                    return true;
                }
            }
            return false;
        }
        catch (error) {
            void 0;
            return false;
        }
    }
    extractAge(text) {
        if (!text)
            return 0;
        const matches = text.match(/(\d+)/);
        return matches ? parseInt(matches[1]) : 0;
    }
}
export { ZhilianParser };
