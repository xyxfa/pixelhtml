(function injectBossInterceptor() {
    'use strict';
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('content_scripts/sites/boss_interceptor.js');
    script.async = false;
    (document.head || document.documentElement).appendChild(script);
    script.onload = function () {
        script.parentNode && script.parentNode.removeChild(script);
    };
    script.onerror = function () {
        void 0;
    };
})();
