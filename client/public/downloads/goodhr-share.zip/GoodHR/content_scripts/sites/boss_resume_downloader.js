const BOSS_SELECTORS = {
    CANDIDATE_LIST: '[role="group"]',
    CANDIDATE_ITEM: '[role="listitem"]',
    CANDIDATE_CLICKABLE: '.geek-item-wrap',
    RESUME_BUTTON: '.btn.resume-btn-file',
    DOWNLOAD_BUTTON: 'popover icon-content popover-bottom',
    CANDIDATE_NAME: '.geek-name',
    CANDIDATE_SKILLS: '.source-job',
    dialogWrap: '.boss-popup__close'
};
window.BossResumeDownloader = class BossResumeDownloader {
    constructor() {
        this.isRunning = false;
        this.getRandomDelay = () => Math.floor(Math.random() * 1000) + 1000;
        this.downloadCount = 0;
        this.currentCandidate = null;
    }
    async start() {
        if (this.isRunning)
            return;
        this.isRunning = true;
        try {
            await this.processNextCandidate();
        }
        catch (error) {
            void 0;
            this.stop();
        }
    }
    stop() {
        this.isRunning = false;
        chrome.runtime.sendMessage({ type: 'DOWNLOAD_STOPPED' });
    }
    async processNextCandidate() {
        if (!this.isRunning)
            return;
        void 0;
        const candidates = document.querySelectorAll(`${BOSS_SELECTORS.CANDIDATE_LIST} ${BOSS_SELECTORS.CANDIDATE_ITEM}:not(.processed)`);
        void 0;
        if (!candidates.length) {
            this.stop();
            chrome.runtime.sendMessage({
                type: 'DOWNLOAD_COMPLETE',
                data: { totalCount: this.downloadCount }
            });
            return;
        }
        const candidate = candidates[0];
        try {
            window.currentCandidateInfo = {
                name: candidate.querySelector(BOSS_SELECTORS.CANDIDATE_NAME)?.textContent?.trim(),
                skills: candidate.querySelector(BOSS_SELECTORS.CANDIDATE_SKILLS)?.textContent?.trim(),
                element: candidate
            };
            void 0;
            void 0;
            candidate.style.backgroundColor = '#fff3e0';
            candidate.style.transition = 'background-color 0.3s';
            const clickableArea = candidate.querySelector(BOSS_SELECTORS.CANDIDATE_CLICKABLE);
            if (!clickableArea) {
                throw new Error('未找到可点击区域');
            }
            void 0;
            clickableArea.click();
            void 0;
            void 0;
            await this.sleep(3000);
            let resumeBtn = null;
            let retryCount = 0;
            const maxRetries = 10;
            while (!resumeBtn && retryCount < maxRetries) {
                resumeBtn = document.querySelector(BOSS_SELECTORS.RESUME_BUTTON);
                if (!resumeBtn) {
                    void 0;
                    await this.sleep(500);
                    retryCount++;
                }
            }
            void 0;
            if (resumeBtn) {
                resumeBtn.click();
                void 0;
                void 0;
                await this.sleep(1000);
                let downloadBtns = [];
                let downloadCount = 0;
                const downloadRetries = 20;
                let lastLength = 0;
                while (downloadCount < downloadRetries) {
                    downloadBtns = document.getElementsByClassName(BOSS_SELECTORS.DOWNLOAD_BUTTON);
                    const currentLength = downloadBtns?.length || 0;
                    if (currentLength !== lastLength) {
                        void 0;
                        lastLength = currentLength;
                        downloadCount = 0;
                        if (currentLength === 3) {
                            await this.sleep(500);
                            break;
                        }
                    }
                    if (downloadCount === 10 && downloadBtns?.length === 1) {
                        void 0;
                        break;
                    }
                    void 0;
                    await this.sleep(500);
                    downloadCount++;
                }
                if (downloadBtns && downloadBtns.length > 2) {
                    const downloadBtn = downloadBtns[downloadBtns.length - 1];
                    void 0;
                    void 0;
                    try {
                        void 0;
                        const clickEvent = new MouseEvent('click', {
                            view: window,
                            bubbles: true,
                            cancelable: true
                        });
                        downloadBtn.dispatchEvent(clickEvent);
                        const possibleElements = downloadBtn.querySelectorAll('a, button, [role="button"], span, div, svg, use');
                        void 0;
                        await this.sleep(500);
                        for (const element of possibleElements) {
                            try {
                                void 0;
                                element.click();
                            }
                            catch (err) {
                                void 0;
                            }
                        }
                        this.downloadCount++;
                        await this.sleep(1000);
                    }
                    catch (error) {
                        void 0;
                        throw new Error('点击下载按钮失败');
                    }
                }
                else {
                    void 0;
                    throw new Error('未找到下载按钮');
                }
                const closeBtn = await this.waitForElement(BOSS_SELECTORS.dialogWrap);
                if (closeBtn) {
                    closeBtn.click();
                    void 0;
                }
                chrome.runtime.sendMessage({
                    type: 'RESUME_DOWNLOADED',
                    data: {
                        name: "1",
                        skills: "1",
                        count: 1
                    }
                });
            }
            else {
                void 0;
                throw new Error('未找到简历按钮');
            }
            candidate.classList.add('processed');
            candidate.style.backgroundColor = '#e8f5e9';
            const randomDelay = this.getRandomDelay();
            void 0;
            await this.sleep(randomDelay);
            await this.processNextCandidate();
        }
        catch (error) {
            this.currentCandidate = null;
            void 0;
            candidate.style.backgroundColor = '#ffebee';
            this.stop();
        }
    }
    async waitForElement(selector, timeout = 5000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const element = document.querySelector(selector);
            if (element)
                return element;
            await this.sleep(100);
        }
        return null;
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    waitForDownload() {
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                reject(new Error('下载超时'));
            }, 30000);
            const handler = (message) => {
                if (message.type === 'RESUME_DOWNLOAD_COMPLETED') {
                    clearTimeout(timeout);
                    chrome.runtime.onMessage.removeListener(handler);
                    resolve();
                }
            };
            chrome.runtime.onMessage.addListener(handler);
        });
    }
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'GET_CANDIDATE_INFO' && window.resumeDownloader?.downloader) {
        sendResponse(window.resumeDownloader.downloader.currentCandidate);
    }
    return true;
});
