window.addEventListener('load', async function () {
    if (isCandidateDetailPage()) {
        const clickTimestamp = localStorage.getItem('goodhr-candidate-click-timestamp');
        const currentTime = Date.now();
        if (clickTimestamp) {
            const timeDiff = currentTime - parseInt(clickTimestamp);
            if (timeDiff < 10000) {
                await processCandidateDetail();
            }
            else {
                localStorage.removeItem('goodhr-candidate-click-timestamp');
                return false;
            }
        }
        else {
            void 0;
        }
    }
    else {
        void 0;
    }
});
async function processCandidateDetail() {
    try {
        const candidateDetail = await extractCandidateDetail();
        const requestId = 'req-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        const storageData = {
            source: 'goodhr-plugin',
            type: 'candidate-detail-response',
            requestId: requestId,
            data: candidateDetail,
            timestamp: Date.now()
        };
        localStorage.setItem('goodhr-candidate-detail', JSON.stringify(storageData));
        localStorage.removeItem('goodhr-candidate-click-timestamp');
        setTimeout(() => {
            window.close();
        }, 2000);
    }
    catch (error) {
        void 0;
        localStorage.removeItem('goodhr-candidate-click-timestamp');
        window.close();
    }
}
function isCandidateDetailPage() {
    return window.location.href.includes('/showresumedetail/');
}
async function extractCandidateDetail() {
    try {
        const candidate = {};
        let nameElement = null;
        let textElement = null;
        let attempts = 0;
        const maxAttempts = 20;
        while (attempts < maxAttempts) {
            nameElement = document.querySelector('[class*="name-box"]');
            textElement = document.querySelector('[class*="ant-tabs-tabpane ant-tabs-tabpane-active"]');
            if (nameElement && nameElement.textContent.trim() &&
                textElement && textElement.textContent.trim()) {
                break;
            }
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
        candidate.name = nameElement ? nameElement.textContent.trim() : '';
        candidate.textContent = textElement ? textElement.textContent.trim() : '';
        if (attempts >= maxAttempts && (!candidate.name || !candidate.textContent)) {
            void 0;
        }
        return candidate;
    }
    catch (error) {
        void 0;
        return { error: '提取候选人详细信息时出错', message: error.message };
    }
}
