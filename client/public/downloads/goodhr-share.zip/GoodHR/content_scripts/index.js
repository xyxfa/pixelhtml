let currentParser = null;
let scrollInterval = null;
let lastProcessedPosition = 0;
let isRunning = false;
let currentDelay = 3000;
let matchLimit = 0;
let scrollDelayMin = 3000;
let scrollDelayMax = 6000;
let port = null;
let matchCount = 0;
let currentPrompt = null;
let enableSound = false;
let ParserName = null;
function showNotification(message, type = 'status') {
    if (!isExtensionValid()) {
        void 0;
        return;
    }
    const notification = document.createElement('div');
    let baseStyle = `
        position: fixed;
        padding: 12px 20px;
        background: rgba(51, 51, 51, 0.9);
        color: white;
        border-radius: 6px;
        z-index: 9999;
        font-size: 14px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.2);
        pointer-events: none;
    `;
    if (type === 'status') {
        baseStyle += `
            left: 50%;
            top: 20px;
            transform: translateX(-50%);
        `;
    }
    else {
        baseStyle += `
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        `;
    }
    notification.style.cssText = baseStyle;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.remove();
    }, 1500);
}
async function initializeParser() {
    try {
        const url = window.location.href;
        const extensionUrl = chrome.runtime.getURL('');
        if (url.includes('zhipin.com')) {
            ParserName = 'boos';
            const { BossParser } = await import(extensionUrl + 'content_scripts/sites/boss.js');
            currentParser = new BossParser();
            const isInIframe = window !== window.top;
            if (!isInIframe) {
                createDraggablePrompt();
            }
        }
        else if (url.includes('lagou.com')) {
            ParserName = 'lagou';
            const { LagouParser } = await import(extensionUrl + 'content_scripts/sites/lagou.js');
            currentParser = new LagouParser();
            createDraggablePrompt();
        }
        else if (url.includes('lpt.liepin.com')) {
            ParserName = 'liepin';
            const { LiepinParser } = await import(extensionUrl + 'content_scripts/sites/liepin.js');
            currentParser = new LiepinParser();
            createDraggablePrompt();
        }
        else if (url.includes('h.liepin.com')) {
            ParserName = 'hliepin';
            const { HLiepinParser } = await import(extensionUrl + 'content_scripts/sites/hliepin.js');
            currentParser = new HLiepinParser();
            createDraggablePrompt();
        }
        else if (url.includes('employer.58.com')) {
            ParserName = 'employer58';
            const { Employer58Parser } = await import(extensionUrl + 'content_scripts/sites/employer58.js');
            currentParser = new Employer58Parser();
            createDraggablePrompt();
        }
        else if (url.includes('zhaopin.com')) {
            ParserName = 'zhilian';
            const { ZhilianParser } = await import(extensionUrl + 'content_scripts/sites/zhilian.js');
            currentParser = new ZhilianParser();
            createDraggablePrompt();
        }
        if (currentParser) {
            await currentParser.loadSettings();
            void 0;
        }
        else {
        }
    }
    catch (error) {
        void 0;
        showNotification('⚠️ 初始化解析器失败: ' + error.message, 'status');
        currentParser = null;
    }
}
function randomDelay(message2 = "无") {
    let currentMin, currentMax;
    if (currentParser?.aiMode) {
        currentMin = currentParser?.aiSettings?.scrollDelayMin || 3;
        currentMax = currentParser?.aiSettings?.scrollDelayMax || 5;
    }
    else {
        currentMin = currentParser?.filterSettings?.scrollDelayMin || 3;
        currentMax = currentParser?.filterSettings?.scrollDelayMax || 5;
    }
    const actualMin = currentMin;
    const actualMax = currentMax;
    const delaySeconds = Math.floor(Math.random() * (actualMax - actualMin + 1) + actualMin);
    const delayMs = delaySeconds * 1000;
    sendMessage({
        type: 'LOG_MESSAGE',
        data: {
            message: `随机停止 ${delaySeconds} 秒 ${message2}`,
            type: 'info'
        }
    });
    return new Promise(resolve => setTimeout(resolve, delayMs));
}
function triggerNativeClick(target) {
    if (!target) {
        return false;
    }
    try {
        target.scrollIntoView?.({
            block: 'center',
            inline: 'nearest',
            behavior: 'auto'
        });
    }
    catch (error) {
        void 0;
    }
    try {
        const clickEvents = ['pointerdown', 'mousedown', 'mouseup', 'click'];
        clickEvents.forEach(type => {
            target.dispatchEvent(new MouseEvent(type, {
                bubbles: true,
                cancelable: true,
                view: window
            }));
        });
        target.click?.();
        return true;
    }
    catch (error) {
        void 0;
        return false;
    }
}
function findCandidateDetailFallbackTargets(element) {
    if (!element) {
        return [];
    }
    const selector = [
        'a',
        'button',
        '[role="button"]',
        '[class*="name"]',
        '[class*="title"]',
        '[class*="resume"]',
        '[class*="card"]',
        '[class*="content"]',
        '[class*="item"]'
    ].join(', ');
    return [
        element.querySelector(selector),
        element.firstElementChild,
        element
    ].filter(Boolean);
}
async function openCandidateDetailWithFallback(element, candidateName = '') {
    try {
        const clicked = await currentParser.clickCandidateDetail(element);
        if (clicked) {
            return true;
        }
    }
    catch (error) {
        void 0;
    }
    const visited = new Set();
    const fallbackTargets = findCandidateDetailFallbackTargets(element);
    for (const target of fallbackTargets) {
        if (!target || visited.has(target)) {
            continue;
        }
        visited.add(target);
        const fallbackClicked = triggerNativeClick(target);
        if (fallbackClicked) {
            void 0;
            await new Promise(resolve => setTimeout(resolve, 350));
            return true;
        }
    }
    return false;
}
function getAllDocuments() {
    const documents = [document];
    const frames = document.getElementsByTagName('iframe');
    for (const frame of frames) {
        try {
            if (frame.contentDocument) {
                documents.push(frame.contentDocument);
            }
        }
        catch (error) {
            void 0;
        }
    }
    return documents;
}
async function startAutoScroll() {
    if (isRunning)
        return;
    if (currentParser?.aiMode) {
        if (!currentParser?.aiSettings?.aiConfig?.token) {
            void 0;
            sendMessage({
                type: 'LOG_MESSAGE',
                data: {
                    message: 'AI模式需要配置Token，请先配置AI设置',
                    type: 'error'
                }
            });
            showNotification('⚠️ AI模式需要配置Token', 'status');
            return;
        }
        if (!currentParser?.aiSettings?.jobDescription || !currentParser.aiSettings.jobDescription.trim()) {
            void 0;
            sendMessage({
                type: 'LOG_MESSAGE',
                data: {
                    message: 'AI模式需要填写岗位说明',
                    type: 'error'
                }
            });
            showNotification('⚠️ AI模式需要填写岗位说明', 'status');
            return;
        }
    }
    try {
        isRunning = true;
        lastProcessedPosition = 0;
        if (currentParser.aiMode) {
            matchLimit = currentParser?.aiSettings?.matchLimit || 200;
            scrollDelayMin = currentParser?.aiSettings?.scrollDelayMin || 3;
            scrollDelayMax = currentParser?.aiSettings?.scrollDelayMax || 5;
        }
        else {
            matchLimit = currentParser?.filterSettings?.matchLimit || 200;
            scrollDelayMin = currentParser?.filterSettings?.scrollDelayMin || 3;
            scrollDelayMax = currentParser?.filterSettings?.scrollDelayMax || 5;
        }
        window.scrollTo(0, 0);
        sendMessage({
            type: 'LOG_MESSAGE',
            data: {
                message: `开始滚动`,
                type: 'info'
            }
        });
        executeScroll();
        showNotification('开始自动滚动', 'status');
    }
    catch (error) {
        isRunning = false;
        void 0;
        showNotification('⚠️ ' + error.message, 'status');
        throw error;
    }
}
async function executeScroll() {
    if (!isRunning || !currentParser) {
        if (scrollInterval) {
            clearInterval(scrollInterval);
            scrollInterval = null;
        }
        isRunning = false;
        return;
    }
    try {
        await currentParser.loadSettings();
        const documents = getAllDocuments();
        for (const doc of documents) {
            let elements = [];
            if (typeof currentParser.selectors.items === 'array') {
                for (const item of currentParser.selectors.items) {
                    const selector = '.' + item;
                    const elements = Array.from(doc.querySelectorAll(selector));
                    if (elements.length > 0) {
                        elements.push(...elements);
                    }
                }
            }
            else {
                const selector = '.' + currentParser.selectors.items;
                elements = Array.from(doc.querySelectorAll(selector));
                if (elements.length > 0) {
                    elements.push(...elements);
                }
            }
            if (elements.length === 0) {
                const looseSelector = `[class*="${currentParser.selectors.items}"]`;
                const looseElements = Array.from(doc.querySelectorAll(looseSelector));
                if (looseElements.length > 0) {
                    elements.push(...looseElements);
                }
            }
            const unprocessedElements = elements.filter(el => {
                const rect = el.getBoundingClientRect();
                const absoluteTop = rect.top + (doc === document ?
                    window.pageYOffset :
                    doc.defaultView.pageYOffset);
                return absoluteTop > lastProcessedPosition;
            });
            if (unprocessedElements.length > 0) {
                const element = unprocessedElements[0];
                try {
                    const rect = element.getBoundingClientRect();
                    const scrollTo = rect.top + window.pageYOffset - 100;
                    window.scrollTo({
                        top: scrollTo,
                        behavior: 'smooth'
                    });
                    const tempStyleEl = document.createElement('style');
                    const tempClass = 'temp-highlight-' + Math.random().toString(36).substr(2, 9);
                    element.classList.add(tempClass);
                    tempStyleEl.textContent = `
                        .${tempClass} {
                            background-color: rgba(255, 247, 224, 0.8) !important;
                            transition: all 0.3s ease !important;
                            outline: 2px dashed #ffa726 !important;
                            position: relative !important;
                            box-shadow: 0 0 20px rgba(255, 167, 38, 0.6) !important;
                        }
                    `;
                    document.head.appendChild(tempStyleEl);
                    await processElement(element, doc);
                    element.classList.remove(tempClass);
                    tempStyleEl.remove();
                    await new Promise(resolve => setTimeout(resolve, 500));
                    executeScroll();
                    return;
                }
                catch (error) {
                    void 0;
                    executeScroll();
                    return;
                }
            }
            else {
                if (ParserName === 'hliepin' && currentParser && typeof currentParser.shouldNavigateToNextPage === 'function') {
                    const shouldNavigate = currentParser.shouldNavigateToNextPage(elements);
                    if (shouldNavigate) {
                        void 0;
                        await currentParser.clickNextPageButton();
                        await new Promise(resolve => setTimeout(resolve, 3000));
                        await currentParser.loadSettings();
                        window.scrollTo(0, 0);
                        lastProcessedPosition = 0;
                        executeScroll();
                        return;
                    }
                }
                window.scrollBy({
                    top: 200,
                    behavior: 'smooth'
                });
                executeScroll();
                return;
            }
        }
    }
    catch (error) {
        void 0;
        showNotification('⚠️ 滚动处理出错', 'status');
        stopAutoScroll();
    }
}
function truncateDecisionText(text, maxLength = 42) {
    const normalized = String(text || '').replace(/\s+/g, ' ').trim();
    if (!normalized)
        return '';
    return normalized.length > maxLength ? `${normalized.slice(0, maxLength - 1)}…` : normalized;
}
function extractReadableDetail(text) {
    const normalized = String(text || '').trim();
    if (!normalized)
        return '';
    if (normalized.startsWith('{') && normalized.includes('"detail"')) {
        const detailMatch = normalized.match(/"detail"\s*:\s*"([^"]+)"/i);
        if (detailMatch?.[1]) {
            return detailMatch[1].trim();
        }
    }
    return normalized
        .replace(/^\{[\s\S]*?"detail"\s*:\s*"/i, '')
        .replace(/"\s*,?\s*"?(?:matched_points|risks|decision|reason)?[\s\S]*$/i, '')
        .trim();
}
function normalizeAIResult(result, fallbackMessage = '未提供原因') {
    if (!result || typeof result !== 'object') {
        return {
            isok: false,
            msg: fallbackMessage,
            detail: '',
            matchedPoints: [],
            risks: []
        };
    }
    return {
        isok: !!result.isok,
        msg: String(result.msg || fallbackMessage).trim(),
        detail: String(result.detail || '').trim(),
        matchedPoints: Array.isArray(result.matchedPoints) ? result.matchedPoints : [],
        risks: Array.isArray(result.risks) ? result.risks : []
    };
}
function buildDecisionLines(result, options = {}) {
    const normalized = normalizeAIResult(result);
    const lines = [
        normalized.isok ? (options.successTitle || '筛选成功') : (options.failureTitle || '筛选失败')
    ];
    const reasonPrefix = options.stageLabel ? `${options.stageLabel}：` : '';
    lines.push(truncateDecisionText(`${reasonPrefix}${normalized.msg}`, normalized.isok ? 40 : 54));
    if (options.extraLine) {
        lines.push(truncateDecisionText(options.extraLine, 48));
    }
    else {
        const detailText = extractReadableDetail(normalized.detail);
        if (normalized.isok) {
            const hint = normalized.matchedPoints[0] || detailText;
            if (hint) {
                lines.push(truncateDecisionText(hint, 48));
            }
        }
        else {
            if (detailText) {
                lines.push(truncateDecisionText(detailText, 64));
            }
            if (normalized.risks[0]) {
                lines.push(truncateDecisionText(`风险：${normalized.risks[0]}`, 48));
            }
        }
    }
    return lines.filter(Boolean).slice(0, normalized.isok ? 3 : 4);
}
function includesAny(text, keywords) {
    const source = String(text || '').toLowerCase();
    return keywords.some(keyword => source.includes(String(keyword).toLowerCase()));
}
function includesAnyPositive(text, keywords) {
    const source = String(text || '').toLowerCase();
    return keywords.some(keyword => {
        const term = String(keyword || '').toLowerCase();
        if (!term)
            return false;
        let index = source.indexOf(term);
        while (index !== -1) {
            const prefix = source.slice(Math.max(0, index - 12), index);
            const suffix = source.slice(index + term.length, index + term.length + 8);
            const isNegated = /(无|没有|未|非|不是|不具备|缺少|暂无|无相关|没有相关|并无|不含|不涉及|未涉及|不做|未做|未做过|没做过|不负责|未参与|没有参与|无参与)\s*(?:[\w#+]+|[\u4e00-\u9fa5]{0,8})?\s*(?:或|和|及|、|\/)?\s*$/.test(prefix) ||
                /^\s*(经验|经历|背景|项目|行业)?(不足|较少|欠缺|缺失|为零)/.test(suffix);
            if (!isNegated) {
                return true;
            }
            index = source.indexOf(term, index + term.length);
        }
        return false;
    });
}
function parseChineseAge(text) {
    const source = String(text || '');
    const labeledMatch = source.match(/年龄[:：]?\s*(\d{1,2})\s*岁?/);
    if (labeledMatch) {
        return parseInt(labeledMatch[1], 10);
    }
    const ageMatch = source.match(/(^|[^\d])(\d{2})\s*岁/);
    return ageMatch ? parseInt(ageMatch[2], 10) : null;
}
function parseCandidateWorkYears(text) {
    const source = String(text || '');
    if (/应届|在校|无经验|暂无经验|1年以内/.test(source)) {
        return 0;
    }
    const workYearMatch = source.match(/工作年限[:：]?\s*(\d+)\s*年/);
    if (workYearMatch) {
        return parseInt(workYearMatch[1], 10);
    }
    const genericYearMatch = source.match(/(\d+)\s*年(?:以上)?(?:工作|研发|开发|实习)?经验/);
    if (genericYearMatch) {
        return parseInt(genericYearMatch[1], 10);
    }
    const shortYearMatch = source.match(/^\s*(\d+)\s*年(?:以上)?\s*$/);
    return shortYearMatch ? parseInt(shortYearMatch[1], 10) : null;
}
function parseJobMinYears(jobText) {
    const matches = Array.from(String(jobText || '').matchAll(/(?:至少|不少于|不低于)?\s*(\d+)\s*年(?:以上|\+)?[^，。；;\n\r]{0,18}?(?:工作|研发|开发|项目|行业)?经验/g));
    if (!matches.length) {
        return null;
    }
    return Math.max(...matches.map(match => parseInt(match[1], 10)).filter(Number.isFinite));
}
function parseJobAgeRange(jobText) {
    const source = String(jobText || '');
    const rangeMatch = source.match(/(\d{2})\s*(?:-|~|到|至)\s*(\d{2})\s*岁?/);
    if (rangeMatch) {
        return {
            min: parseInt(rangeMatch[1], 10),
            max: parseInt(rangeMatch[2], 10)
        };
    }
    const maxMatch = source.match(/(?:年龄)?\s*(\d{2})\s*岁?(?:以下|以内|以内优先)/);
    if (maxMatch) {
        return {
            min: null,
            max: parseInt(maxMatch[1], 10)
        };
    }
    return null;
}
function getCandidatePrimaryDegree(candidate, candidateText) {
    const degree = candidate?.geekCard?.geekDegree ||
        candidate?.geekCard?.geekEdu?.degreeName ||
        candidate?.education ||
        String(candidateText || '').match(/学历[:：]\s*([^\n]+)/)?.[1] ||
        '';
    return String(degree).trim();
}
function getDegreeRank(degree) {
    const text = String(degree || '');
    if (/博士/.test(text))
        return 5;
    if (/硕士|研究生/.test(text))
        return 4;
    if (/本科/.test(text))
        return 3;
    if (/大专|专科/.test(text))
        return 2;
    if (/高中|中专|职高/.test(text))
        return 1;
    return 0;
}
function getCandidateMajor(candidate, candidateText) {
    return String(candidate?.geekCard?.geekEdu?.major ||
        candidate?.geekCard?.geekEdus?.[0]?.major ||
        String(candidateText || '').match(/专业[:：]\s*([^\n]+)/)?.[1] ||
        '').trim();
}
const GAME_CONTEXT_SIGNALS = [
    '游戏', '手游', '端游', '页游', '主机游戏', '小游戏',
    'MMO', 'MMORPG', 'ARPG', 'RPG', 'FPS', 'SLG', '卡牌', '二次元',
    'Unity', 'U3D', 'UE4', 'UE5', 'Unreal', 'Cocos',
    '游戏项目', '游戏Demo', '游戏作品', '游戏研发', '游戏开发',
    '游戏策划', '游戏文案', '游戏美术', '游戏UI', '游戏特效',
    '游戏广告', '游戏运营', '游戏发行', '游戏产品',
    '战斗系统', '技能系统', '关卡', '副本', '数值', '玩法',
    '角色设定', '世界观', '剧情向', '任务文本',
    '游戏引擎', 'Shader', 'ParticleSystem', 'UGUI', 'NGUI'
];
const GAME_DEV_CONTEXT_SIGNALS = [
    '游戏', '手游', '端游', '页游', '主机游戏', '小游戏',
    'MMO', 'MMORPG', 'ARPG', 'RPG', 'FPS', 'SLG', '卡牌',
    'Unity', 'U3D', 'UE4', 'UE5', 'Unreal', 'Cocos',
    '游戏项目', '游戏Demo', '游戏作品', '游戏研发', '游戏开发',
    '游戏客户端', '游戏服务端', '战斗系统', '技能系统', '副本',
    '关卡编辑器', 'UGUI', 'NGUI', 'ParticleSystem'
];
const GAME_PRODUCT_CONTEXT_SIGNALS = [
    '游戏', '手游', '端游', '页游', '主机游戏', '小游戏',
    'MMO', 'MMORPG', 'ARPG', 'RPG', 'SLG', '卡牌', '二次元',
    '游戏项目', '游戏产品', '游戏PM', '游戏制作人', '手游产品',
    '端游产品', '游戏SDK', 'SDK产品', '手游联运', '游戏联运',
    '游戏版本', '游戏商业化', '游戏留存', '游戏付费',
    '游戏用户研究', '游戏数据分析'
];
const GAME_OPERATION_CONTEXT_SIGNALS = [
    '游戏', '手游', '端游', '页游', '主机游戏', '小游戏',
    'MMO', 'MMORPG', 'ARPG', 'RPG', 'SLG', '卡牌', '二次元',
    '游戏运营', '游戏发行', '游戏市场', '游戏商务', '游戏品牌',
    '游戏媒介', '游戏社区', '游戏买量', '游戏投放', '游戏渠道',
    '手游发行', '海外发行', '版本运营'
];
const GAME_NARRATIVE_CONTEXT_SIGNALS = [
    '游戏', '手游', '端游', '页游', '主机游戏', '小游戏',
    'RPG', 'MMORPG', 'ARPG', '剧情向', '二次元',
    '游戏文案', '文案策划', '剧情策划', '叙事策划',
    '游戏剧情', '游戏世界观', '游戏角色', '任务文本',
    '游戏对白', '游戏项目', '上线游戏',
    'NPC人设', 'NPC 人设', 'AI NPC', 'ai-npc', '人设Prompt',
    '人设 Prompt', 'Prompt设计', 'Prompt 设计', 'TTS', '即时生成音频'
];
const GAME_ROLE_PROFILES = [
    {
        key: 'game_development',
        label: '游戏开发',
        requiresGameContext: true,
        contextSignals: GAME_DEV_CONTEXT_SIGNALS,
        jobPattern: /Unity|U3D|UE4|UE5|Unreal|Cocos|C#|Lua|C\+\+|客户端|服务端|服务器|程序|研发工程师|开发工程师|游戏AI|引擎|自动化测试|工具链/i,
        excludeJobPattern: /文案|编剧|剧情|世界观|PM|产品经理|项目经理|制作人|运营|发行|市场|商务|品牌|媒介|社区|用户研究|视觉营销|后期|UI设计|GUI设计|特效师|策划|关卡策划|数值策划|系统策划/i,
        requiredSignals: [
            '游戏开发', '游戏研发', '游戏项目', '游戏Demo', '游戏客户端', '游戏服务端',
            '手游', '端游', '页游', 'MMO', 'MMORPG', 'ARPG', 'RPG', 'FPS',
            'Unity', 'U3D', 'UE4', 'UE5', 'Unreal', 'Cocos',
            'C#', 'Lua', 'C++', 'Shader', 'HLSL',
            '客户端开发', '服务端开发', '服务器开发',
            '游戏引擎', '渲染', '性能优化', '热更新', '资源管理',
            '战斗系统', '技能系统', '背包系统', '任务系统', '关卡编辑器',
            'UGUI', 'NGUI', 'Animator', 'ParticleSystem',
            '工具链', '编辑器', '自动化测试'
        ],
        weakOnlySignals: [
            'AI', '大模型', 'LLM', 'Agent', 'Python', '数据分析', '数据挖掘',
            '机器学习', '深度学习', '爬虫', 'Web', '前端', '后端', '管理系统',
            '小程序', '网站', '电商', 'ERP', 'CRM'
        ],
        missingReason: '缺少游戏开发经历',
        weakOnlyReason: '只有泛技术/AI经历，非游戏开发'
    },
    {
        key: 'technical_art',
        label: '技术美术',
        requiresGameContext: true,
        contextSignals: GAME_DEV_CONTEXT_SIGNALS,
        jobPattern: /技术美术|TA|Shader|渲染|HLSL|材质|美术流程|引擎工具/i,
        requiredSignals: [
            '技术美术', 'TA', 'Shader', 'HLSL', '渲染', '材质', '特效',
            'Unity', 'U3D', 'UE4', 'UE5', 'Unreal', '游戏引擎',
            '美术流程', '工具开发', '资源规范', '性能优化', 'TA工具'
        ],
        missingReason: '缺少技术美术相关经历'
    },
    {
        key: 'game_design',
        label: '游戏策划',
        requiresGameContext: true,
        contextSignals: GAME_CONTEXT_SIGNALS,
        jobPattern: /策划|系统策划|玩法策划|关卡策划|数值策划|战斗策划|关卡|数值|玩法|系统设计|关卡设计/i,
        requiredSignals: [
            '游戏策划', '系统策划', '玩法策划', '关卡策划', '数值策划', '战斗策划',
            '玩法设计', '系统设计', '关卡设计', '数值设计', '副本', '战斗',
            'RPG', 'MMORPG', 'ARPG', 'Unity', 'UE4', '原型', '配置表',
            '策划案', '竞品分析', '用户调研', '游戏项目'
        ],
        missingReason: '缺少游戏策划相关经历'
    },
    {
        key: 'narrative',
        label: '文案/剧情',
        requiresGameContext: true,
        contextSignals: GAME_NARRATIVE_CONTEXT_SIGNALS,
        jobPattern: /文案|编剧|剧情|世界观|叙事|本地化|剧情策划|文案策划|叙事策划|任务文本|对白|道具描述|NPC|Prompt|TTS|人设/i,
        requiredSignals: [
            '游戏文案', '文案策划', '剧情策划', '叙事策划', '游戏剧情',
            '游戏世界观', '世界观', '角色设定', '任务文本', '对白',
            '道具描述', '本地化', '剧情向', 'RPG', 'MMORPG',
            '二次元', '游戏作品集', '上线游戏',
            'NPC人设', 'NPC 人设', 'AI NPC', 'ai-npc', 'AI-NPC',
            '人设Prompt', '人设 Prompt', 'Prompt设计', 'Prompt 设计',
            '群聊', '单聊', 'AI NPC训练', 'AI NPC优化', 'TTS',
            '即时生成音频', '配置落地'
        ],
        weakOnlySignals: [
            '文案', '编剧', '剧本', '小说', '故事', '短剧', '影视',
            '公众号', '新媒体', '广告文案', '品牌文案', '销售文案',
            '小红书', '脚本', '运营', '动画', '平面设计',
            'Toon Boom', 'Storyboard', 'Flash', 'PS'
        ],
        missingReason: '缺少游戏文案/剧情匹配信号',
        weakOnlyReason: '只有通用文案/编剧经历，非游戏文案策划'
    },
    {
        key: 'product_pm',
        label: '产品/PM/项目',
        requiresGameContext: true,
        contextSignals: GAME_PRODUCT_CONTEXT_SIGNALS,
        jobPattern: /PM|产品经理|项目经理|项目管理|制作人|Producer|版本管理|需求管理/i,
        requiredSignals: [
            '游戏产品', '游戏PM', '游戏项目', '游戏制作人', '制作人', 'Producer',
            '手游产品', '端游产品', '游戏SDK', 'SDK产品', '手游联运',
            '游戏联运', '版本运营', '游戏版本', '游戏商业化',
            '游戏留存', '游戏付费', '游戏用户研究', '游戏数据分析',
            'MMO', 'MMORPG', 'ARPG', 'RPG', 'SLG', '卡牌', '二次元'
        ],
        weakOnlySignals: [
            '产品经理', 'PM', '项目经理', '项目管理', '版本管理', '需求管理',
            '排期', '里程碑', '跨部门协作', '数据分析', '用户研究', '商业化',
            '留存', '付费'
        ],
        missingReason: '缺少游戏产品/PM/项目经验',
        weakOnlyReason: '只有通用产品/PM经历，非游戏产品/项目'
    },
    {
        key: 'art_ui_vfx',
        label: '美术/UI/特效',
        requiresGameContext: true,
        contextSignals: GAME_CONTEXT_SIGNALS,
        jobPattern: /美术|原画|3D|建模|动作|动画|特效|VFX|UI|GUI|TA|视觉/i,
        excludeJobPattern: /技术美术|Shader|HLSL/i,
        requiredSignals: [
            '游戏美术', '原画', '角色', '场景', '3D', '建模', '动作', '动画',
            '特效', 'VFX', 'ParticleSystem', 'UI', 'GUI', '游戏UI',
            '界面设计', '图标', '动效', '作品集', '二次元', 'Unity', 'UE'
        ],
        missingReason: '缺少游戏美术/UI/特效信号'
    },
    {
        key: 'marketing_video',
        label: '营销素材/后期',
        requiresGameContext: true,
        contextSignals: GAME_CONTEXT_SIGNALS,
        jobPattern: /视觉营销|视频|后期|AE|After Effects|Premiere|Pr|剪映|达芬奇|广告素材|短视频|动态设计|AI视频/i,
        requiredSignals: [
            '游戏广告', '广告素材', '短视频', '视频后期', 'AE', 'After Effects',
            'Premiere', 'Pr', '剪映', '达芬奇', '动态设计', '动效',
            'AI视频', 'Seedance', 'Kling', 'Midjourney', 'MJ', '小红书',
            '作品集', '营销素材'
        ],
        missingReason: '缺少营销素材/后期匹配信号'
    },
    {
        key: 'operation_publishing',
        label: '运营/发行/市场',
        requiresGameContext: true,
        contextSignals: GAME_OPERATION_CONTEXT_SIGNALS,
        jobPattern: /运营|发行|市场|商务|品牌|媒介|社区|用户增长|买量|投放|渠道/i,
        excludeJobPattern: /新媒体运营经验.*不匹配|没有.*运营经验|无.*运营经验|纯运营|运营.*不匹配/i,
        requiredSignals: [
            '游戏运营', '游戏发行', '游戏市场', '游戏商务', '游戏品牌',
            '游戏媒介', '游戏社区', '游戏用户增长', '游戏买量', '游戏投放',
            '游戏渠道', '活动运营', '版本运营', '买量', '投放', '渠道',
            'DAU', 'ROI', 'ASO', '海外发行', '手游', '端游', 'MMO', 'RPG'
        ],
        weakOnlySignals: [
            '运营', '发行', '市场', '商务', '品牌', '媒介', '社区',
            '用户增长', '数据分析', '留存', '付费'
        ],
        missingReason: '缺少游戏运营/发行/市场信号'
    }
];
function getMatchedGameRoleProfiles(jobText) {
    return GAME_ROLE_PROFILES.filter(profile => profile.jobPattern.test(jobText) && !profile.excludeJobPattern?.test(jobText));
}
function applyGameRoleProfileHardScreens(reasons, jobText, candidateText) {
    const profiles = getMatchedGameRoleProfiles(jobText);
    if (!profiles.length) {
        return;
    }
    const matchedAnyProfile = profiles.some(profile => includesAnyPositive(candidateText, profile.requiredSignals));
    if (!matchedAnyProfile) {
        reasons.push(profiles.length === 1
            ? profiles[0].missingReason
            : `缺少${profiles.map(profile => profile.label).join('/')}匹配信号`);
    }
    const missingContextProfiles = profiles.filter(profile => profile.requiresGameContext &&
        !includesAnyPositive(candidateText, profile.contextSignals || GAME_CONTEXT_SIGNALS));
    if (missingContextProfiles.length) {
        reasons.push(missingContextProfiles.length === 1
            ? `缺少${missingContextProfiles[0].label}的游戏行业/项目背景`
            : `缺少${missingContextProfiles.map(profile => profile.label).join('/')}的游戏行业/项目背景`);
    }
    profiles.forEach(profile => {
        if (profile.weakOnlySignals &&
            includesAny(candidateText, profile.weakOnlySignals) &&
            !includesAnyPositive(candidateText, profile.requiredSignals)) {
            reasons.push(profile.weakOnlyReason || `${profile.label}匹配信号不足`);
        }
    });
}
function applyExplicitNegativeHardScreens(reasons, jobText, candidateText) {
    const text = String(candidateText || '');
    if (/游戏|Unity|U3D|UE4|UE5|Unreal|Cocos|客户端|服务端|程序|研发|开发|技术美术|TA|策划|UI|GUI|后期|运营|发行|PM|产品/.test(jobText) &&
        /(无|没有|暂无|缺少|不具备|未参与|没有参与|未涉及|不涉及|未做过|没做过).{0,12}(游戏|手游|端游|页游|Unity|U3D|UE4|UE5|Unreal|Cocos|游戏项目|商业游戏|上线项目|游戏行业|游戏UI|游戏发行|游戏运营)/i.test(text)) {
        reasons.push('候选人明确缺少游戏相关经验');
    }
    if (/资深|高级|主程|负责人|Lead|3\s*年|5\s*年|三年|五年/i.test(jobText) &&
        /(培训班|课程项目|练习项目|课堂项目|自学项目|Demo).{0,12}(Unity|U3D|游戏|C#|Lua)/i.test(text) &&
        /(无|没有|暂无|缺少|不具备|未参与|没有参与).{0,12}(商业游戏|上线项目|游戏行业|游戏项目)/i.test(text)) {
        reasons.push('只有培训/练习项目，缺少商业游戏经历');
    }
}
function buildHardScreenDecision(candidate, candidateText) {
    const aiSettings = currentParser?.aiSettings || {};
    const jobText = [
        aiSettings.positionName,
        aiSettings.jobDescription,
        ...(aiSettings.keywords || [])
    ].filter(Boolean).join('\n');
    if (!jobText.trim()) {
        return null;
    }
    const text = String(candidateText || '');
    const reasons = [];
    const risks = [];
    const age = parseChineseAge(candidate?.geekCard?.ageDesc || candidate?.age || text);
    const workYears = parseCandidateWorkYears(candidate?.geekCard?.geekWorkYear || text);
    const explicitAgeRange = parseJobAgeRange(jobText);
    const explicitMinYears = parseJobMinYears(jobText);
    const excludeKeywords = (aiSettings.excludeKeywords || [])
        .map(keyword => String(keyword || '').trim())
        .filter(Boolean);
    const matchedExcludeKeyword = excludeKeywords.find(keyword => text.toLowerCase().includes(keyword.toLowerCase()));
    if (matchedExcludeKeyword) {
        reasons.push(`命中排除词：${matchedExcludeKeyword}`);
    }
    if (explicitAgeRange && age !== null) {
        if (explicitAgeRange.min !== null && age < explicitAgeRange.min) {
            reasons.push(`年龄低于要求：${age}岁`);
        }
        if (explicitAgeRange.max !== null && age > explicitAgeRange.max) {
            reasons.push(`年龄超过要求：${age}岁`);
        }
    }
    if (explicitMinYears !== null && workYears !== null && workYears < explicitMinYears) {
        reasons.push(`经验不足：${workYears}年`);
    }
    if (/本科及以上|本科以上|本科或以上/.test(jobText)) {
        const degree = getCandidatePrimaryDegree(candidate, text);
        if (degree && getDegreeRank(degree) > 0 && getDegreeRank(degree) < getDegreeRank('本科')) {
            reasons.push(`学历不符：${degree}`);
        }
    }
    const isInternOrCampusJob = /实习|实习生|应届|校招|毕业生/.test(jobText);
    if (isInternOrCampusJob) {
        if (age !== null && age >= 30) {
            reasons.push(`实习/校招岗位年龄偏离：${age}岁`);
        }
        if (workYears !== null && workYears >= 3) {
            reasons.push(`实习/校招岗位经验偏离：${workYears}年`);
        }
    }
    if (/应届|校招|毕业生/.test(jobText)) {
        const freshGraduate = candidate?.geekCard?.freshGraduate;
        if (freshGraduate === 0 && !/应届|在校|毕业生|202[5-8]/.test(text)) {
            reasons.push('非应届/校招画像');
        }
    }
    if (/计算机|人工智能|数学|软件|游戏|Unity|U3D|C#|Lua/.test(jobText)) {
        const major = getCandidateMajor(candidate, text);
        const relatedMajorPattern = /计算机|软件|人工智能|智能科学|数学|信息|通信|电子|自动化|网络|数据|数字媒体|游戏/;
        if (/计算机|人工智能|数学相关专业/.test(jobText) && major && !relatedMajorPattern.test(major)) {
            reasons.push(`专业不相关：${major}`);
        }
    }
    const isGameCompanyJob = /游戏|Unity|U3D|MMO|MMORPG|ARPG|RPG|FPS|客户端|服务端|程序|研发|开发|策划|关卡|数值|特效|GUI|UI|技术美术|TA|Shader|视觉营销|AE|后期|广告素材/i.test(jobText);
    const gameCompanySignals = [
        '游戏', '手游', '端游', '页游', 'MMO', 'MMORPG', 'ARPG', 'RPG', 'FPS',
        'Unity', 'U3D', 'UE', 'UE4', 'UE5', 'Unreal',
        '游戏客户端', '游戏服务端', '游戏服务器', '游戏程序', '游戏研发', '游戏开发',
        '游戏AI', '游戏自动化', 'Shader', 'HLSL', '渲染', '游戏工具链', '游戏Demo',
        '策划', '系统策划', '玩法策划', '关卡', '数值', '战斗', '副本',
        '文案', '剧情', '编剧', '世界观', '叙事', '本地化',
        '游戏产品', '游戏PM', '游戏项目', '游戏制作人', '制作人', 'Producer',
        '游戏运营', '游戏发行', '游戏市场', '游戏商务', '游戏品牌',
        '游戏媒介', '游戏社区', '游戏用户研究',
        '特效', 'VFX', 'ParticleSystem', 'UGUI', 'NGUI', 'Animator',
        'TA', '技术美术', '美术流程', '材质', '游戏引擎',
        'GUI', '游戏UI', 'UI设计', '作品集', '二次元',
        'AE', 'After Effects', 'Premiere', 'Pr', '剪映', '达芬奇',
        '视频后期', '动态漫画', '广告素材', '动态设计', 'AI视频',
        '数字媒体'
    ];
    const nonGameIndustryTerms = [
        '金融', '银行', '保险', '证券', '基金', '贷款',
        '销售', '电销', '地推', '课程顾问', '置业顾问',
        '客服', '教师', '老师', '教育', '培训', '托管',
        '行政', '人事', 'HR', '财务', '会计', '出纳',
        '房产', '中介', '餐饮', '门店', '导购', '主播', '直播'
    ];
    if (isGameCompanyJob && includesAny(text, nonGameIndustryTerms) && !includesAnyPositive(text, gameCompanySignals)) {
        reasons.push('非游戏行业背景且无岗位匹配信号');
    }
    applyExplicitNegativeHardScreens(reasons, jobText, text);
    applyGameRoleProfileHardScreens(reasons, jobText, text);
    const isGameOrTechJob = /Unity|U3D|C#|Lua|游戏AI|客户端|程序|研发|开发|服务端|技术美术|TA/i.test(jobText);
    const coreTechTerms = ['Unity', 'U3D', 'C#', 'Lua', 'C++', 'Java', 'Go', 'Shader', '游戏', '客户端', '服务端', '研发', '开发', '算法', '项目'];
    const unrelatedTerms = ['金融', '银行', '保险', '证券', '销售', '电销', '运营', '客服', '教师', '老师', '行政', '人事', '财务', '会计', '市场'];
    if (isGameOrTechJob && includesAny(text, unrelatedTerms) && !includesAny(text, coreTechTerms)) {
        reasons.push('方向明显不匹配');
    }
    if (!reasons.length) {
        return null;
    }
    risks.push(...reasons.slice(0, 3));
    return {
        isok: false,
        msg: reasons[0],
        detail: `已根据当前岗位要求进行硬性条件预筛，发现候选人存在 ${reasons.join('；')}。因此不进入 AI 细筛和自动沟通。`,
        matchedPoints: [],
        risks
    };
}
function addHighlightReason(element, status, lines, color) {
    element.querySelector('.goodhr-highlight-reason')?.remove();
    const statusStyles = {
        success: {
            background: '#e8f5e9',
            border: '#4caf50',
            shadow: 'rgba(76, 175, 80, 0.3)'
        },
        pending: {
            background: '#fff3e0',
            border: '#fb8c00',
            shadow: 'rgba(251, 140, 0, 0.28)'
        },
        warning: {
            background: '#fff8e1',
            border: '#f29900',
            shadow: 'rgba(242, 153, 0, 0.28)'
        },
        failed: {
            background: '#f5f5f5',
            border: '#9e9e9e',
            shadow: 'rgba(158, 158, 158, 0.3)'
        }
    };
    const styleConfig = statusStyles[status] || statusStyles.failed;
    const displayLines = Array.isArray(lines) ? lines.filter(Boolean) : [String(lines || '')];
    const reasonEl = document.createElement('div');
    reasonEl.className = 'goodhr-highlight-reason';
    reasonEl.textContent = displayLines.join('\n');
    reasonEl.title = displayLines.join('\n');
    reasonEl.style.cssText = `
                position: absolute;
                top: 0;
                left: 0;
                max-width: 320px;
                background-color: ${color};
                color: white;
                padding: 6px 10px;
                font-size: 12px;
                line-height: 1.45;
                white-space: pre-line;
                word-break: break-word;
                border-bottom-right-radius: 8px;
                z-index: 2;
            `;
    element.style.position = 'relative';
    element.appendChild(reasonEl);
    Object.entries({
        'background-color': styleConfig.background,
        'border': `2px solid ${styleConfig.border}`,
        'box-shadow': `0 0 10px ${styleConfig.shadow}`
    }).forEach(([property, value]) => {
        element.style.setProperty(property, value, 'important');
    });
}
const PROCESSED_CANDIDATES_STORAGE_KEY = 'goodhr_processed_candidates_v1';
const PROCESSED_CANDIDATE_TTL_DAYS = 30;
const PROCESSED_CANDIDATE_MAX_COUNT = 3000;
function normalizeDedupeText(value) {
    return String(value || '')
        .replace(/\s+/g, '')
        .toLowerCase()
        .slice(0, 80);
}
function getCurrentDedupePositionKey() {
    const aiSettings = currentParser?.aiSettings || {};
    const filterSettings = currentParser?.filterSettings || {};
    const positionName = aiSettings.positionName ||
        filterSettings.positionName ||
        aiSettings.jobDescription?.split('\n')?.[0] ||
        'default-position';
    return normalizeDedupeText(positionName);
}
function getCandidateDedupeKey(candidate, candidateInfo = '') {
    const geekCard = candidate?.geekCard || {};
    const siteKey = ParserName || location.hostname || 'unknown-site';
    const positionKey = getCurrentDedupePositionKey();
    const stableId = [
        geekCard.encryptGeekId,
        geekCard.encGeekId,
        geekCard.geekId,
        geekCard.expectId,
        geekCard.jobId,
        candidate?.encryptGeekId,
        candidate?.encGeekId,
        candidate?.geekId,
        candidate?.expectId,
        candidate?.id
    ].filter(Boolean).join(':');
    if (stableId) {
        return `${siteKey}:${positionKey}:id:${stableId}`;
    }
    const fallbackParts = [
        candidate?.name,
        candidate?.age,
        candidate?.education,
        candidate?.university,
        geekCard.geekName,
        geekCard.ageDesc,
        geekCard.geekDegree,
        geekCard.geekEdu?.school,
        geekCard.geekEdu?.major,
        geekCard.expectPositionName,
        String(candidateInfo).match(/姓名[:：]\s*([^\n]+)/)?.[1],
        String(candidateInfo).match(/毕业院校[:：]\s*([^\n]+)/)?.[1],
        String(candidateInfo).match(/专业[:：]\s*([^\n]+)/)?.[1]
    ].filter(Boolean).map(normalizeDedupeText);
    return `${siteKey}:${positionKey}:text:${fallbackParts.join(':')}`;
}
async function getProcessedCandidateMap() {
    return new Promise(resolve => {
        chrome.storage.local.get([PROCESSED_CANDIDATES_STORAGE_KEY], result => {
            const map = result?.[PROCESSED_CANDIDATES_STORAGE_KEY];
            resolve(map && typeof map === 'object' ? map : {});
        });
    });
}
function pruneProcessedCandidateMap(map) {
    const now = Date.now();
    const ttlMs = PROCESSED_CANDIDATE_TTL_DAYS * 24 * 60 * 60 * 1000;
    const entries = Object.entries(map || {})
        .filter(([, value]) => value?.time && now - value.time <= ttlMs)
        .sort((a, b) => (b[1]?.time || 0) - (a[1]?.time || 0))
        .slice(0, PROCESSED_CANDIDATE_MAX_COUNT);
    return Object.fromEntries(entries);
}
async function isCandidateAlreadyProcessed(dedupeKey) {
    if (!dedupeKey) {
        return false;
    }
    const map = pruneProcessedCandidateMap(await getProcessedCandidateMap());
    if (map[dedupeKey]) {
        await chrome.storage.local.set({ [PROCESSED_CANDIDATES_STORAGE_KEY]: map });
        return true;
    }
    return false;
}
async function markCandidateProcessed(dedupeKey, candidate, status = 'matched') {
    if (!dedupeKey) {
        return;
    }
    const map = pruneProcessedCandidateMap(await getProcessedCandidateMap());
    map[dedupeKey] = {
        time: Date.now(),
        status,
        name: candidate?.geekCard?.geekName || candidate?.name || '',
        site: ParserName || location.hostname || '',
        position: currentParser?.aiSettings?.positionName || ''
    };
    await chrome.storage.local.set({ [PROCESSED_CANDIDATES_STORAGE_KEY]: map });
}
function hasPlatformContactHistory(candidate) {
    const geekCard = candidate?.geekCard || {};
    return [
        candidate?.haveChatted,
        candidate?.isFriend,
        candidate?.friendGeek,
        candidate?.viewed,
        geekCard.haveChatted,
        geekCard.isFriend,
        geekCard.friendGeek,
        geekCard.viewed
    ].some(value => value === true || value === 1);
}
async function processElement(element, doc) {
    if (currentParser.aiSettings == null || currentParser.aiSettings.communicationConfig == null) {
        currentParser.aiSettings = {
            communicationConfig: {
                collectPhone: false,
                collectWechat: false,
                collectResume: false
            }
        };
    }
    void 0;
    await currentParser.checkMessageTip(element, currentParser.aiSettings.communicationConfig.collectPhone || false, currentParser.aiSettings.communicationConfig.collectWechat || false, currentParser.aiSettings.communicationConfig.collectResume || false);
    try {
        const apiBase = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.API_BASE : 'https://goodhr.58it.cn';
        fetch(`${apiBase}/counter.php`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        }).catch(err => {
        });
        if (matchCount >= matchLimit) {
            isRunning = false;
            stopAutoScroll();
            return;
        }
        await currentParser.loadSettings();
        let targetElement = element.closest('.' + currentParser.selectors.items);
        if (!targetElement) {
            targetElement = element.closest(`[class*="${currentParser.selectors.items}"]`);
        }
        if (!targetElement)
            return;
        targetElement.removeAttribute('style');
        targetElement.querySelector('.goodhr-highlight-reason')?.remove();
        const rect = element.getBoundingClientRect();
        lastProcessedPosition = rect.top + rect.height + (doc === document ?
            window.pageYOffset :
            doc.defaultView.pageYOffset);
        const candidates = await currentParser.extractCandidates([element]);
        const resolvedCandidates = candidates;
        if (resolvedCandidates.length > 0) {
            for (let candidate of candidates) {
                let simpleCandidateInfo = null;
                let firstDecision = null;
                let finalDecision = null;
                if (matchCount >= matchLimit) {
                    void 0;
                    isRunning = false;
                    stopAutoScroll();
                    return;
                }
                let shouldSkipDelay = false;
                let clickCandidate = false;
                simpleCandidateInfo = await currentParser.getSimpleCandidateInfo(candidate);
                const dedupeKey = getCandidateDedupeKey(candidate, simpleCandidateInfo);
                if (hasPlatformContactHistory(candidate)) {
                    await markCandidateProcessed(dedupeKey, candidate, 'platform_contacted');
                    addHighlightReason(targetElement, 'failed', ['跳过已沟通过候选人', '平台显示已有联系记录'], '#9e9e9e');
                    continue;
                }
                if (await isCandidateAlreadyProcessed(dedupeKey)) {
                    addHighlightReason(targetElement, 'failed', ['跳过重复候选人', '近期已处理过'], '#9e9e9e');
                    await sendMessage({
                        type: 'LOG_MESSAGE',
                        data: {
                            message: `跳过重复候选人：${candidate?.geekCard?.geekName || candidate?.name || '未知候选人'}`,
                            type: 'info'
                        }
                    });
                    continue;
                }
                if (currentParser.aiMode) {
                    const hardScreenDecision = buildHardScreenDecision(candidate, simpleCandidateInfo);
                    firstDecision = hardScreenDecision || normalizeAIResult(await performAIClickDecision(simpleCandidateInfo), '初筛失败');
                    clickCandidate = firstDecision.isok;
                    if (clickCandidate) {
                        addHighlightReason(targetElement, 'pending', buildDecisionLines(firstDecision, {
                            successTitle: '初筛通过',
                            stageLabel: '初筛'
                        }), '#fb8c00');
                    }
                    else {
                        addHighlightReason(targetElement, 'failed', buildDecisionLines(firstDecision, {
                            failureTitle: '筛选失败',
                            stageLabel: '初筛'
                        }), '#9e9e9e');
                    }
                }
                else {
                    clickCandidate = currentParser.shouldClickCandidate();
                }
                let shouldContact = false;
                if (clickCandidate) {
                    let clicked = await openCandidateDetailWithFallback(element, candidate.name);
                    if (ParserName === 'employer58') {
                        clicked = false;
                        shouldContact = true;
                        await randomDelay(`查看候选人详细信息: ${candidate.name}`);
                    }
                    if (clicked) {
                        shouldSkipDelay = true;
                        await randomDelay(`查看候选人详细信息: ${candidate.name}`);
                        let colleagueContactedInfo = null;
                        try {
                            colleagueContactedInfo = await currentParser.queryColleagueContactedInfo(candidate);
                            simpleCandidateInfo += colleagueContactedInfo;
                        }
                        catch (error) {
                            void 0;
                        }
                        try {
                            let data2 = await currentParser.extractCandidates2(candidate);
                            if (data2) {
                                simpleCandidateInfo = data2;
                            }
                        }
                        catch (error) {
                            void 0;
                        }
                        if (currentParser.aiMode) {
                            finalDecision = normalizeAIResult(await performAIDetailDecision(simpleCandidateInfo), '二筛失败');
                            shouldContact = finalDecision.isok;
                        }
                        else {
                            shouldContact = currentParser.filterCandidate(simpleCandidateInfo);
                            if (ParserName === 'employer58') {
                                shouldContact = true;
                            }
                        }
                        await currentParser.closeDetail();
                        await new Promise(resolve => setTimeout(resolve, 500));
                    }
                    else if (currentParser.aiMode && ParserName !== 'employer58') {
                        finalDecision = {
                            isok: false,
                            msg: '详情打开失败',
                            detail: '初筛已通过，但无法打开详情页完成二筛。',
                            matchedPoints: [],
                            risks: []
                        };
                    }
                }
                else {
                    await randomDelay("不查看候选人详细信息");
                    if (!currentParser.aiMode) {
                        shouldContact = currentParser.filterCandidate(simpleCandidateInfo);
                        if (ParserName === 'employer58') {
                            shouldContact = true;
                        }
                    }
                }
                if (shouldContact) {
                    if (matchCount >= matchLimit) {
                        void 0;
                        isRunning = false;
                        stopAutoScroll();
                        return;
                    }
                    const clicked = await currentParser.clickMatchedItem(element);
                    if (clicked) {
                        const successDecision = normalizeAIResult(finalDecision || firstDecision || { isok: true, msg: '符合筛选条件' }, '符合筛选条件');
                        addHighlightReason(targetElement, 'success', buildDecisionLines(successDecision, {
                            successTitle: '筛选成功',
                            stageLabel: currentParser.aiMode ? (finalDecision ? '二筛' : '初筛') : '结果',
                            extraLine: '已自动打招呼'
                        }), '#4caf50');
                        try {
                            if (currentParser.aiSettings.communicationConfig.collectPhone || currentParser.aiSettings.communicationConfig.collectWechat || currentParser.aiSettings.communicationConfig.collectResume) {
                                const phone = await currentParser.collectPhoneWechatResume(currentParser.aiSettings.communicationConfig.collectPhone, currentParser.aiSettings.communicationConfig.collectWechat, currentParser.aiSettings.communicationConfig.collectResume, candidate, element);
                            }
                        }
                        catch (error) {
                            void 0;
                            return null;
                        }
                        matchCount++;
                        await markCandidateProcessed(dedupeKey, candidate, 'matched');
                        void 0;
                        playNotificationSound();
                        try {
                            if (currentParser.processCommunication && typeof currentParser.processCommunication === 'function') {
                                await currentParser.processCommunication(candidate);
                            }
                        }
                        catch (error) {
                            void 0;
                        }
                        await sendMessage({
                            type: 'MATCH_SUCCESS',
                            data: {
                                name: candidate.name,
                                age: candidate.age,
                                education: candidate.education,
                                university: candidate.university,
                                extraInfo: candidate.extraInfo,
                                matchTime: new Date().toLocaleTimeString('zh-CN', {
                                    hour12: false,
                                    hour: '2-digit',
                                    minute: '2-digit',
                                    second: '2-digit'
                                }),
                                clicked: clicked
                            }
                        });
                    }
                    else {
                        const failedGreetingDecision = normalizeAIResult(finalDecision || firstDecision || { isok: true, msg: '符合筛选条件' }, '符合筛选条件');
                        await markCandidateProcessed(dedupeKey, candidate, 'greeting_failed');
                        addHighlightReason(targetElement, 'warning', buildDecisionLines(failedGreetingDecision, {
                            successTitle: '筛选通过',
                            stageLabel: currentParser.aiMode ? (finalDecision ? '二筛' : '初筛') : '结果',
                            extraLine: '打招呼失败'
                        }), '#f29900');
                    }
                    if (matchCount >= matchLimit) {
                        void 0;
                        isRunning = false;
                        stopAutoScroll();
                        return;
                    }
                }
                else {
                    if (currentParser.aiMode) {
                        const failedDecision = normalizeAIResult(finalDecision || firstDecision || { isok: false, msg: '未通过筛选' }, '未通过筛选');
                        addHighlightReason(targetElement, 'failed', buildDecisionLines(failedDecision, {
                            failureTitle: '筛选失败',
                            stageLabel: finalDecision ? '二筛' : '初筛'
                        }), '#9e9e9e');
                    }
                    else {
                        addHighlightReason(targetElement, 'failed', ['未打招呼', '未命中关键词'], '#9e9e9e');
                    }
                }
            }
        }
    }
    catch (error) {
        void 0;
        element.removeAttribute('style');
    }
}
function playNotificationSound() {
    if (enableSound) {
        const audio = new Audio(chrome.runtime.getURL('sounds/notification2.mp3'));
        audio.volume = 0.5;
        audio.play().catch(error => void 0);
    }
}
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    try {
        switch (message.action) {
            case 'START_SCROLL':
                if (!currentParser) {
                    void 0;
                    sendResponse({ status: 'error', message: '解析器未初始化' });
                    return;
                }
                if (message.data.clickFrequency !== undefined) {
                    currentParser.clickCandidateConfig.frequency = message.data.clickFrequency;
                }
                currentParser.aiMode = false;
                if (message.data.keywords) {
                    currentParser.filterSettings = {
                        ...currentParser.filterSettings,
                        keywords: message.data.keywords,
                        excludeKeywords: message.data.excludeKeywords,
                        isAndMode: message.data.isAndMode,
                        matchLimit: message.data.matchLimit,
                        scrollDelayMin: message.data.scrollDelayMin,
                        scrollDelayMax: message.data.scrollDelayMax,
                        enableSound: message.data.enableSound,
                        communicationEnabled: message.data.communicationEnabled,
                        communicationConfig: message.data.communicationConfig
                    };
                }
                await startAutoScroll();
                sendResponse({ status: 'success' });
                break;
            case 'SET_AI_MODE':
                break;
            case 'START_AI_SCROLL':
                if (!currentParser) {
                    void 0;
                    sendResponse({ status: 'error', message: '解析器未初始化' });
                    return;
                }
                if (message.data.clickFrequency !== undefined) {
                    currentParser.clickCandidateConfig.frequency = message.data.clickFrequency;
                }
                currentParser.aiMode = true;
                currentParser.aiSettings = {
                    positionName: message.data.positionName,
                    jobDescription: message.data.jobDescription,
                    keywords: message.data.keywords || [],
                    excludeKeywords: message.data.excludeKeywords || [],
                    aiConfig: message.data.aiConfig,
                    matchLimit: message.data.matchLimit,
                    scrollDelayMin: message.data.scrollDelayMin,
                    scrollDelayMax: message.data.scrollDelayMax,
                    enableSound: message.data.enableSound,
                    communicationEnabled: message.data.communicationEnabled,
                    communicationConfig: message.data.communicationConfig
                };
                await startAutoScroll();
                sendResponse({ status: 'success' });
                break;
            case 'SHOW_ADS':
                removeAds();
                sendResponse({ status: 'success' });
                break;
                enableSound = currentParser.aiSettings.enableSound;
                break;
            case 'STOP_SCROLL':
                stopAutoScroll();
                sendResponse({ status: 'stopped' });
                break;
            case 'REMOVE_ADS':
                removeAds();
                sendResponse({ status: 'success' });
                break;
            case 'UPDATE_KEYWORDS':
                if (currentParser) {
                    currentParser.setFilterSettings(message.data);
                    sendResponse({ status: 'updated' });
                }
                else {
                    sendResponse({ status: 'error', message: '解析器未初始化' });
                }
                break;
            case 'SETTINGS_UPDATED':
                if (currentParser) {
                    currentParser.setFilterSettings({
                        ...message.data,
                        scrollDelayMin: message.data.scrollDelayMin || 3,
                        scrollDelayMax: message.data.scrollDelayMax || 5
                    });
                    sendResponse({ status: 'ok' });
                }
                else {
                    void 0;
                    sendResponse({ status: 'error', message: '解析器未初始化' });
                }
                break;
            case 'COMMUNICATION_PROCESS':
                if (currentParser) {
                    if (message.data.companyInfo) {
                        currentParser.companyInfo = message.data.companyInfo;
                    }
                    if (message.data.jobInfo) {
                        currentParser.jobInfo = message.data.jobInfo;
                    }
                    if (message.data.communicationConfig) {
                        currentParser.aiSettings.communicationConfig = message.data.communicationConfig;
                    }
                    if (message.data.runModeConfig) {
                        currentParser.runModeConfig = message.data.runModeConfig;
                    }
                    sendResponse({ status: 'success' });
                }
                else {
                    sendResponse({ status: 'error', message: '解析器未初始化' });
                }
                break;
            default:
                void 0;
                sendResponse({ status: 'error', message: '未知的消息类型' });
        }
    }
    catch (error) {
        void 0;
        isRunning = false;
        sendResponse({ status: 'error', message: error.message });
    }
    return true;
});
function stopAutoScroll() {
    if (!isRunning)
        return;
    try {
        isRunning = false;
        if (scrollInterval) {
            clearInterval(scrollInterval);
            scrollInterval = null;
        }
        lastProcessedPosition = 0;
        if (currentParser) {
            document.querySelectorAll(`[class^="${currentParser.selectors.items}"], [class*=" ${currentParser.selectors.items}"]`)
                .forEach(el => {
                el.style.cssText = '';
            });
        }
        if (isExtensionValid()) {
            showNotification('已停止自动滚动', 'status');
        }
        else {
            void 0;
        }
    }
    catch (error) {
        void 0;
    }
}
function removeAds() {
    try {
        const adElements = document.querySelectorAll('.ad-container, .draggable-ad-container');
        adElements.forEach(adElement => {
            adElement.remove();
        });
        chrome.storage.local.remove(['adDisplayed']);
        void 0;
    }
    catch (error) {
        void 0;
    }
}
async function getCandidateInfo(candidate) {
    try {
        let info = `姓名：${candidate.name}\n`;
        if (candidate.age)
            info += `年龄：${candidate.age}\n`;
        if (candidate.education)
            info += `学历：${candidate.education}\n`;
        if (candidate.university)
            info += `学校：${candidate.university}\n`;
        if (candidate.experience)
            info += `经验：${candidate.experience}\n`;
        if (candidate.salary)
            info += `期望薪资：${candidate.salary}\n`;
        if (candidate.location)
            info += `期望地点：${candidate.location}\n`;
        if (candidate.extraInfo && candidate.extraInfo.length > 0) {
            info += `其他信息：\n`;
            candidate.extraInfo.forEach(item => {
                info += `- ${item.type}: ${item.value}\n`;
            });
        }
        if (candidate.colleagueContactedInfo) {
            info += `同事沟通过候选人的信息：\n${candidate.colleagueContactedInfo}\n`;
        }
        if (candidate.activeText) {
            info += `在线状态：${candidate.activeText}\n`;
        }
        return info;
    }
    catch (error) {
        void 0;
        return `姓名：${candidate.name}`;
    }
}
const GUJJI_API_CONFIG = window.GOODHR_CONFIG ? window.GOODHR_CONFIG.GUJJI_API : {
    baseUrl: 'https://api.siliconflow.cn/v1/chat/completions',
    maxTokens: 100,
    temperature: 0.1
};
function buildChatCompletionsUrl(endpoint) {
    const trimmed = (endpoint || '').trim().replace(/\/+$/, '');
    if (!trimmed) {
        return GUJJI_API_CONFIG.baseUrl;
    }
    if (trimmed.endsWith('/chat/completions')) {
        return trimmed;
    }
    return `${trimmed}/chat/completions`;
}
function isAnthropicCompatibleEndpoint(endpoint) {
    return /\/anthropic(\/|$)/i.test(endpoint || '') || /\/messages$/i.test(endpoint || '');
}
function buildAIRequestUrl(endpoint, platform) {
    const trimmed = (endpoint || '').trim().replace(/\/+$/, '');
    if (!trimmed) {
        return buildChatCompletionsUrl(trimmed);
    }
    if (platform === 'anthropic-compatible' || isAnthropicCompatibleEndpoint(trimmed)) {
        return trimmed.endsWith('/messages') ? trimmed : `${trimmed}/messages`;
    }
    return buildChatCompletionsUrl(trimmed);
}
async function requestAIProxy(payload) {
    const MAX_RETRIES = 3;
    const TIMEOUT_MS = 60000;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const result = await new Promise((resolve, reject) => {
                const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
                const aiPort = chrome.runtime.connect({ name: 'ai-proxy' });
                const cleanup = () => {
                    clearTimeout(timeoutId);
                    aiPort.onMessage.removeListener(handleMessage);
                    aiPort.onDisconnect.removeListener(handleDisconnect);
                    try {
                        aiPort.disconnect();
                    }
                    catch (e) {
                    }
                };
                const timeoutId = setTimeout(() => {
                    cleanup();
                    reject(new Error('AI代理请求超时'));
                }, TIMEOUT_MS);
                const handleMessage = (response) => {
                    if (!response || response.requestId !== requestId) {
                        return;
                    }
                    cleanup();
                    resolve(response);
                };
                const handleDisconnect = () => {
                    const lastError = chrome.runtime.lastError;
                    cleanup();
                    reject(new Error(lastError?.message || 'AI代理连接已断开'));
                };
                aiPort.onMessage.addListener(handleMessage);
                aiPort.onDisconnect.addListener(handleDisconnect);
                aiPort.postMessage({
                    action: 'AI_PROXY_REQUEST',
                    payload,
                    requestId
                });
            });
            return result;
        }
        catch (error) {
            if (attempt === MAX_RETRIES) {
                throw error;
            }
            await new Promise(resolve => setTimeout(resolve, 500 * attempt));
        }
    }
}
async function sendDirectAIRequest(prompt, aiConfig) {
    try {
        const model = aiConfig.model;
        const apiKey = aiConfig.apiKey || aiConfig.token;
        const platform = aiConfig.platform || (isAnthropicCompatibleEndpoint(aiConfig.endpoint) ? 'anthropic-compatible' : 'openai-compatible');
        const endpoint = buildAIRequestUrl(aiConfig.endpoint, platform);
        const result = await requestAIProxy({
            endpoint,
            apiKey,
            model,
            provider: platform,
            prompt,
            maxTokens: GUJJI_API_CONFIG.maxTokens,
            temperature: GUJJI_API_CONFIG.temperature,
            reasoningEffort: aiConfig.reasoningEffort || 'max'
        });
        if (!result) {
            throw new Error(`AI代理无响应，请重新加载扩展后重试`);
        }
        if (!result.success) {
            const fallbackError = result.error || result.message || JSON.stringify(result);
            throw new Error(`AI代理请求失败: ${fallbackError}`);
        }
        return {
            success: true,
            response: result.response
        };
    }
    catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}
function checkAIExpiration() {
    return Promise.resolve(false);
}
async function performAIClickDecision(simpleCandidateInfo) {
    try {
        if (ParserName === 'employer58') {
            return { isok: true, msg: "58无法筛选" };
        }
        showAIDecisionModal();
        const prompt = buildAIClickPrompt(simpleCandidateInfo);
        const result = await sendDirectAIRequest(prompt, currentParser.aiSettings.aiConfig);
        hideAIDecisionModal();
        if (result.success) {
            return normalizeAIResult(parseAIResponse(result.response), '初筛失败');
        }
        else {
            void 0;
            return {
                isok: false,
                msg: result.error || '初筛失败',
                detail: '',
                matchedPoints: [],
                risks: []
            };
        }
    }
    catch (error) {
        hideAIDecisionModal();
        void 0;
        return {
            isok: false,
            msg: error.message || '初筛异常',
            detail: '',
            matchedPoints: [],
            risks: []
        };
    }
}
async function performAIDetailDecision(detailCandidateInfo) {
    try {
        showAIDecisionModal();
        const prompt = buildAIDetailPrompt(detailCandidateInfo);
        const result = await sendDirectAIRequest(prompt, currentParser.aiSettings.aiConfig);
        hideAIDecisionModal();
        if (result.success) {
            return normalizeAIResult(parseAIResponse(result.response), '详情二筛失败');
        }
        else {
            void 0;
            return {
                isok: false,
                msg: result.error || '详情二筛失败',
                detail: '',
                matchedPoints: [],
                risks: []
            };
        }
    }
    catch (error) {
        hideAIDecisionModal();
        void 0;
        return {
            isok: false,
            msg: error.message || '详情二筛异常',
            detail: '',
            matchedPoints: [],
            risks: []
        };
    }
}
function buildAIClickPrompt(simpleCandidateInfo) {
    const customPrompt = currentParser.aiSettings?.aiConfig?.clickPrompt;
    const outputRequirements = `

额外要求：
1. 必须返回 JSON。
2. decision 只能是"是"或"否"。
3. reason 是一句简短结论，25 个字以内。
4. detail 是详细分析，60-160 个字。
5. matched_points 返回 2-4 条匹配点数组。
6. risks 返回 0-3 条风险点数组。
示例：
{"decision":"是","reason":"专业与方向匹配","detail":"候选人的专业背景、求职方向和地点与岗位要求较为一致，虽然项目经历偏少，但作为实习岗仍具备继续查看和沟通价值。","matched_points":["专业对口","求职方向一致","地点匹配"],"risks":["项目经历较少"]}`;
    if (customPrompt) {
        return `${customPrompt
            .replace('${候选人信息}', simpleCandidateInfo)
            .replace('${岗位信息}', currentParser.aiSettings?.jobDescription || '未设置岗位要求')}

${outputRequirements}`;
    }
    return `你是一个资深HR专家。请根据岗位要求和候选人的基础信息判断是否值得继续查看候选人详情。

岗位要求：
${currentParser.aiSettings?.jobDescription || '未设置岗位要求'}

候选人基础信息：
${simpleCandidateInfo}

${outputRequirements}`;
}
function buildAIDetailPrompt(detailCandidateInfo) {
    return `你是一个资深HR专家，请进行二次筛选。

这一次你拿到的是候选人的更完整信息，你需要比初筛更严格，判断是否值得立即沟通。

岗位要求：
${currentParser.aiSettings?.jobDescription || '未设置岗位要求'}

候选人详细信息：
${detailCandidateInfo}

输出要求：
1. 必须只返回 JSON。
2. decision 只能是"是"或"否"。
3. reason 是一句简短结论，25 个字以内。
4. detail 是详细分析，80-180 个字。
5. matched_points 返回 2-4 条匹配点数组。
6. risks 返回 0-4 条风险点数组。
7. 二筛要重点关注项目经历、专业方向、技能匹配度、实习/工作经历以及岗位硬性要求。

示例：
{"decision":"是","reason":"项目与方向匹配","detail":"候选人的项目经历、专业方向和岗位要求整体匹配，虽然实战深度一般，但具备继续沟通并确认细节的价值。","matched_points":["项目方向匹配","专业相关","城市匹配"],"risks":["实战深度一般"]}`;
}
function stripMarkdownCodeFence(text) {
    return String(text || '')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
}
function extractLegacyAIResult(response) {
    const raw = stripMarkdownCodeFence(response);
    if (!raw) {
        return null;
    }
    const decisionMatch = raw.match(/(?:decision|结论|结果|判断)\s*[:："'` ]*\s*(是|否|yes|no)/i) ||
        raw.match(/^\s*(是|否|yes|no)\b/i) ||
        raw.match(/(?:建议|判断|结论)[^\n\r]{0,20}?(是|否)/i);
    if (!decisionMatch) {
        return null;
    }
    const decisionText = decisionMatch[1].toLowerCase();
    const isok = decisionText === '是' || decisionText === 'yes';
    let reason = raw.match(/(?:reason|原因|理由|说明)\s*[:："'` ]*\s*([^\n\r}]+)/i)?.[1] ||
        raw.match(/^\s*(?:是|否|yes|no)\s*[,，:：-]\s*([^\n\r]+)/i)?.[1] ||
        raw.match(/(?:是|否)[^。\n\r]{0,3}[，,:：-]\s*([^\n\r]+)/i)?.[1] ||
        '';
    if (!reason) {
        const lines = raw
            .split(/\r?\n/)
            .map(line => line.trim())
            .filter(Boolean)
            .filter(line => !/^(?:\{|\}|"|decision|matched_points|risks|detail)/i.test(line));
        reason = lines.find(line => !/^(?:是|否|yes|no)$/i.test(line)) || '';
    }
    reason = reason
        .replace(/^["'`{\[]+|["'`\]}。,，\s]+$/g, '')
        .replace(/^(?:原因|理由|说明)\s*[:：]?\s*/i, '')
        .trim();
    const detail = raw.match(/(?:detail|详细分析|分析)\s*[:："'` ]*\s*([^\n\r}]+)/i)?.[1]?.trim() ||
        extractReadableDetail(raw);
    const risksText = raw.match(/(?:risks|风险点|风险)\s*[:："'` ]*\s*([^\n\r}]+)/i)?.[1] || '';
    const risks = risksText
        ? risksText.split(/[、,，;；]/).map(item => item.trim()).filter(Boolean)
        : [];
    if (!reason) {
        reason = isok ? '模型判定通过，但未附原因' : '模型判定不通过，但未附原因';
    }
    return {
        isok,
        msg: reason,
        detail,
        matchedPoints: [],
        risks
    };
}
function parseAIResponse(response) {
    try {
        const normalizedResponse = stripMarkdownCodeFence(response);
        const jsonMatch = normalizedResponse.match(/\{[\s\S]*"decision"[\s\S]*\}/);
        if (jsonMatch) {
            const aiResponse = JSON.parse(jsonMatch[0]);
            const decisionText = String(aiResponse.decision || '');
            const decision = decisionText.includes('是');
            const reason = String(aiResponse.reason || '未提供原因').trim();
            void 0;
            sendMessage({
                type: 'LOG_MESSAGE',
                data: {
                    message: `AI决策: ${decisionText} (${reason})`,
                    type: decision ? 'success' : 'info'
                }
            });
            return {
                isok: decision,
                msg: reason,
                detail: String(aiResponse.detail || '').trim(),
                matchedPoints: Array.isArray(aiResponse.matched_points) ? aiResponse.matched_points : [],
                risks: Array.isArray(aiResponse.risks) ? aiResponse.risks : []
            };
        }
    }
    catch (error) {
        void 0;
        const fallbackResult = extractLegacyAIResult(response);
        if (fallbackResult) {
            sendMessage({
                type: 'LOG_MESSAGE',
                data: {
                    message: `AI决策(文本兼容): ${fallbackResult.isok ? '是' : '否'} (${fallbackResult.msg})`,
                    type: fallbackResult.isok ? 'success' : 'info'
                }
            });
            return fallbackResult;
        }
        sendMessage({
            type: 'LOG_MESSAGE',
            data: {
                message: `解析失败 原文: ${response.trim()}`,
                type: 'error'
            }
        });
        return {
            isok: false,
            msg: '解析失败',
            detail: response.trim(),
            matchedPoints: [],
            risks: []
        };
    }
    const legacyResult = extractLegacyAIResult(response);
    if (legacyResult) {
        sendMessage({
            type: 'LOG_MESSAGE',
            data: {
                message: `AI决策(文本兼容): ${legacyResult.isok ? '是' : '否'} (${legacyResult.msg})`,
                type: legacyResult.isok ? 'success' : 'info'
            }
        });
        return legacyResult;
    }
    void 0;
    sendMessage({
        type: 'LOG_MESSAGE',
        data: {
            message: `格式异常 原文: ${response.trim()}`,
            type: 'error'
        }
    });
    return {
        isok: false,
        msg: '未识别到明确原因',
        detail: response.trim(),
        matchedPoints: [],
        risks: []
    };
}
function createAIDecisionModal() {
    if (document.getElementById('ai-decision-modal')) {
        return document.getElementById('ai-decision-modal');
    }
    const modal = document.createElement('div');
    modal.id = 'ai-decision-modal';
    modal.style.cssText = `
		position: fixed;
		top: 20px;
		right: 20px;
		width: 200px;
		height: 120px;
		background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
		border-radius: 15px;
		box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
		z-index: 10000;
		display: none;
		animation: none;
		overflow: hidden;
	`;
    modal.innerHTML = `
		<div style="
			position: relative;
			width: 100%;
			height: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: white;
			font-family: 'Arial', sans-serif;
		">
			<div style="
				width: 40px;
				height: 40px;
				border: 3px solid rgba(255, 255, 255, 0.3);
				border-top: 3px solid white;
				border-radius: 50%;
				animation: spin 1s linear infinite;
				margin-bottom: 10px;
			"></div>
			<div style="
				font-size: 14px;
				font-weight: bold;
				margin-bottom: 5px;
				text-align: center;
			">AI正在思考...</div>
			<div style="
				font-size: 12px;
				opacity: 0.8;
				text-align: center;
			">请稍候</div>
		</div>
	`;
    const style = document.createElement('style');
    style.textContent = `
		@keyframes slideInRight {
			from {
				transform: translateX(100%);
				opacity: 0;
			}
			to {
				transform: translateX(0);
				opacity: 1;
			}
		}

		@keyframes slideOutRight {
			from {
				transform: translateX(0);
				opacity: 1;
			}
			to {
				transform: translateX(100%);
				opacity: 0;
			}
		}

		@keyframes spin {
			0% { transform: rotate(0deg); }
			100% { transform: rotate(360deg); }
		}

		@keyframes pulse {
			0%, 100% { transform: scale(1); }
			50% { transform: scale(1.05); }
		}
	`;
    document.head.appendChild(style);
    document.body.appendChild(modal);
    return modal;
}
function showAIDecisionModal() {
    const modal = createAIDecisionModal();
    if (modal) {
        modal.style.display = 'block';
        modal.style.animation = 'none';
        modal.style.transform = 'translateX(100%)';
        modal.style.opacity = '0';
        modal.offsetHeight;
        modal.style.animation = 'slideInRight 0.5s ease-out';
        modal.style.transform = '';
        modal.style.opacity = '';
    }
}
function hideAIDecisionModal() {
    const modal = document.getElementById('ai-decision-modal');
    if (modal) {
        modal.style.animation = 'slideOutRight 0.5s ease-out';
        setTimeout(() => {
            modal.style.display = 'none';
            modal.style.animation = 'none';
            modal.style.transform = '';
            modal.style.opacity = '';
        }, 500);
    }
}
function isExtensionValid() {
    return chrome.runtime && chrome.runtime.id;
}
function initializeConnection() {
    try {
        port = chrome.runtime.connect({ name: 'content-script-connection' });
        return true;
    }
    catch (error) {
        void 0;
        return false;
    }
}
async function sendMessage(message) {
    const MAX_RETRIES = 3;
    let retryCount = 0;
    while (retryCount < MAX_RETRIES) {
        try {
            if (!isExtensionValid()) {
                void 0;
                throw new Error('扩展上下文已失效');
            }
            if (!port && !initializeConnection()) {
                throw new Error('无法建立连接');
            }
            return await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage(message, function (response) {
                    const lastError = chrome.runtime.lastError;
                    if (lastError) {
                        if (lastError.message.includes('Receiving end does not exist')) {
                            void 0;
                            port = null;
                            initializeConnection();
                            reject(lastError);
                            return;
                        }
                        void 0;
                        reject(lastError);
                        return;
                    }
                    resolve(response);
                });
            });
        }
        catch (error) {
            retryCount++;
            void 0;
            if (retryCount === MAX_RETRIES) {
                throw error;
            }
            await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
        }
    }
}
function createDraggablePrompt() {
    return;
    if (currentPrompt) {
        currentPrompt.remove();
    }
    const prompt = document.createElement('div');
    currentPrompt = prompt;
    prompt.className = 'goodhr-prompt';
    prompt.style.position = 'fixed';
    prompt.style.top = '20px';
    prompt.style.right = '20px';
    prompt.style.padding = '10px';
    prompt.style.backgroundColor = '#f9f9f9';
    prompt.style.border = '1px solid #ddd';
    prompt.style.borderRadius = '10px';
    prompt.style.boxShadow = '0 6px 20px rgba(0,0,0,0.5)';
    prompt.style.zIndex = '9999';
    prompt.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    prompt.style.opacity = '0';
    prompt.style.transform = 'translateY(-10px)';
    prompt.innerHTML = `
        <div style='cursor: move; display: flex; justify-content: space-between; align-items: center;'>
            <div style='display: flex; align-items: center;'>
                <strong style='color: #1a73e8; margin-right: 5px; font-size: 16px;'>GoodHR 插件</strong>
                <span style='background-color: #e8f0fe; color: #1a73e8; padding: 2px 6px; border-radius: 10px; font-size: 12px;'>v${window.GOODHR_CONFIG ? window.GOODHR_CONFIG.VERSION : chrome.runtime.getManifest().version}</span>
            </div>
            <span style='font-size: 12px; color: #999;'>拖动</span>
        </div>
        <div style='margin-top: 15px; text-align: center;'>
            <div style='margin-bottom: 15px; font-size: 14px;'>是否打开 GoodHR 插件？</div>
            <div>
                <button id='open-plugin' style='
                    padding: 5px 20px;
                    background-color: #1a73e8;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    transition: background-color 0.2s, transform 0.2s;
                    font-weight: 500;
                '>是</button>
                <button id='close-prompt' style='
                    padding: 5px 20px;
                    background-color: #ff4444;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    margin-left: 10px;
                    transition: background-color 0.2s, transform 0.2s;
                    font-weight: 500;
                '>取消 (10s)</button>
            </div>
        </div>
    `;
    document.body.appendChild(prompt);
    const buttons = prompt.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('mouseover', () => {
            button.style.opacity = '0.9';
            button.style.transform = 'translateY(-1px)';
        });
        button.addEventListener('mouseout', () => {
            button.style.opacity = '1';
            button.style.transform = 'translateY(0)';
        });
    });
    setTimeout(() => {
        prompt.style.opacity = '1';
        prompt.style.transform = 'translateY(0)';
    }, 10);
    let countdown = 10;
    const closeButton = prompt.querySelector('#close-prompt');
    const countdownInterval = setInterval(() => {
        countdown--;
        if (countdown >= 0) {
            closeButton.textContent = `取消 (${countdown}s)`;
        }
        if (countdown === 0) {
            clearInterval(countdownInterval);
            prompt.style.opacity = '0';
            prompt.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                prompt.remove();
                currentPrompt = null;
            }, 300);
        }
    }, 1000);
    let isDragging = false;
    let offsetX, offsetY;
    const dragHandle = prompt.querySelector('div[style*="cursor: move"]');
    dragHandle.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - prompt.getBoundingClientRect().left;
        offsetY = e.clientY - prompt.getBoundingClientRect().top;
        prompt.style.boxShadow = '0 8px 28px rgba(0,0,0,0.28)';
    });
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            prompt.style.left = e.clientX - offsetX + 'px';
            prompt.style.top = e.clientY - offsetY + 'px';
            prompt.style.right = 'auto';
        }
    });
    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            prompt.style.boxShadow = '0 4px 20px rgba(0,0,0,0.2)';
        }
    });
    const openButton = prompt.querySelector('#open-plugin');
    openButton.addEventListener('click', () => {
        clearInterval(countdownInterval);
        prompt.style.transform = 'scale(0.95)';
        setTimeout(() => {
            chrome.runtime.sendMessage({ action: 'OPEN_PLUGIN' }, (response) => {
                if (chrome.runtime.lastError) {
                    void 0;
                }
                else {
                    void 0;
                }
            });
            prompt.style.opacity = '0';
            prompt.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                prompt.remove();
                currentPrompt = null;
            }, 300);
        }, 150);
    });
    closeButton.addEventListener('click', () => {
        clearInterval(countdownInterval);
        prompt.style.opacity = '0';
        prompt.style.transform = 'translateY(-10px)';
        setTimeout(() => {
            prompt.remove();
            currentPrompt = null;
        }, 300);
    });
}
try {
    const isInIframe = window !== window.top;
    removeAds();
    initializeParser().then(() => {
    });
}
catch (error) {
    void 0;
    showNotification('⚠️ 初始化失败', 'status');
}
document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
        setTimeout(() => {
            if (document.hidden && document.visibilityState === 'hidden') {
                if (isRunning) {
                    handleWindowMinimized();
                }
            }
        }, 100);
    }
    else {
    }
});
window.addEventListener('beforeunload', function () {
    chrome.storage.local.remove(['adDisplayed']);
});
function handleWindowMinimized() {
    try {
        if (isRunning) {
            void 0;
            sendMessage({
                type: 'LOG_MESSAGE',
                data: {
                    message: '检测到窗口最小化，已暂停运行',
                    type: 'warning'
                }
            });
        }
    }
    catch (error) {
        void 0;
    }
}
initializeConnection();
let adConfig = null;
async function loadAdConfig() {
    adConfig = null;
}
function createAdElement(adData, position) {
    if (!adData) {
        return null;
    }
    const adElement = document.createElement('div');
    adElement.className = `ad-container ad-${position}`;
    adElement.setAttribute('data-ad-id', adData.id);
    if (adData.style) {
        Object.assign(adElement.style, {
            background: adData.style.background || '#f8f9fa',
            color: adData.style.color || '#333333',
            border: adData.style.border || '1px solid #e9ecef',
            padding: '8px',
            margin: '8px 0',
            borderRadius: '6px',
            fontSize: '12px',
            cursor: adData.link ? 'pointer' : 'default',
            position: 'relative'
        });
    }
    let content = `<div class="ad-title" style="font-weight: 600; margin-bottom: 4px;">${adData.title}</div>`;
    content += `<div class="ad-content">${adData.content}</div>`;
    if (adData.image) {
        content = `<img src="${adData.image}" style="max-width: 100%; height: auto; margin-bottom: 4px;">` + content;
    }
    if (adConfig && adConfig.config && adConfig.config.show_close_button) {
        content += `<button class="ad-close-btn" style="position: absolute; top: 4px; right: 4px; background: rgba(0,0,0,0.2); border: none; color: white; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; cursor: pointer; line-height: 1;">&times;</button>`;
    }
    adElement.innerHTML = content;
    if (adData.link) {
        adElement.addEventListener('click', (e) => {
            if (e.target.classList.contains('ad-close-btn')) {
                return;
            }
            if (adConfig && adConfig.config && adConfig.config.click_tracking) {
                void 0;
            }
            window.open(adData.link, '_blank');
        });
    }
    const closeBtn = adElement.querySelector('.ad-close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            adElement.remove();
        });
    }
    return adElement;
}
function createDraggableAdElement(adData) {
    if (!adData) {
        return null;
    }
    const adElement = document.createElement('div');
    adElement.className = 'draggable-ad-container';
    adElement.setAttribute('data-ad-id', adData.id);
    Object.assign(adElement.style, {
        position: 'fixed',
        left: adData.x ? adData.x + 'px' : '100px',
        top: adData.y ? adData.y + 'px' : '100px',
        width: adData.width ? adData.width + 'px' : '300px',
        height: adData.height ? adData.height + 'px' : '200px',
        background: adData.style.background || '#f8f9fa',
        color: adData.style.color || '#333333',
        border: adData.style.border || '1px solid #e9ecef',
        borderRadius: '6px',
        fontSize: '12px',
        cursor: 'move',
        zIndex: '10000',
        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
        overflow: 'hidden'
    });
    let content = `<div class="ad-header" style="padding: 0px 8px; background: rgba(0,0,0,0.05); cursor: move; user-select: none; display: flex; justify-content: space-between; align-items: center;">`;
    content += `<div class="ad-title" style="font-weight: 600;">${adData.title}</div>`;
    if (adConfig && adConfig.config && adConfig.config.show_close_button) {
        content += `<button class="ad-close-btn" style="background: rgba(0,0,0,0.2); border: none; color: white; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; cursor: pointer; line-height: 1;">&times;</button>`;
    }
    content += `</div>`;
    content += `<div class="ad-content" style="padding: 0px 8px;  overflow-y: auto;cursor: pointer; ">${adData.content}</div>`;
    if (adData.bottom_content) {
        content += `<div class="ad-bottom-content" style="line-height: 1.4;padding: 0px 2px; font-size: 10px; color: #666; border-top: 1px solid #eee; background: rgba(0,0,0,0.02);">${adData.bottom_content || '免费版运行时无法关闭该广告(可拖拽)、如需关闭 请刷新浏览器或停止运行或升级AI版'}</div>`;
    }
    if (adData.image) {
        content = `<img src="${adData.image}" style="max-width: 100%; height: auto; margin-bottom: 4px;">` + content;
    }
    adElement.innerHTML = content;
    let isDragging = false;
    let currentX;
    let currentY;
    let initialX;
    let initialY;
    let xOffset = 0;
    let yOffset = 0;
    let dragStartTime = 0;
    const dragHeader = adElement.querySelector('.ad-header');
    if (dragHeader) {
        dragHeader.addEventListener('mousedown', dragStart);
        document.addEventListener('mouseup', dragEnd);
        document.addEventListener('mousemove', drag);
    }
    function dragStart(e) {
        if (e.target !== dragHeader && !dragHeader.contains(e.target)) {
            return;
        }
        dragStartTime = Date.now();
        initialX = e.clientX - xOffset;
        initialY = e.clientY - yOffset;
        isDragging = true;
        e.preventDefault();
    }
    function dragEnd(e) {
        const dragDuration = Date.now() - dragStartTime;
        initialX = currentX;
        initialY = currentY;
        isDragging = false;
        if (dragDuration < 200) {
            const moveDistance = Math.sqrt(Math.pow(xOffset, 2) + Math.pow(yOffset, 2));
            if (moveDistance < 5) {
                isDragging = false;
            }
        }
    }
    function drag(e) {
        if (isDragging) {
            e.preventDefault();
            currentX = e.clientX - initialX;
            currentY = e.clientY - initialY;
            xOffset = currentX;
            yOffset = currentY;
            setTranslate(currentX, currentY, adElement);
        }
    }
    function setTranslate(xPos, yPos, el) {
        el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0)`;
    }
    if (adData.link) {
        adElement.addEventListener('click', (e) => {
            if (isDragging) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            if (e.target.classList.contains('ad-close-btn') ||
                e.target.classList.contains('ad-header') ||
                (e.target.parentElement && e.target.parentElement.classList.contains('ad-header'))) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            if (adConfig && adConfig.config && adConfig.config.click_tracking) {
                void 0;
            }
            window.open(adData.link, '_blank');
        });
    }
    const closeBtn = adElement.querySelector('.ad-close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            adElement.remove();
        });
    }
    return adElement;
}
function displayAds(isAIExpired) {
    const isInIframe = window !== window.top;
    if (isInIframe) {
        void 0;
        return;
    }
    if (!adConfig || !adConfig.success || !adConfig.ads) {
        return;
    }
    if (adConfig.ads.pageAds && Array.isArray(adConfig.ads.pageAds)) {
        adConfig.ads.pageAds.forEach(adData => {
            void 0;
            if (isAIExpired || (!isAIExpired && adData.vip_show)) {
                const adElement = createDraggableAdElement(adData);
                if (adElement) {
                    document.body.appendChild(adElement);
                }
            }
        });
    }
    const targetElements = document.querySelectorAll('[class*="list"], [class*="container"], [class*="content"]');
    if (targetElements.length > 0) {
    }
}
function shouldShowAd(probability) {
    if (probability === undefined)
        return true;
    return Math.random() * 100 < probability;
}
