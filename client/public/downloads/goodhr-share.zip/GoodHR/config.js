const CONFIG = {
    API_BASE: 'https://goodhr.58it.cn',
    GUJJI_API: {
        baseUrl: 'https://api.siliconflow.cn/v1/chat/completions',
        maxTokens: 100,
        temperature: 0.1
    },
    VERSION: '2.8.1',
    DEFAULTS: {
        matchLimit: 200,
        scrollDelayMin: 3,
        scrollDelayMax: 5,
        clickFrequency: 7,
        enableSound: true
    },
    COMPANY_INFO: {
        name: "",
        address: "",
        scale: "",
        industry: "",
        description: "",
        culture: "",
        benefits: "",
        location: "",
        website: ""
    },
    JOB_INFO: {
        position: "",
        responsibilities: [],
        requirements: [],
        salary: "",
        workHours: "",
        overtime: "",
        benefits: "",
        growth: "",
        team: "",
        environment: ""
    },
    COMMUNICATION_CONFIG: {
        enabled: false,
        collectPhone: true,
        collectWechat: true,
        collectResume: true
    },
    RUN_MODE_CONFIG: {
        greetingEnabled: true,
        communicationEnabled: true
    }
};
if (typeof window !== 'undefined') {
    window.GOODHR_CONFIG = CONFIG;
}
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
